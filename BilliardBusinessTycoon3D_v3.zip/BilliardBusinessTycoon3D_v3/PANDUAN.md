# Panduan Billiard Business Tycoon 3D (v0.3)

## 1. Yang baru di v0.3
- **Main billiard sendiri (9-ball).** Tekan **MAIN** → pilih lawan (Mudah/Sedang/Sulit/Pro). Aturan: pukul bola urut dari angka terkecil, masukkan bola 9 untuk menang. Foul (bola putih masuk, salah sentuh bola, tidak ada bantalan) = lawan dapat bola putih di tangan.
- **NPC main 1 vs 1 sungguhan** di setiap meja: berjalan ke meja, membidik, memukul dengan stik, bola bergulir dengan fisika, ada foul dan giliran. Satu pertandingan berlangsung sekitar 2–3 menit. Bayaran dihitung dari lama bermain (lebih lama = lebih besar).
- **Karakter 3D** berkaki, bertangan, dan berkepala yang berjalan dan membungkuk saat membidik. 5 tipe pengunjung (Anak Muda, Karyawan, Pemain Pro, Tamu VIP, Influencer) dengan kemampuan dan bayaran berbeda.
- **Lampu atas dihapus.** Tidak ada benda yang menghalangi pandangan.
- **Grafis lebih nyata:** tekstur kayu/keramik/marmer, kain meja bernoda serat dengan kantong dan titik, bola bernomor yang berputar, bayangan, tone mapping, papan nama neon, dekorasi per lokasi. Resolusi menyesuaikan otomatis supaya tidak lag (bisa dipilih di Pengaturan).
- **Progres lebih panjang:** 5 lokasi (Ruko → Arena Internasional), meja sampai Lv.10, batas level meja naik tiap renovasi lokasi, 4 jenis karyawan yang terlihat bekerja, 3 fasilitas.
- **Fitur baru:** Turnamen Harian (4 peserta) dan Kejuaraan Mingguan (8 peserta, bracket), piala emas di lemari pajangan, misi harian, hadiah menang, suara, garis bantu bidikan.
- **UI baru:** HUD kaca, menu bawah dengan tombol MAIN, kartu rapi, tombol 3D.

## 2. Cara main
1. Tekan **MAIN**, pilih lawan.
2. **Geser layar kiri/kanan** untuk membidik (aktifkan **Presisi** untuk geseran halus). Garis putih = arah bola putih, garis kuning = arah bola target.
3. Atur **KUAT** (geser slider kanan) dan **EFEK** (slider kiri: atas = bola maju/follow, bawah = bola mundur/draw).
4. Tekan **SODOK**. Jika bola putih di tangan, geser untuk memindah bola lalu tekan **Letakkan**.

## 3. Top Up masih mode demo
Paket top up belum terhubung pembayaran, berlian diberikan gratis untuk uji coba (ada tulisan peringatan di menu). Untuk uang sungguhan di Play Store wajib **Google Play Billing**: buat produk dalam aplikasi, pasang plugin, isi `window.onBuyGems` di `www/game.js`, ubah `PAYMENT_ENABLED = true`, dan validasi pembelian di server.

## 4. Cara perbarui di repo-mu
1. Di repo, hapus zip lama (ikon sampah → Commit). **Hanya boleh ada satu zip.**
2. **Add file → Upload files** → unggah `BilliardBusinessTycoon3D_v3.zip` (tanpa diekstrak) → Commit.
3. Buka **Actions**, tunggu hijau ✔ (jika tidak jalan: Run workflow).
4. Ambil APK di **Releases → Billiard Tycoon 3D (build terbaru)**.
5. Hapus aplikasi lama sebelum memasang yang baru (kunci debug berubah tiap build).
**Catatan:** versi ini memakai data simpanan baru, jadi progres versi lama tidak terbawa.

## 5. Jika lag
Buka ⚙️ (kanan atas) → Kualitas Grafis → pilih **Rendah** atau **Sedang**. Mode Otomatis menurunkan resolusi sendiri saat layar berat.

## 6. Jika build merah atau ada bug
Kirim screenshot langkah yang gagal di Actions, atau jelaskan bug-nya.
