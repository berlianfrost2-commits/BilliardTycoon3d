(() => {
'use strict';
const E = window.Engine, R = E.R, HX = E.HX, HZ = E.HZ, POCKET = E.POCKET;
const $ = id => document.getElementById(id);
const SAVE = 'bt3d_save_v2', TOP = 0.885, BALL_Y = TOP + R, MAX_LV = 10;
const ROWS = [1, 2, 3, 4, 4], CAP = [2, 4, 6, 8, 8], LVCAP = [4, 6, 8, 10, 10], VCOST = [0, 3000, 25000, 200000, 1500000];
const VEN = ['Ruko Billiard Sederhana', 'Billiard Kampung', 'Billiard Kota', 'Pusat Billiard', 'Arena Internasional'];
const FRAME = [0x6b4426, 0x5c3a1e, 0x4a2a12, 0x2b1608, 0xc9a227, 0xd8d8e0, 0xe8c14a, 0x9aa0a8, 0x7a4bd0, 0xffd36b];
const CLOTHS = ['#1f6b35', '#1d6a3a', '#16603f', '#0f6a4f', '#0b6a63', '#0b5d7a', '#1b4f86', '#4a2a86', '#7a1f5a', '#8a1c2c'];
const TNAME = ['Meja Kayu Sederhana', 'Meja Hijau Klasik', 'Meja Semi-Pro', 'Meja Profesional', 'Meja VIP Emas', 'Meja Platinum', 'Meja Turnamen', 'Meja Kristal', 'Meja Royal', 'Meja Legendaris'];
const BALLC = [0xffffff, 0xf1c40f, 0x2e86de, 0xe74c3c, 0x8e44ad, 0xe67e22, 0x27ae60, 0x7b241c, 0x111111, 0xf5d142];
const NAMES = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eko', 'Fajar', 'Gita', 'Hadi', 'Indra', 'Joko', 'Kiki', 'Lina', 'Maya', 'Nando', 'Oki', 'Putri', 'Rian', 'Sari', 'Tono', 'Udin'];
const rr = (a, b) => a + Math.random() * (b - a);
const pick = a => a[Math.random() * a.length | 0];

// ===== Data =====
const DEF = () => ({ name: '', cash: 400, gems: 20, total: 0, venue: 1, tables: [1], staff: { kasir: 0, pelayan: 0, bersih: 0, pelatih: 0 }, fac: { cafe: 0, ac: 0, park: 0 }, price: 3, boostUntil: 0, visits: 0, wins: 0, losses: 0, pots: 0, trophies: 0, daily: 0, quality: 'auto', mute: false, assist: true, tcd: { d: 0, w: 0 }, mis: { day: 0, list: [] }, tour: null, t: Date.now() });
let S = (() => { let d = {}; try { d = JSON.parse(localStorage.getItem(SAVE)) || {}; } catch (e) {} const o = Object.assign(DEF(), d); for (const k of ['staff', 'fac', 'tcd', 'mis']) o[k] = Object.assign(DEF()[k], d[k] || {}); return o; })();
const save = () => { if (window.__reset) return; try { S.t = Date.now(); localStorage.setItem(SAVE, JSON.stringify(S)); } catch (e) {} };
const fmt = n => n >= 1e9 ? (n / 1e9).toFixed(2) + 'M' : n >= 1e6 ? (n / 1e6).toFixed(2) + 'jt' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'rb' : Math.floor(n) + '';
const boosted = () => Date.now() < S.boostUntil;
const priceMult = () => 0.4 + 0.2 * S.price;
const bonus = () => (1 + 0.12 * S.fac.cafe + 0.1 * S.fac.ac + 0.1 * S.staff.kasir + 0.08 * S.staff.pelayan + 0.06 * S.staff.bersih + 0.07 * S.staff.pelatih) * priceMult() * (boosted() ? 2 : 1);
const rate = lv => 1.2 * Math.pow(1.38, lv - 1) * bonus();
const income = () => S.tables.reduce((a, l) => a + rate(l), 0) * 0.75;
const stars = () => Math.min(5, Math.floor(Math.log10(S.total + 10)));
const upCost = lv => Math.round(150 * Math.pow(1.95, lv - 1));
const buyCost = () => Math.round(400 * Math.pow(2.6, S.tables.length - 1));
const FAC = { cafe: { n: 'Kafe & Minuman', ic: '☕', base: 400, max: 5, d: '+12% pendapatan' }, ac: { n: 'AC & Ruang Nyaman', ic: '❄️', base: 700, max: 5, d: '+10% pendapatan' }, park: { n: 'Lahan Parkir', ic: '🅿️', base: 500, max: 5, d: 'Pengunjung lebih sering' } };
const STAFF = { kasir: { n: 'Kasir', ic: '🧾', base: 600, d: '+10% pendapatan' }, pelayan: { n: 'Pelayan', ic: '🍹', base: 900, d: '+8% pendapatan' }, bersih: { n: 'Petugas Kebersihan', ic: '🧹', base: 700, d: '+6% pendapatan' }, pelatih: { n: 'Pelatih', ic: '🎓', base: 1200, d: '+7% pendapatan' } };
const stCost = (k, l) => Math.round(STAFF[k].base * Math.pow(2.4, l));
const facCost = (k, l) => Math.round(FAC[k].base * Math.pow(2.2, l));
let sel = 0, PL = null, tab = null;
const ctls = [], chars = [], tables = [], staffList = [];

// misi harian
const MP = [
  { id: 'visit', t: n => `Layani ${n} pertandingan pengunjung`, n: [2, 3, 5] },
  { id: 'win', t: n => `Menangkan ${n} pertandingan sendiri`, n: [1, 2] },
  { id: 'pot', t: n => `Masukkan ${n} bola`, n: [6, 10, 16] },
  { id: 'up', t: n => `Upgrade meja ${n}x`, n: [1, 2] },
  { id: 'earn', t: n => `Kumpulkan $${fmt(n)}`, n: [0] }
];
function genMissions() {
  const day = Math.floor(Date.now() / 864e5); if (S.mis.day === day && S.mis.list.length) return;
  const pool = MP.slice().sort(() => Math.random() - 0.5).slice(0, 3);
  S.mis = { day, list: pool.map(p => { const need = p.id === 'earn' ? Math.max(500, Math.round(income() * 400 / 100) * 100) : pick(p.n); return { id: p.id, need, got: 0, done: false, claimed: false, gem: Math.random() < 0.5 }; }) };
}
function prog(id, k) { for (const m of S.mis.list) if (m.id === id && !m.done) { m.got += k; if (m.got >= m.need) { m.done = true; toast('✅ Misi selesai! Klaim di tab Turnamen'); } } }
function addCash(n) { S.cash += n; S.total += n; prog('earn', n); }

function toast(m) { const t = $('toast'); t.textContent = m; t.style.opacity = 1; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.opacity = 0, 2600); }
let AC = null, sfxN = 0;
function sfx(kind, v) {
  if (S.mute || sfxN > 3) return; sfxN++;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
    o.connect(g); g.connect(AC.destination); const f = { click: 1500, rail: 320, pot: 170, cue: 760, win: 880 }[kind] || 600;
    o.type = kind === 'pot' ? 'sine' : 'triangle'; o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 0.5, t + 0.08);
    g.gain.setValueAtTime(Math.min(0.22, 0.03 + (v || 1) * 0.04), t); g.gain.exponentialRampToValueAtTime(0.0001, t + (kind === 'pot' ? 0.22 : 0.07)); o.start(t); o.stop(t + 0.25);
  } catch (e) {}
}

// ===== Renderer =====
const QS = S.quality === 'low' ? { pr: 1, sh: 0, aa: false } : S.quality === 'mid' ? { pr: 1.5, sh: 1024, aa: true } : { pr: 2, sh: 2048, aa: true };
const renderer = new THREE.WebGLRenderer({ antialias: QS.aa, powerPreference: 'high-performance' });
let prCur = Math.min(window.devicePixelRatio || 1, QS.pr);
renderer.setPixelRatio(prCur);
renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
if (QS.sh) { renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; }
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0a0c10); scene.fog = new THREE.Fog(0x0a0c10, 20, 55);
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 80);
const camT = new THREE.Vector3(0, 0.8, 0), camP = new THREE.Vector3(0, 5, 4), UP = new THREE.Vector3(0, 1, 0);
scene.add(new THREE.HemisphereLight(0xfff1dd, 0x3a2e26, 0.8));
const sun = new THREE.DirectionalLight(0xfff0dd, 0.95); sun.position.set(6, 14, 9);
if (QS.sh) { sun.castShadow = true; sun.shadow.mapSize.set(QS.sh, QS.sh); Object.assign(sun.shadow.camera, { left: -13, right: 13, top: 13, bottom: -13, near: 2, far: 40 }); sun.shadow.bias = -0.0005; }
scene.add(sun); sun.target.position.set(2, 0, 3); scene.add(sun.target);
const CAST = !!QS.sh;

// ===== Tekstur =====
function ctex(w, h, fn, rx, ry) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4;
  if (rx) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); } return t;
}
function grain(x, w, h, n, a, col) { x.fillStyle = col; for (let i = 0; i < n; i++) { x.globalAlpha = Math.random() * a; x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2); } x.globalAlpha = 1; }
function floorTex(type, W, H) {
  return ctex(512, 512, (x, w, h) => {
    if (type === 0) { x.fillStyle = '#7d7b76'; x.fillRect(0, 0, w, h); grain(x, w, h, 7000, 0.35, '#000'); grain(x, w, h, 3000, 0.3, '#fff'); x.strokeStyle = '#0003'; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(Math.random() * w, Math.random() * h); x.lineTo(Math.random() * w, Math.random() * h); x.stroke(); } }
    else if (type === 1) { x.fillStyle = '#d9cfbd'; x.fillRect(0, 0, w, h); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { x.fillStyle = `rgba(0,0,0,${Math.random() * 0.07})`; x.fillRect(i * 128, j * 128, 128, 128); } x.strokeStyle = '#9c9382'; x.lineWidth = 3; for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(i * 128, 0); x.lineTo(i * 128, h); x.moveTo(0, i * 128); x.lineTo(w, i * 128); x.stroke(); } grain(x, w, h, 2500, 0.2, '#000'); }
    else if (type === 2) { for (let i = 0; i < 8; i++) { x.fillStyle = `hsl(28,48%,${38 + Math.random() * 12}%)`; x.fillRect(i * 64, 0, 64, h); x.strokeStyle = 'rgba(50,25,8,.25)'; for (let k = 0; k < 14; k++) { x.beginPath(); const px = i * 64 + Math.random() * 64; x.moveTo(px, 0); x.lineTo(px + Math.random() * 6 - 3, h); x.stroke(); } x.fillStyle = '#0005'; x.fillRect(i * 64, 0, 2, h); } for (let k = 0; k < 8; k++) { x.fillStyle = '#0003'; x.fillRect(Math.random() * w, 0, 2, 0); } }
    else if (type === 3) { x.fillStyle = '#e8e6e2'; x.fillRect(0, 0, w, h); x.lineCap = 'round'; for (let i = 0; i < 16; i++) { x.strokeStyle = `rgba(110,115,130,${0.15 + Math.random() * 0.3})`; x.lineWidth = 1 + Math.random() * 3; x.beginPath(); x.moveTo(Math.random() * w, 0); x.bezierCurveTo(Math.random() * w, h * 0.3, Math.random() * w, h * 0.6, Math.random() * w, h); x.stroke(); } grain(x, w, h, 1500, 0.15, '#000'); x.strokeStyle = '#0002'; x.strokeRect(0, 0, w, h); }
    else { x.fillStyle = '#1b1d23'; x.fillRect(0, 0, w, h); x.strokeStyle = '#c9a22755'; x.lineWidth = 2; for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(i * 128, 0); x.lineTo(i * 128, h); x.moveTo(0, i * 128); x.lineTo(w, i * 128); x.stroke(); } grain(x, w, h, 3000, 0.25, '#fff'); }
  }, W / 3, H / 3);
}
const woodFrame = ctex(256, 256, (x, w, h) => { for (let i = 0; i < 8; i++) { x.fillStyle = `hsl(25,35%,${34 + Math.random() * 8}%)`; x.fillRect(0, i * 32, w, 32); for (let k = 0; k < 18; k++) { x.fillStyle = `rgba(20,8,0,${Math.random() * 0.2})`; x.fillRect(Math.random() * w, i * 32 + Math.random() * 30, 30 + Math.random() * 90, 1); } } });
const clothCache = {};
function clothTex(i) {
  return clothCache[i] || (clothCache[i] = ctex(1024, 512, (x, w, h) => {
    x.fillStyle = CLOTHS[i]; x.fillRect(0, 0, w, h); grain(x, w, h, 14000, 0.16, '#000'); grain(x, w, h, 9000, 0.1, '#fff');
    const s = w / (2 * HX), u = v => (v + HX) * s, vv = v => (v + HZ) * s;
    x.strokeStyle = 'rgba(255,255,255,.12)'; x.lineWidth = 2; x.beginPath(); x.moveTo(u(-0.6), 0); x.lineTo(u(-0.6), h); x.stroke();
    x.fillStyle = 'rgba(255,255,255,.35)'; x.beginPath(); x.arc(u(0.45), vv(0), 4, 0, 7); x.fill();
    for (const p of E.POCKETS) { x.fillStyle = '#050505'; x.beginPath(); x.arc(u(p[0]), vv(p[1]), POCKET * s, 0, 7); x.fill(); x.strokeStyle = 'rgba(0,0,0,.5)'; x.lineWidth = 6; x.stroke(); }
  }));
}
const poolTex = ctex(128, 128, (x, w, h) => { const g = x.createRadialGradient(64, 64, 4, 64, 64, 62); g.addColorStop(0, 'rgba(255,225,170,.55)'); g.addColorStop(1, 'rgba(255,225,170,0)'); x.fillStyle = g; x.fillRect(0, 0, w, h); });
const ballMat = [];
for (let n = 0; n <= 9; n++) {
  const col = '#' + BALLC[n].toString(16).padStart(6, '0');
  const tx = ctex(256, 128, (x, w, h) => {
    x.fillStyle = (n === 0 || n === 9) ? '#f4f4ef' : col; x.fillRect(0, 0, w, h); if (n === 9) { x.fillStyle = col; x.fillRect(0, h * 0.25, w, h * 0.5); }
    for (const cx of [w * 0.25, w * 0.75]) { if (n > 0) { x.fillStyle = '#fff'; x.beginPath(); x.arc(cx, h / 2, 22, 0, 7); x.fill(); x.fillStyle = '#111'; x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(String(n), cx, h / 2 + 2); } else { x.fillStyle = '#c0392b'; x.beginPath(); x.arc(cx, h / 2, 6, 0, 7); x.fill(); } }
  });
  ballMat.push(new THREE.MeshStandardMaterial({ map: tx, roughness: 0.16, metalness: 0.05 }));
}
const ballGeo = new THREE.SphereGeometry(R, 20, 14);

// ===== Venue =====
const venueG = new THREE.Group(); scene.add(venueG);
const W0 = -3.6, W1 = 6.9, Z0 = -3.2, DOOR_Z = 1.8, COUNTER = { x: -2.9, z: -1.7 };
const lam = (c, r) => new THREE.MeshLambertMaterial({ color: c });
const std = (c, r, m, e) => new THREE.MeshStandardMaterial({ color: c, roughness: r == null ? 0.6 : r, metalness: m || 0, emissive: e || 0x000000 });
function box(g, w, h, d, mat, x, y, z, cast) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.castShadow = !!cast && CAST; m.receiveShadow = true; g.add(m); return m; }
const signC = document.createElement('canvas'); signC.width = 1024; signC.height = 256;
const signT = new THREE.CanvasTexture(signC); signT.encoding = THREE.sRGBEncoding;
function drawSign() {
  const x = signC.getContext('2d'); x.shadowBlur = 0; x.fillStyle = '#10161a'; x.fillRect(0, 0, 1024, 256); x.strokeStyle = '#ffd75e'; x.lineWidth = 10; x.strokeRect(10, 10, 1004, 236);
  const t = (S.name || 'BILLIARD BUSINESS').toUpperCase(); let fs = 100; x.font = 'bold ' + fs + 'px sans-serif';
  while (x.measureText(t).width > 940 && fs > 30) { fs -= 4; x.font = 'bold ' + fs + 'px sans-serif'; }
  x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#fff3b0'; x.shadowColor = '#ffb300'; x.shadowBlur = 24; x.fillText(t, 512, 105);
  x.shadowBlur = 0; x.font = '34px sans-serif'; x.fillStyle = '#9fe6b0'; x.fillText('BILLIARD  •  CAFE  •  LOUNGE', 512, 205); signT.needsUpdate = true;
}
function artTex(seed) { return ctex(128, 96, (x, w, h) => { x.fillStyle = '#e9e1cf'; x.fillRect(0, 0, w, h); for (let i = 0; i < 6; i++) { x.fillStyle = `hsl(${(seed * 70 + i * 50) % 360},55%,${40 + i * 4}%)`; x.beginPath(); x.arc(Math.random() * w, Math.random() * h, 12 + Math.random() * 26, 0, 7); x.fill(); } }); }
function buildVenue() {
  while (venueG.children.length) venueG.remove(venueG.children[0]);
  const v = S.venue, rows = ROWS[v - 1], Z1 = rows * 3.2 - 0.4, cx = (W0 + W1) / 2, cz = (Z0 + Z1) / 2, G = venueG;
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(W1 - W0, Z1 - Z0), new THREE.MeshStandardMaterial({ map: floorTex([0, 1, 2, 3, 4][v - 1], W1 - W0, Z1 - Z0), roughness: v >= 4 ? 0.22 : 0.6, metalness: v >= 4 ? 0.1 : 0 }));
  fl.rotation.x = -Math.PI / 2; fl.position.set(cx, 0, cz); fl.receiveShadow = true; G.add(fl);
  const gnd = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), lam(0x15171b)); gnd.rotation.x = -Math.PI / 2; gnd.position.set(cx, -0.02, cz); G.add(gnd);
  const wc = [0x8d8272, 0xc9bb9b, 0xb59a74, 0x3b4658, 0x1d2333][v - 1], wm = lam(wc);
  box(G, W1 - W0 + 0.4, 3.4, 0.2, wm, cx, 1.7, Z0 - 0.1); box(G, 0.2, 3.4, Z1 - Z0, wm, W0 - 0.1, 1.7, cz); box(G, 0.2, 3.4, Z1 - Z0, wm, W1 + 0.1, 1.7, cz);
  const base = lam(v >= 3 ? 0x4a2f1a : 0x5a5348);
  box(G, W1 - W0, 0.16, 0.06, base, cx, 0.08, Z0 + 0.03); box(G, 0.06, 0.16, Z1 - Z0, base, W0 + 0.03, 0.08, cz); box(G, 0.06, 0.16, Z1 - Z0, base, W1 - 0.03, 0.08, cz);
  if (v >= 3) { const pn = lam(0x5b3a22); box(G, W1 - W0, 1.0, 0.05, pn, cx, 0.65, Z0 + 0.05); box(G, 0.05, 1.0, Z1 - Z0, pn, W0 + 0.05, 0.65, cz); }
  sign.position.set(2.2, 2.55, Z0 + 0.02); G.add(sign);
  // pintu
  const dm = std(0x3b2412, 0.5); box(G, 0.12, 2.2, 1.1, dm, W0 + 0.02, 1.1, DOOR_Z); box(G, 0.14, 0.05, 1.3, std(0xc9a227, 0.3, 0.8), W0 + 0.02, 2.25, DOOR_Z);
  // meja kasir/bar
  const cm = v >= 2 ? std(0x5a3a22, 0.35, 0.1) : std(0x7a5a3a, 0.7); box(G, 0.7, 1.0, 2.2, cm, COUNTER.x - 0.3, 0.5, COUNTER.z, true); box(G, 0.85, 0.06, 2.35, std(v >= 2 ? 0x202428 : 0x9a8060, 0.25, 0.2), COUNTER.x - 0.28, 1.03, COUNTER.z);
  box(G, 0.2, 0.18, 0.28, std(0x222, 0.4, 0.3, 0x113322), COUNTER.x - 0.3, 1.15, COUNTER.z + 0.4);
  if (v >= 2) { box(G, 0.08, 0.05, 2.2, std(0x6a4a2e, 0.5), W0 + 0.08, 1.5, COUNTER.z); box(G, 0.08, 0.05, 2.2, std(0x6a4a2e, 0.5), W0 + 0.08, 1.9, COUNTER.z);
    for (let i = 0; i < 9; i++) { const c = [0x2e7d32, 0x8d6e63, 0x1565c0, 0xb71c1c][i % 4]; box(G, 0.1, 0.28, 0.1, std(c, 0.2, 0.1), W0 + 0.15, 1.67 + (i % 2) * 0.4, COUNTER.z - 0.9 + i * 0.22); } }
  if (v >= 3) { for (let i = 0; i < 3; i++) { const p = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.75), new THREE.MeshBasicMaterial({ map: artTex(i + 1) })); p.position.set(-0.4 + i * 3.4, 1.9, Z0 + 0.03); G.add(p); box(G, 1.08, 0.83, 0.03, std(0x3b2412, 0.4), -0.4 + i * 3.4, 1.9, Z0 + 0.0); }
    for (const [px, pz] of [[W0 + 0.4, Z1 - 0.5], [W1 - 0.4, Z0 + 0.5]]) { const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.15, 0.4, 10), lam(0x6d4c41)); pot.position.set(px, 0.2, pz); G.add(pot); for (let k = 0; k < 4; k++) { const lf = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), lam(0x2e7d32)); lf.position.set(px + rr(-0.12, 0.12), 0.6 + k * 0.2, pz + rr(-0.12, 0.12)); G.add(lf); } } }
  if (v >= 4) { for (let i = 0; i < 3; i++) { const wn = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.3), new THREE.MeshBasicMaterial({ color: [0x6fa8ff, 0xffb46a, 0x8f7bff][i] })); wn.rotation.y = Math.PI / 2; wn.position.set(W0 + 0.01, 1.8, 0.4 + i * 3.0); G.add(wn); }
    box(G, W1 - W0 - 1, 0.08, 0.08, new THREE.MeshBasicMaterial({ color: 0x35f0b0 }), cx, 3.0, Z0 + 0.12); }
  if (v >= 5) { box(G, 0.5, 2.2, 3.4, std(0x1a1a22, 0.2, 0.3), W1 - 0.4, 1.1, Z0 + 2.2); box(G, 0.04, 2.0, 3.2, new THREE.MeshStandardMaterial({ color: 0x9fd3ff, transparent: true, opacity: 0.18, roughness: 0.05 }), W1 - 0.14, 1.1, Z0 + 2.2);
    for (let i = 0; i < 3; i++) box(G, 0.45, 0.04, 3.2, std(0x444, 0.4), W1 - 0.38, 0.5 + i * 0.6, Z0 + 2.2);
    const tg = new THREE.MeshStandardMaterial({ color: 0xffd34d, roughness: 0.25, metalness: 0.9 });
    for (let i = 0; i < Math.min(12, S.trophies); i++) { const r = Math.floor(i / 4), c = i % 4; const cp = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.03, 0.14, 8), tg); cp.position.set(W1 - 0.38, 0.62 + r * 0.6, Z0 + 0.9 + c * 0.7); G.add(cp); }
    box(G, 1.2, 0.5, 2.0, std(0x6a1b1b, 0.7), W1 - 1.0, 0.25, (Z0 + Z1) / 2 + 1.5, true); box(G, 0.3, 0.7, 2.0, std(0x6a1b1b, 0.7), W1 - 0.4, 0.45, (Z0 + Z1) / 2 + 1.5, true);
    const sc = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 1.2), new THREE.MeshBasicMaterial({ map: ctex(256, 96, (x, w, h) => { x.fillStyle = '#071018'; x.fillRect(0, 0, w, h); x.fillStyle = '#35f0b0'; x.font = 'bold 40px sans-serif'; x.textAlign = 'center'; x.fillText('LIVE  9-BALL', w / 2, 58); }) })); sc.position.set(6.0, 2.2, Z0 + 0.02); G.add(sc); }
  hl.visible = true; G.add(hl);
}
const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 0.9), new THREE.MeshBasicMaterial({ map: signT })); drawSign();
const hl = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2 + 0.9, HZ * 2 + 0.9), new THREE.MeshBasicMaterial({ color: 0xffdd55, transparent: true, opacity: 0.2, depthWrite: false }));
hl.rotation.x = -Math.PI / 2; hl.position.y = 0.014;

// ===== Meja =====
const tpos = i => new THREE.Vector3((i % 2) * 4.4, 0, Math.floor(i / 2) * 3.2);
const stickGeo = new THREE.CylinderGeometry(0.009, 0.016, 1.5, 8), stickMat = std(0xd9b27c, 0.4);
const poolGeo = new THREE.PlaneGeometry(3.4, 2.2), poolMat = new THREE.MeshBasicMaterial({ map: poolTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
function buildTable(i) {
  const g = new THREE.Group(); g.position.copy(tpos(i)); g.userData.i = i;
  const fm = new THREE.MeshStandardMaterial({ map: woodFrame, color: FRAME[0], roughness: 0.4, metalness: 0.1 });
  const cm = new THREE.MeshStandardMaterial({ map: clothTex(0), roughness: 0.95, emissive: 0x0a2a14, emissiveIntensity: 0.35 });
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2, HZ * 2), cm); cloth.rotation.x = -Math.PI / 2; cloth.position.y = TOP; cloth.receiveShadow = true; g.add(cloth);
  const ad = (w, h, d, mat, x, y, z) => box(g, w, h, d, mat, x, y, z, true);
  ad(HX * 2 + 0.44, 0.16, HZ * 2 + 0.44, fm, 0, 0.78, 0);
  const rail = [[0, HZ + 0.11, HX * 2 + 0.44, 0.22], [0, -HZ - 0.11, HX * 2 + 0.44, 0.22], [HX + 0.11, 0, 0.22, HZ * 2], [-HX - 0.11, 0, 0.22, HZ * 2]];
  rail.forEach(r => ad(r[2], 0.12, r[3], fm, r[0], 0.93, r[1]));
  const cush = std(0x1d5a33, 0.9);
  [[0, HZ + 0.03, HX * 2 - 0.5, 0.06], [0, -HZ - 0.03, HX * 2 - 0.5, 0.06]].forEach(r => ad(r[2], 0.06, r[3], cush, r[0], 0.92, r[1]));
  [[HX + 0.03, 0, 0.06, HZ * 2 - 0.3], [-HX - 0.03, 0, 0.06, HZ * 2 - 0.3]].forEach(r => ad(r[2], 0.06, r[3], cush, r[0], 0.92, r[1]));
  ad(0.3, 0.72, HZ * 2 - 0.2, fm, -HX * 0.55, 0.36, 0); ad(0.3, 0.72, HZ * 2 - 0.2, fm, HX * 0.55, 0.36, 0);
  const trimM = std(0xffd34d, 0.25, 0.9); const trim = ad(HX * 2 + 0.46, 0.03, HZ * 2 + 0.46, trimM, 0, 0.86, 0); trim.visible = false;
  const pool = new THREE.Mesh(poolGeo, poolMat); pool.rotation.x = -Math.PI / 2; pool.position.y = 0.02; g.add(pool);
  const stick = new THREE.Mesh(stickGeo, stickMat); stick.castShadow = CAST; stick.visible = false; g.add(stick);
  const bm = []; for (let n = 0; n <= 9; n++) { const b = new THREE.Mesh(ballGeo, ballMat[n]); b.castShadow = CAST; g.add(b); bm.push(b); }
  scene.add(g);
  return { i, group: g, fm, cm, trim, stick, bm, ctl: null, m: null, idle: E.newMatch(), butt: new THREE.Vector3(), tip: new THREE.Vector3() };
}
function styleTable(t) { const l = Math.min(S.tables[t.i], MAX_LV) - 1; t.fm.color.setHex(FRAME[l]); t.fm.roughness = Math.max(0.08, 0.45 - l * 0.04); t.fm.metalness = l >= 4 ? 0.6 : 0.1; t.cm.map = clothTex(l); t.cm.needsUpdate = true; t.trim.visible = l >= 4; }
function syncTables() { while (tables.length < S.tables.length) tables.push(buildTable(tables.length)); tables.forEach(styleTable); }
function setBalls(tb, dt) {
  const m = tb.m || tb.idle;
  for (const b of m.balls) {
    const me = tb.bm[b.n]; me.visible = b.alive; me.position.set(b.x, BALL_Y, b.z);
    const sp = Math.hypot(b.vx, b.vz); if (b.alive && sp > 0.01 && dt) { me.rotateOnWorldAxis(_ax.set(b.vz / sp, 0, -b.vx / sp), sp * dt / R); }
  }
}
const _ax = new THREE.Vector3(), _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3(), _v3 = new THREE.Vector3();

// ===== Karakter 3D =====
const GEO = { leg: new THREE.CylinderGeometry(0.07, 0.06, 0.88, 8), torso: new THREE.CylinderGeometry(0.17, 0.15, 0.62, 10), head: new THREE.SphereGeometry(0.12, 14, 12), hair: new THREE.SphereGeometry(0.13, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), arm: new THREE.CylinderGeometry(0.04, 0.035, 1, 6), eye: new THREE.SphereGeometry(0.014, 6, 4), shoe: new THREE.BoxGeometry(0.1, 0.06, 0.2) };
const matC = {}; const mat = c => matC[c] || (matC[c] = new THREE.MeshLambertMaterial({ color: c }));
const SHL = new THREE.Vector3(-0.21, 0.54, 0), SHR = new THREE.Vector3(0.21, 0.54, 0);
function mkChar(L) {
  const g = new THREE.Group(), upper = new THREE.Group(); upper.position.y = 0.88; g.add(upper);
  const mk = (geo, c, x, y, z, par) => { const m = new THREE.Mesh(geo, mat(c)); m.position.set(x, y, z); m.castShadow = CAST; par.add(m); return m; };
  const legL = new THREE.Group(), legR = new THREE.Group(); legL.position.set(-0.09, 0.88, 0); legR.position.set(0.09, 0.88, 0); g.add(legL); g.add(legR);
  mk(GEO.leg, L.pants, 0, -0.44, 0, legL); mk(GEO.leg, L.pants, 0, -0.44, 0, legR); mk(GEO.shoe, 0x181818, 0, -0.86, 0.04, legL); mk(GEO.shoe, 0x181818, 0, -0.86, 0.04, legR);
  mk(GEO.torso, L.shirt, 0, 0.31, 0, upper); mk(GEO.head, L.skin, 0, 0.8, 0, upper); mk(GEO.hair, L.hair, 0, 0.82, -0.01, upper);
  mk(GEO.eye, 0x111111, -0.045, 0.82, 0.108, upper); mk(GEO.eye, 0x111111, 0.045, 0.82, 0.108, upper);
  const armL = mk(GEO.arm, L.shirt, 0, 0, 0, upper), armR = mk(GEO.arm, L.shirt, 0, 0, 0, upper);
  const ch = { g, upper, legL, legR, armL, armR, ph: Math.random() * 6, lean: 0, leanT: 0, walking: false, hw: null, path: [], speed: 1.5, hr: new THREE.Vector3(), hl: new THREE.Vector3() };
  scene.add(g); chars.push(ch); return ch;
}
function killChar(ch) { scene.remove(ch.g); const i = chars.indexOf(ch); if (i >= 0) chars.splice(i, 1); }
function limb(m, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz) || 1e-3;
  m.position.set((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2); m.scale.set(1, L, 1); m.quaternion.setFromUnitVectors(UP, _v3.set(dx / L, dy / L, dz / L));
}
function reach(a, h) { const d = Math.hypot(h.x - a.x, h.y - a.y, h.z - a.z); if (d > 0.8) { const k = 0.8 / d; h.set(a.x + (h.x - a.x) * k, a.y + (h.y - a.y) * k, a.z + (h.z - a.z) * k); } }
function animChar(ch, dt) {
  ch.lean += (ch.leanT - ch.lean) * Math.min(1, dt * 8); ch.upper.rotation.x = ch.lean; ch.leanT = 0;
  const mv = ch.walking ? 1 : 0; ch.ph += dt * (mv ? 8 : 1.5);
  ch.legL.rotation.x = Math.sin(ch.ph) * 0.65 * mv; ch.legR.rotation.x = -Math.sin(ch.ph) * 0.65 * mv;
  ch.upper.position.y = 0.88 + (mv ? Math.abs(Math.sin(ch.ph)) * 0.02 : Math.sin(ch.ph) * 0.004);
  if (ch.hw) { ch.g.updateMatrixWorld(true); ch.upper.worldToLocal(ch.hr.copy(ch.hw.r)); ch.upper.worldToLocal(ch.hl.copy(ch.hw.l)); reach(SHR, ch.hr); reach(SHL, ch.hl); ch.hw = null; }
  else { const s = Math.sin(ch.ph) * 0.28 * mv, y = -0.5 + Math.sin(ch.ph * 0.5) * 0.01; ch.hr.set(0.22, 0.54 + y, -s + 0.02); ch.hl.set(-0.22, 0.54 + y, s + 0.02); }
  limb(ch.armR, SHR, ch.hr); limb(ch.armL, SHL, ch.hl); ch.walking = false;
}
function walkTo(ch, tx, tz, dt, sp) {
  const dx = tx - ch.g.position.x, dz = tz - ch.g.position.z, d = Math.hypot(dx, dz);
  if (d < 0.06) return true;
  const st = Math.min(d, (sp || ch.speed) * dt); ch.g.position.x += dx / d * st; ch.g.position.z += dz / d * st; ch.walking = true; faceDir(ch, Math.atan2(dx, dz), dt); return false;
}
function faceDir(ch, a, dt) { let da = a - ch.g.rotation.y; da = Math.atan2(Math.sin(da), Math.cos(da)); ch.g.rotation.y += da * Math.min(1, dt * 10); }
function faceAt(ch, x, z, dt) { faceDir(ch, Math.atan2(x - ch.g.position.x, z - ch.g.position.z), dt); }
function walkPath(ch, dt) { if (!ch.path.length) return true; const t = ch.path[0]; if (walkTo(ch, t.x, t.z, dt)) ch.path.shift(); return !ch.path.length; }

const TYPES = [
  { n: 'Anak Muda', shirt: [0xc0392b, 0x2980b9, 0x16a085], pants: 0x2f4a7a, sk: [0.3, 0.55], pay: 1 },
  { n: 'Karyawan', shirt: [0xecf0f1, 0xaed6f1, 0xf9e79f], pants: 0x2c3e50, sk: [0.4, 0.65], pay: 1.15 },
  { n: 'Pemain Pro', shirt: [0x111111, 0x1b5e20], pants: 0x151515, sk: [0.75, 0.92], pay: 1.6 },
  { n: 'Tamu VIP', shirt: [0x1c1c24, 0x5b2c6f], pants: 0x1c1c24, sk: [0.5, 0.8], pay: 2.2 },
  { n: 'Influencer', shirt: [0xff6fa5, 0xffd166, 0x6ee7b7], pants: 0xe8e8e8, sk: [0.3, 0.6], pay: 1.4 }
];
const SKIN = [0xf1c27d, 0xc68642, 0x8d5524, 0xe0ac69], HAIR = [0x111111, 0x2b1a0e, 0x4a3320, 0x6b4a2a];
const lookOf = t => ({ shirt: pick(t.shirt), pants: t.pants, skin: pick(SKIN), hair: pick(HAIR) });
function pickType() { const w = [3, 2, 0.6 + S.venue * 0.4, 0.2 + S.venue * 0.35, 1]; let r = Math.random() * w.reduce((a, b) => a + b, 0); for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0) return TYPES[i]; } return TYPES[0]; }

// ===== Pengendali pertandingan =====
const SPAWN = { x: -7, z: DOOR_Z }, DOORIN = { x: -2.8, z: DOOR_Z };
const standby = (tb, k) => { const p = tb.group.position; return k === 0 ? { x: p.x - 0.95, z: p.z + HZ + 0.95 } : { x: p.x + 0.95, z: p.z - HZ - 0.95 }; };
function mkCtl(tb, pl0, pl1, human) {
  const c = { tb, pl: [pl0, pl1], ch: [], state: 'enter', ph: '', t: 0, s: 0, m: null, ang: 0, angS: 0, power: 0.5, spin: 0, speed: 2, gap: 0.12, elapsed: 0, human: human ? 0 : -1, plan: null, tp: new THREE.Vector3(), opts: null, done: false };
  [pl0, pl1].forEach((p, k) => { const ch = mkChar(p.look); ch.g.position.set(SPAWN.x, 0, SPAWN.z + k * 0.7); ch.g.rotation.y = Math.PI / 2; const sb = standby(tb, k); ch.path = [{ x: DOORIN.x, z: DOORIN.z + k * 0.5 }, sb]; ch.speed = 1.6; c.ch.push(ch); });
  tb.ctl = c; ctls.push(c); return c;
}
function removeCtl(c) { c.ch.forEach(killChar); const i = ctls.indexOf(c); if (i >= 0) ctls.splice(i, 1); c.tb.ctl = null; c.tb.m = null; c.tb.idle = E.newMatch(); c.tb.stick.visible = false; if (PL === c) exitPlayUI(); }
function startNPC(tb) {
  const t0 = pickType(), t1 = pickType(), n0 = pick(NAMES); let n1 = pick(NAMES); if (n1 === n0) n1 = 'Pemain';
  mkCtl(tb, { name: n0, type: t0, skill: rr(t0.sk[0], t0.sk[1]), look: lookOf(t0) }, { name: n1, type: t1, skill: rr(t1.sk[0], t1.sk[1]), look: lookOf(t1) }, false);
}
function startHuman(tb, opp, opts) {
  if (tb.ctl) removeCtl(tb.ctl);
  const me = { name: S.name || 'Kamu', human: true, skill: 1, look: { shirt: 0x1f6feb, pants: 0x1b2a49, skin: 0xe0ac69, hair: 0x111111 } };
  const t = pick(TYPES); opp.look = opp.look || lookOf(t);
  const c = mkCtl(tb, me, opp, true); c.opts = opts || {}; PL = c; sel = tb.i; enterPlayUI(); return c;
}
const worldOf = (tb, x, z, out) => out.set(tb.group.position.x + x, 0, tb.group.position.z + z);
function standPos(tb, cu, ang, out) {
  const dx = Math.cos(ang), dz = Math.sin(ang); let x = cu.x - dx * (R + 0.15 + 1.47), z = cu.z - dz * (R + 0.15 + 1.47);
  for (let i = 0; i < 16 && Math.abs(x) < HX + 0.34 && Math.abs(z) < HZ + 0.34; i++) { x -= dx * 0.12; z -= dz * 0.12; }
  return worldOf(tb, x, z, out);
}
function setStick(tb, cu, ang, gap, vis) {
  const s = tb.stick; s.visible = vis; if (!vis) return;
  const dx = Math.cos(ang), dz = Math.sin(ang), tx = cu.x - dx * (R + gap), tz = cu.z - dz * (R + gap), ty = BALL_Y + 0.005, bx = tx - dx * 1.47, bz = tz - dz * 1.47, by = ty + 0.2;
  s.position.set((tx + bx) / 2, (ty + by) / 2, (tz + bz) / 2); const L = Math.hypot(tx - bx, ty - by, tz - bz); s.quaternion.setFromUnitVectors(UP, _v3.set((tx - bx) / L, (ty - by) / L, (tz - bz) / L));
  tb.butt.set(bx, by, bz); tb.tip.set(tx, ty, tz);
}
const _hw = { r: new THREE.Vector3(), l: new THREE.Vector3() };
function poseAim(c, ch, cu, ang, gap) {
  const tb = c.tb, p = tb.group.position; setStick(tb, cu, ang, gap, true);
  const bx = tb.butt.x, by = tb.butt.y, bz = tb.butt.z, k = 0.4 / 1.5, dx = Math.cos(ang), dz = Math.sin(ang);
  _hw.r.set(p.x + bx + (tb.tip.x - bx) * k, by + (tb.tip.y - by) * k, p.z + bz + (tb.tip.z - bz) * k);
  _hw.l.set(p.x + cu.x - dx * 0.32, TOP + 0.04, p.z + cu.z - dz * 0.32);
  ch.hw = _hw; ch.leanT = 0.6;
}
function lowestAng(m) { const cu = E.cue(m), t = E.ball(m, E.lowest(m)); return Math.atan2(t.z - cu.z, t.x - cu.x); }
function say(c, txt) { if (c.human >= 0) toast(txt); else floatText(_v1.set(c.tb.group.position.x, 1.8, c.tb.group.position.z), txt, '#ffd166'); }
function startThink(c) {
  const m = c.m, me = m.turn, p = c.pl[me], cu = E.cue(m); c.s = 0;
  if (c.human === me) { c.ph = m.inHand ? 'place' : 'human'; c.ang = lowestAng(m); c.angS = c.ang; c.power = 0.5; if (m.inHand) toast('Bola putih di tangan: geser untuk memindah, lalu tekan Letakkan'); return; }
  const a = E.aiShot(m, p.skill); if (a.place) { cu.x = a.place.x; cu.z = a.place.z; m.inHand = false; }
  c.plan = a; c.ang = a.ang; c.angS = a.ang; c.speed = a.speed; c.spin = a.spin; c.t = rr(1.0, 2.2) * (p.skill > 0.7 ? 0.8 : 1.2); c.ph = 'think';
}
function afterShot(c) {
  const m = c.m, L = m.last;
  if (L.foul) say(c, 'FOUL · ' + L.reason); else if (L.pots.length) say(c, '+ bola ' + L.pots.join(', '));
  if (c.human === L.who && L.pots.length) { S.pots += L.pots.length; prog('pot', L.pots.length); }
  if (m.phase === 'over') { onOver(c); return; }
  startThink(c);
}
function onOver(c) {
  c.state = 'end'; c.t = c.human >= 0 ? 0.4 : 2.2; c.tb.stick.visible = false; const w = c.m.winner; sfx('win', 2);
  if (c.human >= 0) { const won = w === c.human; humanResult(c, won); }
  else {
    const tb = c.tb, mult = (c.pl[0].type.pay + c.pl[1].type.pay) / 2, fee = Math.round(rate(S.tables[tb.i]) * Math.max(40, c.elapsed) * 1.5 * mult * rr(0.9, 1.1));
    addCash(fee); S.visits++; prog('visit', 1); floatText(_v1.set(tb.group.position.x, 1.9, tb.group.position.z), '+$' + fmt(fee), '#7dff9a');
  }
}
function consume(c, loud) {
  const m = c.m; for (const e of m.events) { const v = loud ? 1 : 0.35; if (e.t === 'click') sfx('click', Math.min(3, e.v) * v); else if (e.t === 'rail') sfx('rail', 1 * v); else if (e.t === 'pot') sfx('pot', 2 * v); else if (e.t === 'cue') sfx('cue', 2 * v); } m.events.length = 0;
}
function updCtl(c, dt) {
  const tb = c.tb, m = c.m;
  if (c.state === 'enter') { let ok = true; for (const ch of c.ch) if (!walkPath(ch, dt)) ok = false; if (ok) { c.state = 'rack'; c.t = 0.8; } return; }
  if (c.state === 'rack') { c.t -= dt; c.ch.forEach((ch, k) => { const sb = standby(tb, k); faceAt(ch, tb.group.position.x, tb.group.position.z, dt); }); if (c.t <= 0) { c.m = tb.m = E.newMatch(c.pl[0], c.pl[1]); c.state = 'play'; startThink(c); } return; }
  if (c.state === 'end') { c.t -= dt; if (c.human < 0 && c.t <= 0) endCtl(c); if (c.human >= 0 && c.t <= -99) endCtl(c); return; }
  if (c.state === 'leave') { let ok = true; for (const ch of c.ch) if (!walkPath(ch, dt)) ok = false; if (ok) removeCtl(c); return; }
  c.elapsed += dt;
  const me = m.turn, ch = c.ch[me], ot = c.ch[1 - me], sb = standby(tb, 1 - me), cu = E.cue(m);
  walkTo(ot, sb.x, sb.z, dt, 1.6); faceAt(ot, tb.group.position.x, tb.group.position.z, dt);
  if (c.ph === 'think' || c.ph === 'aim' || c.ph === 'human' || c.ph === 'stroke') {
    c.angS += (Math.atan2(Math.sin(c.ang - c.angS), Math.cos(c.ang - c.angS))) * Math.min(1, dt * 12);
    const a = c.ph === 'think' || c.ph === 'aim' ? c.ang : c.angS; standPos(tb, cu, a, c.tp);
    const arrived = walkTo(ch, c.tp.x, c.tp.z, dt, 2.2);
    if (arrived || c.ph === 'stroke') faceDir(ch, a === undefined ? 0 : Math.atan2(Math.cos(a), Math.sin(a)), dt);
  }
  if (c.ph === 'think') { c.t -= dt; const d = Math.hypot(ch.g.position.x - c.tp.x, ch.g.position.z - c.tp.z); if (c.t <= 0 && d < 0.15) { c.ph = 'aim'; c.t = rr(0.5, 1.0); } }
  else if (c.ph === 'aim') { poseAim(c, ch, cu, c.ang, 0.12); c.t -= dt; if (c.t <= 0) { c.ph = 'stroke'; c.s = 0; } }
  else if (c.ph === 'human') { c.gap = 0.1 + c.power * 0.12; poseAim(c, ch, cu, c.angS, c.gap); }
  else if (c.ph === 'place') { setStick(tb, cu, 0, 0, false); }
  else if (c.ph === 'stroke') {
    c.s += dt; const g0 = c.ph === 'stroke' && c.human === me ? 0.1 + c.power * 0.12 : 0.12, peak = g0 + 0.12 + c.speed * 0.03; let gap;
    if (c.s < 0.5) gap = g0 + (peak - g0) * (1 - Math.pow(1 - c.s / 0.5, 2)); else gap = Math.max(0, peak * (1 - (c.s - 0.5) / 0.1));
    poseAim(c, ch, cu, c.human === me ? c.angS : c.ang, gap);
    if (c.s >= 0.6) { E.shoot(m, c.human === me ? c.angS : c.ang, c.speed, c.spin); c.ph = 'roll'; c.s = 0; }
  }
  else if (c.ph === 'roll') {
    c.s += dt; if (c.s > 0.35) tb.stick.visible = false; else poseAim(c, ch, cu, c.human === me ? c.angS : c.ang, 0);
    E.step(m, dt); consume(c, c.human >= 0);
    if (m.phase !== 'roll') afterShot(c);
  }
}
function endCtl(c) {
  c.state = 'leave'; c.tb.m = null; c.tb.idle = E.newMatch(); c.tb.stick.visible = false;
  c.ch.forEach((ch, k) => { ch.path = [{ x: DOORIN.x, z: DOORIN.z + k * 0.5 }, { x: SPAWN.x, z: SPAWN.z }]; ch.speed = 1.8; });
}

// ===== Staf =====
function syncStaff() {
  const defs = { kasir: { look: { shirt: 0x1f5fbf, pants: 0x222222, skin: 0xe0ac69, hair: 0x111111 } }, pelayan: { look: { shirt: 0xf4f4f4, pants: 0x111111, skin: 0xc68642, hair: 0x2b1a0e } }, bersih: { look: { shirt: 0x2e7d32, pants: 0x2e7d32, skin: 0xf1c27d, hair: 0x4a3320 } }, pelatih: { look: { shirt: 0xc62828, pants: 0x222222, skin: 0x8d5524, hair: 0x111111 } } };
  for (const k in defs) {
    const has = staffList.find(s => s.role === k), want = S.staff[k] > 0;
    if (want && !has) { const ch = mkChar(defs[k].look); const s = { role: k, ch, wp: 0, wait: 0 }; const p0 = tpos(0); if (k === 'kasir') ch.g.position.set(COUNTER.x + 0.7, 0, COUNTER.z); else if (k === 'pelatih') ch.g.position.set(p0.x + 1.9, 0, p0.z + 1.4); else ch.g.position.set(2.2, 0, 0.5); staffList.push(s); }
    else if (!want && has) { killChar(has.ch); staffList.splice(staffList.indexOf(has), 1); }
  }
}
function updStaff(dt) {
  for (const s of staffList) {
    const ch = s.ch, rows = ROWS[S.venue - 1];
    if (s.role === 'kasir') { faceDir(ch, -Math.PI / 2, dt); continue; }
    if (s.role === 'pelatih') { const p0 = tpos(0); faceAt(ch, p0.x, p0.z, dt); continue; }
    if (s.wait > 0) { s.wait -= dt; continue; }
    const lane = s.role === 'pelayan' ? 2.2 : 6.3, zs = []; for (let r = 0; r < rows; r++) zs.push(r * 3.2 + 0.2);
    const seq = s.role === 'pelayan' ? zs.concat(zs.slice().reverse()) : zs.slice().reverse().concat(zs); const wp = seq[s.wp % seq.length];
    if (walkTo(ch, lane, wp, dt, 1.1)) { s.wp++; s.wait = rr(1, 2.5); }
  }
}

// ===== Garis bantu bidikan =====
function mkLine(col, op) { const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]); const l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: op })); l.frustumCulled = false; l.visible = false; scene.add(l); return l; }
const L1 = mkLine(0xffffff, 0.85), L2 = mkLine(0xffd34d, 0.95), L3 = mkLine(0xffffff, 0.35);
const ghost = new THREE.Mesh(new THREE.SphereGeometry(R, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 })); ghost.visible = false; scene.add(ghost);
function setLine(l, ax, ay, az, bx, by, bz) { const p = l.geometry.attributes.position; p.setXYZ(0, ax, ay, az); p.setXYZ(1, bx, by, bz); p.needsUpdate = true; l.visible = true; }
function updAim() {
  L1.visible = L2.visible = L3.visible = ghost.visible = false;
  const c = PL; if (!c || !c.m || c.ph !== 'human' || c.m.turn !== c.human || c.m.phase !== 'aim' || !S.assist) return;
  const p = c.tb.group.position, cu = E.cue(c.m), pr = E.predict(c.m, c.angS), y = BALL_Y;
  const gx = pr.gx, gz = pr.gz; setLine(L1, p.x + cu.x, y, p.z + cu.z, p.x + gx, y, p.z + gz);
  if (pr.n !== null) { ghost.visible = true; ghost.position.set(p.x + gx, y, p.z + gz); const k = 0.35 + c.power * 0.6; setLine(L2, p.x + pr.bx, y, p.z + pr.bz, p.x + pr.bx + pr.tdx * k, y, p.z + pr.bz + pr.tdz * k); setLine(L3, p.x + gx, y, p.z + gz, p.x + gx + pr.cdx * 0.4, y, p.z + gz + pr.cdz * 0.4); }
}

// ===== UI =====
const PAYMENT_ENABLED = false; // true jika Google Play Billing sudah dipasang (isi window.onBuyGems)
const PACKS = [{ g: 50, rp: 5000 }, { g: 120, rp: 10000 }, { g: 350, rp: 25000 }, { g: 800, rp: 50000 }];
const DIFFS = [{ n: 'Mudah', ic: '🟢', sk: 0.35, m: 1, g: 0 }, { n: 'Sedang', ic: '🟡', sk: 0.55, m: 1.8, g: 1 }, { n: 'Sulit', ic: '🟠', sk: 0.75, m: 3, g: 2 }, { n: 'Pro', ic: '🔴', sk: 0.9, m: 5, g: 4 }];
const TOURS = [{ id: 'd', n: 'Turnamen Harian', size: 4, gems: 8, cd: 20 * 60e3, mult: 4.2, fee: () => Math.round(250 * Math.pow(3.2, S.venue - 1)) }, { id: 'w', n: 'Kejuaraan Mingguan', size: 8, gems: 30, cd: 60 * 60e3, mult: 9, fee: () => Math.round(1000 * Math.pow(3.2, S.venue - 1)) }];
const rupiah = n => 'Rp' + n.toLocaleString('id-ID');
const sheetEl = $('sheet'), sheetBody = $('sb');
const can = (c, cur) => (cur === 'g' ? S.gems : S.cash) >= c;
const btn = (a, label, cost, cur, x, cls) => `<button class="btn ${cls || (cur === 'g' ? 'g' : '')}" data-a="${a}" data-x="${x === undefined ? 0 : x}" data-cost="${cost}" data-cur="${cur}"${can(cost, cur) ? '' : ' disabled'}>${label}</button>`;
const card = (ic, t, sub, right, prog_, tint) => `<div class="card"><div class="ic ${tint || ''}">${ic}</div><div class="tx"><b>${t}</b><small>${sub}</small>${prog_ != null ? `<i class="bar"><u style="width:${Math.round(prog_ * 100)}%"></u></i>` : ''}</div><div class="rt">${right || ''}</div></div>`;
function spend(c, cur) { if (!can(c, cur)) return false; if (cur === 'g') S.gems -= c; else S.cash -= c; return true; }
function floatText(p, txt, col) {
  const v = p.clone().project(camera); if (v.z > 1) return;
  const d = document.createElement('div'); d.className = 'fl'; d.textContent = txt; if (col) d.style.color = col;
  d.style.left = ((v.x + 1) / 2 * innerWidth - 24) + 'px'; d.style.top = ((1 - v.y) / 2 * innerHeight) + 'px'; document.body.appendChild(d); setTimeout(() => d.remove(), 1200);
}
function modal(html, ok) { $('modal').style.display = 'flex'; $('mc').innerHTML = html + '<button class="btn big" id="mok">OK</button>'; $('mok').onclick = () => { $('modal').style.display = 'none'; if (ok) ok(); }; }

function tPlay() {
  const tb = tables[sel], busy = tb.ctl && !PL;
  let h = card('🎱', `Main 9-Ball di Meja ${sel + 1}`, busy ? 'Meja sedang dipakai pengunjung (mereka akan pergi)' : 'Lawan NPC · pukul bola urut dari angka terkecil, masukkan bola 9 untuk menang', '');
  h += '<h4>Pilih Lawan</h4>';
  DIFFS.forEach((d, i) => { h += card(d.ic, `Lawan ${d.n}`, `Hadiah menang ±$${fmt(Math.max(100, income()) * 120 * d.m)}${d.g ? ' + ' + d.g + '💎' : ''}`, `<button class="btn" data-a="play" data-x="${i}">Main</button>`); });
  return h + '<div class="note" style="color:#9fc">Tips: geser layar untuk membidik, atur KUAT dan EFEK, lalu tekan SODOK. Garis putih = arah, garis kuning = arah bola target.</div>';
}
function tTables() {
  const lv = S.tables[sel], cap = LVCAP[S.venue - 1], mx = lv >= cap, uc = upCost(lv), full = S.tables.length >= CAP[S.venue - 1], bc = buyCost();
  let h = '<div class="chips">' + S.tables.map((l, i) => `<button class="chip2 ${i === sel ? 'on' : ''}" data-a="selT" data-x="${i}">Meja ${i + 1} · Lv${l}</button>`).join('') + '</div>';
  h += card('🎱', `Meja ${sel + 1}: ${TNAME[lv - 1]}`, `Lv.${lv}/${cap} · +$${fmt(rate(lv))}/dtk`, lv >= MAX_LV ? '<span class="max">MAX</span>' : mx ? '<span class="max">Renovasi dulu</span>' : btn('upT', `⬆ $${fmt(uc)}`, uc, 'c'), lv / MAX_LV);
  h += card('➕', 'Tambah Meja Baru', `${S.tables.length}/${CAP[S.venue - 1]} meja${full && S.venue < 5 ? ' · renovasi lokasi untuk menambah' : ''}`, full ? '<span class="max">PENUH</span>' : btn('buyT', `$${fmt(bc)}`, bc, 'c'));
  return h;
}
function tBiz() {
  const pm = priceMult(); let h = '<h4>Lokasi</h4>';
  const vc = VCOST[S.venue];
  h += card('🏢', VEN[S.venue - 1], `Lokasi ${S.venue}/5 · maks ${CAP[S.venue - 1]} meja, meja maks Lv${LVCAP[S.venue - 1]}`, S.venue >= 5 ? '<span class="max">MAX</span>' : btn('renov', `Pindah $${fmt(vc)}`, vc, 'c'), S.venue / 5, 'gold');
  h += '<h4>Harga</h4>' + card('🏷️', 'Tarif Sewa Meja', `Tingkat ${S.price}/5 · bayaran ×${pm.toFixed(1)} · pengunjung ${S.price > 3 ? 'lebih jarang' : S.price < 3 ? 'lebih ramai' : 'normal'}`, '<button class="btn s" data-a="pr" data-x="-1">−</button><button class="btn s" data-a="pr" data-x="1">+</button>', S.price / 5);
  h += '<h4>Karyawan</h4>';
  for (const k in STAFF) { const F = STAFF[k], l = S.staff[k], c = stCost(k, l); h += card(F.ic, F.n, `Lv.${l}/5 · ${F.d}`, l >= 5 ? '<span class="max">MAX</span>' : btn('staff', `$${fmt(c)}`, c, 'c', k), l / 5); }
  h += '<h4>Fasilitas</h4>';
  for (const k in FAC) { const F = FAC[k], l = S.fac[k], c = facCost(k, l); h += card(F.ic, F.n, `Lv.${l}/${F.max} · ${F.d}`, l >= F.max ? '<span class="max">MAX</span>' : btn('fac', `$${fmt(c)}`, c, 'c', k), l / F.max); }
  return h + '<h4>Statistik</h4>' + card('📊', S.name || 'Bisnisku', `${S.visits} pertandingan pengunjung · ${S.wins} menang / ${S.losses} kalah · 🏆 ${S.trophies}`, '');
}
function roundName(n) { return n === 2 ? 'Final' : n === 4 ? 'Semifinal' : 'Perempat Final'; }
function tTour() {
  let h = '';
  const T = S.tour;
  if (T) {
    const def = TOURS.find(d => d.id === T.id), meIdx = 0, pos = T.alive.indexOf(meIdx), opp = T.pl[T.alive[pos ^ 1]];
    h += card('🏆', def.n, `${roundName(T.alive.length)} · hadiah juara $${fmt(T.prize)} + ${T.gems}💎`, '', null, 'gold');
    h += card('⚔️', `Lawan: ${opp.name}`, `Kemampuan ${Math.round(Math.min(0.95, opp.skill + T.round * 0.04) * 100)}% · main di Meja ${sel + 1}`, '<button class="btn" data-a="tplay" data-x="0">Main</button>');
    h += '<div class="note" style="color:#bcd">Peserta tersisa: ' + T.alive.map(i => T.pl[i].name).join(', ') + '</div><button class="btn s" style="width:auto;padding:8px 12px;margin-top:8px" data-a="tquit" data-x="0">Mundur</button>';
  } else {
    h += '<h4>Turnamen</h4>';
    TOURS.forEach((d, i) => { const f = d.fee(), cd = S.tcd[d.id] - Date.now(), rdy = cd <= 0; h += card('🏆', d.n, `${d.size} peserta · hadiah juara $${fmt(f * d.mult)} + ${d.gems}💎 + piala${rdy ? '' : ' · buka lagi ' + Math.ceil(cd / 60000) + ' mnt'}`, rdy ? btn('tour', `Daftar $${fmt(f)}`, f, 'c', i) : '<span class="max">⏳</span>'); });
  }
  h += '<h4>Misi Harian</h4>';
  S.mis.list.forEach((m, i) => { const d = MP.find(p => p.id === m.id); const rw = m.gem ? '10💎' : '$' + fmt(income() * 300); h += card('📋', d.t(m.need), `${Math.min(m.got, m.need)}/${m.need} · hadiah ${rw}`, m.claimed ? '<span class="max">✔</span>' : m.done ? `<button class="btn" data-a="claim" data-x="${i}">Klaim</button>` : '', Math.min(1, m.got / m.need)); });
  return h;
}
function tShop() {
  const rdy = Date.now() - S.daily >= 864e5, left = Math.ceil((864e5 - (Date.now() - S.daily)) / 36e5);
  let h = card('💎', 'Saldo Berlian', 'Untuk boost, paket uang, dan kosmetik', `<b>${S.gems} 💎</b>`);
  h += card('🎁', 'Hadiah Harian', rdy ? 'Gratis +20 berlian!' : `Klaim lagi ${left} jam lagi`, rdy ? '<button class="btn" data-a="daily" data-x="0">Klaim</button>' : '<span class="max">✔</span>');
  h += '<h4>Top Up Berlian</h4><div class="grid">' + PACKS.map((p, i) => `<button class="pack" data-a="topup" data-x="${i}"><b>💎 ${p.g}</b><span>${rupiah(p.rp)}</span></button>`).join('') + '</div>';
  if (!PAYMENT_ENABLED) h += '<div class="note">⚠ Mode demo: pembayaran belum terhubung ke Google Play Billing, jadi berlian diberikan gratis untuk uji coba.</div>';
  return h + '<h4>Toko Berlian</h4>' + card('⚡', 'Boost Pendapatan ×2', 'Aktif 10 menit (bisa ditumpuk)', btn('boost', '💎 30', 30, 'g')) + card('💰', 'Paket Uang', `±$${fmt(income() * 7200)} (2 jam pendapatan)`, btn('cash', '💎 40', 40, 'g'));
}
function tSet() {
  const qn = { auto: 'Otomatis (HD)', low: 'Rendah', mid: 'Sedang', high: 'Tinggi (HD)' }[S.quality];
  return card('✏️', 'Nama Bisnis', S.name || '-', '<button class="btn" data-a="rename" data-x="0">Ubah</button>')
    + card('🖥️', 'Kualitas Grafis', qn + ' · layar kurang lancar? pilih Rendah', '<button class="btn" data-a="quality" data-x="0">Ganti</button>')
    + card('🔊', 'Suara', S.mute ? 'Mati' : 'Hidup', '<button class="btn" data-a="mute" data-x="0">Ubah</button>')
    + card('📐', 'Garis Bantu Bidikan', S.assist ? 'Hidup' : 'Mati', '<button class="btn" data-a="assist" data-x="0">Ubah</button>')
    + card('🗑️', 'Hapus Semua Data', 'Mulai dari nol (tidak bisa dibatalkan)', '<button class="btn s" style="width:auto;padding:9px 12px" data-a="reset" data-x="0">Reset</button>')
    + '<div class="note" style="color:#9fc">Billiard Business Tycoon 3D · v0.3</div>';
}
const TABS = { tables: ['🎱 Meja', tTables], biz: ['🏪 Kelola Bisnis', tBiz], play: ['🎯 Main 1 vs 1', tPlay], tour: ['🏆 Turnamen & Misi', tTour], shop: ['💎 Top Up & Toko', tShop], set: ['⚙️ Pengaturan', tSet] };
function render() {
  document.querySelectorAll('.nv').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  sheetEl.classList.toggle('open', !!tab); document.body.classList.toggle('sheetopen', !!tab);
  if (!tab) return; $('st').textContent = TABS[tab][0]; const top = sheetBody.scrollTop; sheetBody.innerHTML = TABS[tab][1](); sheetBody.scrollTop = top;
}
function afford() { sheetBody.querySelectorAll('[data-cost]').forEach(b => { b.disabled = !can(+b.dataset.cost, b.dataset.cur); }); }
function hud() {
  $('bn').textContent = S.name || 'Billiard Business'; $('rk').textContent = VEN[S.venue - 1] + ' · ' + '★'.repeat(stars()) + '☆'.repeat(5 - stars());
  $('cash').textContent = '$' + fmt(S.cash); $('gem').textContent = S.gems; $('inc').textContent = '+$' + fmt(income()) + '/dtk';
  const b = $('bst'); if (boosted()) { b.style.display = 'block'; b.textContent = '⚡ ×2 · ' + Math.ceil((S.boostUntil - Date.now()) / 60000) + ' mnt'; } else b.style.display = 'none';
  afford(); const p = tpos(sel); hl.position.x = p.x; hl.position.z = p.z;
}
function refresh() { hud(); if (tab === 'tables' || tab === 'play') render(); }

// turnamen
function startTour(def) {
  if (S.tcd[def.id] > Date.now() || S.tour) return; const fee = def.fee(); if (!spend(fee, 'c')) return;
  const pl = [{ name: S.name || 'Kamu', skill: 1, me: true }], names = NAMES.slice().sort(() => Math.random() - 0.5), base = 0.33 + 0.08 * S.venue;
  for (let i = 1; i < def.size; i++) pl.push({ name: names[i], skill: Math.min(0.93, base + rr(-0.05, 0.12)) });
  S.tour = { id: def.id, size: def.size, round: 0, pl, alive: pl.map((_, i) => i).sort(() => Math.random() - 0.5), prize: Math.round(fee * def.mult), gems: def.gems, fee };
}
function endTour(won, champion) {
  const T = S.tour, def = TOURS.find(d => d.id === T.id); S.tcd[T.id] = Date.now() + def.cd; S.tour = null;
  if (champion) { addCash(T.prize); S.gems += T.gems; S.trophies++; S.wins++; buildVenue(); }
}
function tourResult(c, won) {
  const T = S.tour; let html;
  if (!won) { S.losses++; html = '<h2>Tersingkir</h2><p>Kamu kalah di ' + roundName(T.alive.length) + '. Coba lagi di turnamen berikutnya!</p>'; endTour(false, false); }
  else {
    S.wins++; prog('win', 1); const na = [];
    for (let p = 0; p < T.alive.length; p += 2) { const a = T.alive[p], b = T.alive[p + 1]; if (a === 0 || b === 0) na.push(0); else { const sa = T.pl[a].skill, sb = T.pl[b].skill; na.push(Math.random() < sa / (sa + sb) ? a : b); } }
    T.alive = na; T.round++;
    if (na.length === 1) { html = `<h2>🏆 JUARA!</h2><p>Hadiah: $${fmt(T.prize)} + ${T.gems}💎 + piala emas untuk lemari pajangan!</p>`; endTour(true, true); }
    else html = `<h2>Menang!</h2><p>Kamu lolos ke ${roundName(na.length)}. Buka tab Turnamen untuk lanjut.</p>`;
  }
  modal(html, () => { PL = null; exitPlayUI(); endCtl(c); hud(); save(); });
}
function humanResult(c, won) {
  const o = c.opts || {}; if (o.tour) { tourResult(c, won); return; }
  let html;
  if (won) { const d = o.diff || DIFFS[0], cash = Math.round(Math.max(100, income()) * 120 * d.m); addCash(cash); S.gems += d.g; S.wins++; prog('win', 1); html = `<h2>🏆 Kamu Menang!</h2><p>Hadiah: $${fmt(cash)}${d.g ? ' + ' + d.g + '💎' : ''}</p>`; }
  else { S.losses++; html = '<h2>Kalah</h2><p>Latih lagi atau coba lawan yang lebih mudah.</p>'; }
  modal(html, () => { PL = null; exitPlayUI(); endCtl(c); hud(); save(); });
}

function act(a, x) {
  if (a === 'selT') sel = x;
  else if (a === 'upT') { const lv = S.tables[sel]; if (lv < LVCAP[S.venue - 1] && spend(upCost(lv), 'c')) { S.tables[sel]++; styleTable(tables[sel]); prog('up', 1); toast(`Meja ${sel + 1} naik ke Lv.${S.tables[sel]}`); } }
  else if (a === 'buyT') { if (S.tables.length < CAP[S.venue - 1] && spend(buyCost(), 'c')) { S.tables.push(1); syncTables(); sel = S.tables.length - 1; toast('Meja baru dibeli!'); } }
  else if (a === 'renov') { if (S.venue < 5 && spend(VCOST[S.venue], 'c')) { S.venue++; buildVenue(); syncStaff(); toast('Selamat pindah ke ' + VEN[S.venue - 1] + '!'); } }
  else if (a === 'staff') { if (S.staff[x] < 5 && spend(stCost(x, S.staff[x]), 'c')) { S.staff[x]++; syncStaff(); toast(STAFF[x].n + ' naik ke Lv.' + S.staff[x]); } }
  else if (a === 'fac') { const F = FAC[x], l = S.fac[x]; if (l < F.max && spend(facCost(x, l), 'c')) { S.fac[x]++; toast(F.n + ' naik ke Lv.' + S.fac[x]); } }
  else if (a === 'pr') S.price = Math.max(1, Math.min(5, S.price + x));
  else if (a === 'daily') { if (Date.now() - S.daily >= 864e5) { S.gems += 20; S.daily = Date.now(); toast('+20 💎 hadiah harian'); } }
  else if (a === 'boost') { if (spend(30, 'g')) { S.boostUntil = Math.max(Date.now(), S.boostUntil) + 10 * 60000; toast('⚡ Boost ×2 aktif 10 menit'); } }
  else if (a === 'cash') { if (spend(40, 'g')) { const g = Math.round(income() * 7200); addCash(g); toast('+$' + fmt(g)); } }
  else if (a === 'topup') { const p = PACKS[x]; if (PAYMENT_ENABLED && window.onBuyGems) { window.onBuyGems(p, ok => { if (ok) { S.gems += p.g; save(); render(); hud(); toast('+' + p.g + ' 💎'); } }); return; } S.gems += p.g; toast(`Mode demo: +${p.g} 💎 (tanpa bayar)`); }
  else if (a === 'claim') { const m = S.mis.list[x]; if (m && m.done && !m.claimed) { m.claimed = true; if (m.gem) { S.gems += 10; toast('+10 💎'); } else { const g = Math.round(income() * 300); addCash(g); toast('+$' + fmt(g)); } } }
  else if (a === 'tour') startTour(TOURS[x]);
  else if (a === 'tquit') { if (confirm('Mundur dari turnamen? Biaya tidak dikembalikan.')) endTour(false, false); }
  else if (a === 'tplay') { const T = S.tour; if (T) { const pos = T.alive.indexOf(0), o = T.pl[T.alive[pos ^ 1]]; tab = null; startHuman(tables[sel], { name: o.name, skill: Math.min(0.95, o.skill + T.round * 0.04) }, { tour: true }); } }
  else if (a === 'play') { const d = DIFFS[x]; tab = null; startHuman(tables[sel], { name: pick(NAMES), skill: d.sk }, { diff: d }); }
  else if (a === 'rename') { const n = prompt('Nama bisnis:', S.name); if (n && n.trim()) { S.name = n.trim().slice(0, 24); drawSign(); } }
  else if (a === 'quality') { const o = ['auto', 'low', 'mid', 'high']; S.quality = o[(o.indexOf(S.quality) + 1) % 4]; save(); toast('Memuat ulang dengan kualitas baru...'); setTimeout(() => location.reload(), 600); return; }
  else if (a === 'mute') S.mute = !S.mute;
  else if (a === 'assist') S.assist = !S.assist;
  else if (a === 'reset') { if (confirm('Hapus semua progres?')) { window.__reset = true; try { localStorage.removeItem(SAVE); } catch (e) {} location.reload(); return; } }
  save(); render(); hud();
}
sheetBody.addEventListener('click', ev => { const b = ev.target.closest('[data-a]'); if (b && !b.disabled) act(b.dataset.a, isNaN(+b.dataset.x) ? b.dataset.x : +b.dataset.x); });
document.querySelectorAll('.nv').forEach(b => b.onclick = () => { tab = tab === b.dataset.tab ? null : b.dataset.tab; render(); hud(); });
$('gear').onclick = () => { tab = tab === 'set' ? null : 'set'; render(); };
$('sx').onclick = () => { tab = null; render(); };
if (S.name) $('intro').style.display = 'none';
$('go').onclick = () => { S.name = ($('nm').value || '').trim().slice(0, 24) || 'Billiard Bisnis Saya'; save(); drawSign(); $('intro').style.display = 'none'; hud(); toast('Bisnis "' + S.name + '" resmi dibuka! 🎉'); };

// ===== UI saat bermain =====
function enterPlayUI() { tab = null; render(); document.body.classList.add('playing'); $('ph').style.display = 'block'; phSig = ''; toast('Pemain & lawan sedang masuk...'); }
function exitPlayUI() { PL = null; document.body.classList.remove('playing'); $('ph').style.display = 'none'; }
let phSig = '', fine = false;
function phud() {
  const c = PL; if (!c || !c.m) { if (c) $('pmsg').textContent = 'Menunggu pemain...'; return; }
  const m = c.m, myTurn = m.turn === c.human && m.phase === 'aim', ctl = c.ph === 'human' && myTurn;
  const sig = [m.seq, m.turn, c.ph, m.pots.join(), E.lowest(m), S.assist, fine].join('|'); if (sig === phSig) return; phSig = sig;
  $('p0n').textContent = c.pl[0].name; $('p1n').textContent = c.pl[1].name; $('p0s').textContent = m.pots[0]; $('p1s').textContent = m.pots[1];
  $('pl0').classList.toggle('on', m.turn === 0); $('pl1').classList.toggle('on', m.turn === 1);
  const low = E.lowest(m); $('tray').innerHTML = m.balls.filter(b => b.n > 0).map(b => `<i class="tb ${b.alive ? '' : 'out'} ${b.n === low ? 'nx' : ''}" style="background:#${BALLC[b.n].toString(16).padStart(6, '0')}">${b.n}</i>`).join('');
  $('pmsg').textContent = c.ph === 'place' ? 'Geser untuk memindah bola putih, lalu tekan Letakkan' : ctl ? `Bidik bola ${low} · geser layar, atur KUAT, tekan SODOK` : `Giliran ${c.pl[m.turn].name}...`;
  $('fire').disabled = !ctl; $('bPlace').style.display = c.ph === 'place' ? 'block' : 'none'; $('bFine').classList.toggle('on', fine); $('bAssist').classList.toggle('on', S.assist);
}
$('fire').onclick = () => { const c = PL; if (c && c.ph === 'human' && c.m.turn === c.human && c.power > 0.03) { c.speed = 0.5 + c.power * 5.7; c.ph = 'stroke'; c.s = 0; phSig = ''; } };
$('bPlace').onclick = () => { const c = PL; if (c && c.ph === 'place') { c.m.inHand = false; c.ph = 'human'; c.ang = lowestAng(c.m); c.angS = c.ang; phSig = ''; } };
$('bFine').onclick = () => { fine = !fine; phSig = ''; };
$('bAssist').onclick = () => { S.assist = !S.assist; phSig = ''; save(); };
$('bExit').onclick = () => { const c = PL; if (c && confirm('Keluar dari pertandingan? Dianggap kalah.')) { c.state = 'end'; c.t = 9; humanResult(c, false); } };
function bindSlider(el, fn) {
  const f = e => { const r = el.getBoundingClientRect(); fn(Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height))); e.preventDefault(); };
  el.addEventListener('pointerdown', e => { el.setPointerCapture(e.pointerId); el._d = true; f(e); }); el.addEventListener('pointermove', e => { if (el._d) f(e); }); el.addEventListener('pointerup', () => { el._d = false; });
}
bindSlider($('pw'), v => { if (PL) { PL.power = v; $('pw').firstChild.style.height = v * 100 + '%'; } });
bindSlider($('sp'), v => { if (PL) { PL.spin = (v - 0.5) * 2; $('sp').lastChild.style.bottom = v * 100 + '%'; } });

// ===== Input kanvas =====
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -BALL_Y);
function groundAt(e) { ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera); const p = new THREE.Vector3(); return ray.ray.intersectPlane(plane, p) ? p : null; }
let drag = null; const dom = renderer.domElement;
dom.addEventListener('pointerdown', e => { drag = { lx: e.clientX, ly: e.clientY, moved: 0 }; });
dom.addEventListener('pointermove', e => {
  if (!drag) return; const dx = e.clientX - drag.lx; drag.lx = e.clientX; drag.moved += Math.abs(dx) + Math.abs(e.clientY - drag.ly); drag.ly = e.clientY;
  const c = PL; if (!c || !c.m) return;
  if (c.ph === 'human' && c.m.turn === c.human) c.ang += dx * 0.0055 * (fine ? 0.25 : 1);
  else if (c.ph === 'place') { const g = groundAt(e); if (g) { const cu = E.cue(c.m), p = c.tb.group.position, x = g.x - p.x, z = g.z - p.z; if (E.freeSpot(c.m, x, z)) { cu.x = x; cu.z = z; } } }
});
dom.addEventListener('pointerup', e => {
  const d = drag; drag = null; if (!d || PL || d.moved > 10) return;
  ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera);
  const hit = ray.intersectObjects(tables.map(t => t.group), true)[0];
  if (hit) { let o = hit.object; while (o && o.userData.i === undefined) o = o.parent; if (o) { sel = o.userData.i; refresh(); } }
});
dom.addEventListener('pointercancel', () => { drag = null; });

// ===== Kamera & loop =====
function resize() { renderer.setPixelRatio(prCur); renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
const tgtP = new THREE.Vector3(), tgtT = new THREE.Vector3();
function planCam() {
  const tv = Math.tan(camera.fov * Math.PI / 360), asp = camera.aspect;
  if (PL) {
    const c = PL, p = c.tb.group.position;
    if (c.m && (c.ph === 'human' || c.ph === 'stroke') && c.m.turn === c.human) {
      const cu = E.cue(c.m), a = c.angS, dx = Math.cos(a), dz = Math.sin(a);
      tgtP.set(p.x + cu.x - dx * 1.5, 1.05, p.z + cu.z - dz * 1.5); tgtT.set(p.x + cu.x + dx * 0.9, 0.82, p.z + cu.z + dz * 0.9);
    } else { const dist = Math.max(1.85 / (tv * asp), 1.5 / tv) + 0.2; tgtT.set(p.x, 0.85, p.z); tgtP.set(p.x, 0.85 + dist * 0.89, p.z + dist * 0.45); }
    return;
  }
  const ps = S.tables.map((_, i) => tpos(i)), xs = ps.map(p => p.x), zs = ps.map(p => p.z);
  const w = (Math.max(...xs) - Math.min(...xs)) / 2 + 2.3, d = (Math.max(...zs) - Math.min(...zs)) / 2 + 1.7;
  const dist = Math.max(w / (tv * asp), d / tv / 0.8) + 0.5, el = 58 * Math.PI / 180;
  tgtT.set((Math.max(...xs) + Math.min(...xs)) / 2 - 0.2, 0.8, (Math.max(...zs) + Math.min(...zs)) / 2 + 0.4); tgtP.copy(tgtT); tgtP.y += Math.sin(el) * dist; tgtP.z += Math.cos(el) * dist;
}
let last = performance.now(), vo = 0, hudT = 0, autoT = 0, spawnT = 3, fAcc = 0, fN = 0, warm = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const raw = Math.min(0.1, (now - last) / 1000), dt = Math.min(0.05, raw); last = now; sfxN = 0;
  warm += raw; if (warm > 3) { fAcc += raw; fN++; if (fAcc >= 2) { const avg = fAcc / fN; fAcc = 0; fN = 0; const cap = Math.min(window.devicePixelRatio || 1, QS.pr);
    if (avg > 1 / 38 && prCur > 1) { prCur = Math.max(1, prCur - 0.25); resize(); } else if (avg < 1 / 57 && prCur < cap) { prCur = Math.min(cap, prCur + 0.125); resize(); } } }
  for (let i = ctls.length - 1; i >= 0; i--) updCtl(ctls[i], dt);
  for (const tb of tables) setBalls(tb, tb.ctl && tb.ctl.ph === 'roll' ? dt : 0);
  updStaff(dt); for (const ch of chars) animChar(ch, dt);
  spawnT -= dt; if (spawnT <= 0) { const free = tables.filter(t => !t.ctl); if (!free.length) spawnT = 2; else { startNPC(pick(free)); spawnT = Math.max(2.5, 8 - stars() - 0.7 * S.fac.park) * (0.7 + 0.1 * S.price) * rr(0.8, 1.2); } }
  updAim(); planCam();
  const k = 1 - Math.exp(-dt * (PL ? 5 : 3)); camT.lerp(tgtT, k); camP.lerp(tgtP, k); camera.position.copy(camP); camera.lookAt(camT);
  const tvo = (tab && !PL) ? (sheetEl.offsetHeight + 60) * 0.5 : 0; vo += (tvo - vo) * 0.15; camera.setViewOffset(innerWidth, innerHeight, 0, vo, innerWidth, innerHeight);
  if (PL) phud();
  hudT += dt; if (hudT >= 0.5) { hudT = 0; hud(); } autoT += dt; if (autoT >= 10) { autoT = 0; save(); }
  renderer.render(scene, camera);
}
// ===== Mulai =====
genMissions(); buildVenue(); syncTables(); syncStaff(); planCam(); camT.copy(tgtT); camP.copy(tgtP); hud();
{ const dtO = Math.min((Date.now() - (S.t || Date.now())) / 1000, 4 * 3600); if (dtO > 60) { const g = Math.floor(dtO * income() * 0.5); if (g > 0) { addCash(g); setTimeout(() => toast('Pendapatan offline: $' + fmt(g)), 700); } } }
requestAnimationFrame(loop);
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); }); addEventListener('pagehide', save);
})();
