# Billiard Business Tycoon 3D

Bisnis billiard 3D: main 9-ball sungguhan lawan NPC, kelola tempat, upgrade lokasi, ikut turnamen.
Panduan lengkap di `PANDUAN.md`. Lisensi: MIT
