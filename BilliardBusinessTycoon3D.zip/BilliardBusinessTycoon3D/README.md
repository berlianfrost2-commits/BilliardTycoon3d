# Billiard Business Tycoon 3D

Buka bisnis billiard-mu dan kembangkan jadi kekaisaran. Mainkan biliar di meja utama, layani pengunjung 3D,
atur tarif, bangun fasilitas, rekrut karyawan, dan gunakan berlian untuk boost.

Lihat `PANDUAN.md` untuk cara pasang di GitHub dan membuat APK.
Lisensi: MIT
