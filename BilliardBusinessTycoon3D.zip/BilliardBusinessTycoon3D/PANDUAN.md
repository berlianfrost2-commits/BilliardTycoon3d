# Panduan: Billiard Business Tycoon 3D

## 1. Isi game (v0.2)
- **Buka Bisnis:** layar awal untuk memberi nama bisnis. Nama tampil di HUD dan papan nama neon 3D di dinding.
- **Tab Meja:** pilih meja (ketuk meja atau chip), upgrade sampai Lv.6 (tampilan berubah), beli meja baru sampai 6.
- **Tab Bisnis:**
  - Tarif sewa 1–5 (tarif tinggi: bayaran besar tapi pengunjung lebih jarang)
  - Karyawan Kasir (+15% per level)
  - Fasilitas: Kafe (+12%), AC (+10%), Parkir (pengunjung lebih sering)
  - Statistik dan peringkat bisnis (Warung Billiard sampai Arena Internasional)
- **Tab Top Up:** saldo berlian, hadiah harian gratis (20 💎), paket top up, Boost ×2 (10 menit), Paket Uang.
- **Tab Lainnya:** ganti nama bisnis, reset data.
- Main biliar manual: geser di layar lalu lepas. Bola masuk kantong = uang.
- Pendapatan offline (maks 4 jam, efisiensi 50%) dan simpan otomatis.

## 2. Penting: Top Up masih mode demo
Tombol paket top up (Rp5.000 – Rp50.000) **belum terhubung pembayaran sungguhan**. Saat ini berlian diberikan gratis untuk uji coba, dan ada tulisan peringatan di menunya.

Untuk uang sungguhan di aplikasi Android yang dijual lewat Play Store, Google mewajibkan **Google Play Billing** (bukan QRIS/transfer luar untuk item digital dalam game). Langkah nanti:
1. Rilis ke Play Console, buat produk dalam aplikasi (50, 120, 350, 800 berlian).
2. Pasang plugin Capacitor untuk Play Billing, lalu isi `window.onBuyGems = (paket, selesai) => { ... selesai(true) }` dan ubah `PAYMENT_ENABLED = true` di `www/game.js`.
3. Validasi pembelian di server sebelum menambah berlian (supaya tidak bisa dicurangi).

## 3. Cara perbarui game di repo-mu (metode ZIP)
Repo-mu memakai workflow "Build APK dari ZIP" yang sudah berhasil. Untuk memperbarui:
1. Buka repo → klik file zip lama (`BilliardTycoon3D (2).zip`) → ikon sampah (**Delete file**) → Commit.
   **Penting:** hanya boleh ada **satu** zip di repo, karena workflow mengambil zip pertama yang ditemukan.
2. **Add file → Upload files** → pilih `BilliardBusinessTycoon3D.zip` (tanpa diekstrak) → Commit changes.
3. Buka tab **Actions**. Build jalan otomatis (±2–5 menit). Kalau tidak: **Run workflow**.
4. Setelah hijau ✔: unduh APK di **Releases → Billiard Tycoon 3D (build terbaru)** atau di **Artifacts**.

## 4. Pasang APK
- Nama aplikasi di HP: **Billiard Business Tycoon 3D**.
- APK debug dibuat dengan kunci baru setiap build. Jika gagal terpasang di atas versi lama, **hapus aplikasi lama dulu**, lalu pasang yang baru. Progres game tersimpan di HP; menghapus aplikasi ikut menghapus progres.
- Izinkan "install dari sumber tidak dikenal" jika diminta.

## 5. Jika build merah
Buka run di tab Actions → klik langkah yang gagal → kirim screenshot-nya.

## 6. Langkah berikutnya (saran)
Siklus siang-malam, tipe pengunjung baru, suara bola, turnamen, cabang kota, Google Play Billing, lalu build rilis bertanda tangan (.aab) untuk Play Store.
