(() => {
'use strict';
// ===== Konstanta =====
const R = 0.045, HX = 1.27, HZ = 0.635, POCKET = 0.085, BALL_Y = 0.885 + R;
const SAVE = 'bt3d_save_v1', MAX_TABLES = 6, MAX_LV = 6;
const FRAME = [0x5c3a1e, 0x4a2a12, 0x2b1608, 0xc9a227, 0xd8d8e0, 0xe8c14a];
const CLOTH = [0x1f6b35, 0x1a5e30, 0x0f5a3a, 0x0a6b4a, 0x0b5d6b, 0x0b4f7a];
const BALLC = [0xf1c40f, 0x2e86de, 0xe74c3c, 0x8e44ad, 0xe67e22, 0x27ae60, 0x7b241c, 0x111111, 0xf39c12, 0x1abc9c];
const $ = id => document.getElementById(id);

// ===== Data & simpan =====
let S = (() => { let d = {}; try { d = JSON.parse(localStorage.getItem(SAVE)) || {}; } catch (e) {}
  const base = { cash: 300, gems: 20, total: 0, tables: [1], staff: 0, name: '', price: 3, fac: { cafe: 0, ac: 0, park: 0 }, boostUntil: 0, visits: 0, daily: 0, t: Date.now() };
  const o = Object.assign(base, d); o.fac = Object.assign({ cafe: 0, ac: 0, park: 0 }, d.fac || {}); return o; })();
const save = () => { if (window.__reset) return; try { S.t = Date.now(); localStorage.setItem(SAVE, JSON.stringify(S)); } catch (e) {} };
const boosted = () => Date.now() < S.boostUntil;
const priceMult = () => 0.4 + 0.2 * S.price;
const bonus = () => (1 + 0.15 * S.staff + 0.12 * S.fac.cafe + 0.1 * S.fac.ac) * priceMult() * (boosted() ? 2 : 1);
const rate = lv => 2 * Math.pow(1.35, lv - 1) * bonus();
const income = () => S.tables.reduce((a, l) => a + rate(l), 0);
const stars = () => Math.min(5, Math.floor(Math.log10(S.total + 10)));
const rank = () => ['Warung Billiard', 'Warung Billiard', 'Biliar Kampung', 'Biliar Kota', 'Pusat Biliar', 'Arena Internasional'][stars()];
const upCost = lv => Math.round(100 * Math.pow(1.7, lv));
const buyCost = () => Math.round(600 * Math.pow(3, S.tables.length - 1));
const staffCost = () => Math.round(500 * Math.pow(2.3, S.staff));
const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(2) + 'jt' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'rb' : Math.floor(n) + '';
function addCash(n) { S.cash += n; S.total += n; }

let sel = 0;
function toast(m) { const t = $('toast'); t.textContent = m; t.style.opacity = 1; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.opacity = 0, 2800); }

// Pendapatan offline (maks 4 jam, efisiensi 50%)
{ const dt = Math.min((Date.now() - (S.t || Date.now())) / 1000, 4 * 3600);
  if (dt > 60) { const g = Math.floor(dt * income() * 0.5); if (g > 0) { addCash(g); setTimeout(() => toast('Pendapatan offline: $' + fmt(g)), 600); } } }

// ===== Three.js =====
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.outputEncoding = THREE.sRGBEncoding;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x140f0a);
scene.fog = new THREE.Fog(0x140f0a, 14, 34);
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 80);
const camT = new THREE.Vector3(0, 0.8, 0), camP = new THREE.Vector3(0, 5, 4);

scene.add(new THREE.HemisphereLight(0xffe8cc, 0x3a2a1a, 0.55));
const sun = new THREE.DirectionalLight(0xfff0dd, 0.5);
sun.position.set(4, 9, 5); sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 30 });
scene.add(sun);

function woodTex() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  for (let i = 0; i < 8; i++) { const l = 45 + Math.random() * 10; x.fillStyle = `hsl(28,45%,${l}%)`; x.fillRect(0, i * 32, 256, 32); x.fillStyle = '#0004'; x.fillRect(0, i * 32, 256, 2);
    for (let k = 0; k < 30; k++) { x.fillStyle = `rgba(60,30,10,${Math.random() * .12})`; x.fillRect(Math.random() * 256, i * 32 + Math.random() * 30, 40 + Math.random() * 80, 1); } }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(6, 6); return t;
}
const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ map: woodTex(), roughness: 0.35, metalness: 0.05 }));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
const wallM = new THREE.MeshStandardMaterial({ color: 0xb9a48a, roughness: 0.9 });
const wall1 = new THREE.Mesh(new THREE.BoxGeometry(40, 4, 0.2), wallM); wall1.position.set(0, 2, -3.2); scene.add(wall1);
const wall2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 40), wallM); wall2.position.set(-3.6, 2, 0); scene.add(wall2);
const door = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, 1.1), new THREE.MeshStandardMaterial({ color: 0x3b2412, roughness: 0.5 })); door.position.set(-3.48, 1.1, 2.0); scene.add(door);

const hl = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2 + 1, HZ * 2 + 1), new THREE.MeshBasicMaterial({ color: 0xffdd55, transparent: true, opacity: 0.28 }));
hl.rotation.x = -Math.PI / 2; hl.position.y = 0.012; scene.add(hl);

// ===== Papan nama =====
const signC = document.createElement('canvas'); signC.width = 1024; signC.height = 256;
const signT = new THREE.CanvasTexture(signC); signT.encoding = THREE.sRGBEncoding;
function drawSign() {
  const x = signC.getContext('2d'); x.shadowBlur = 0; x.fillStyle = '#10161a'; x.fillRect(0, 0, 1024, 256);
  x.strokeStyle = '#ffd75e'; x.lineWidth = 10; x.strokeRect(10, 10, 1004, 236);
  const t = (S.name || 'BILLIARD BUSINESS').toUpperCase(); let fs = 100; x.font = 'bold ' + fs + 'px sans-serif';
  while (x.measureText(t).width > 940 && fs > 30) { fs -= 4; x.font = 'bold ' + fs + 'px sans-serif'; }
  x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#fff3b0'; x.shadowColor = '#ffb300'; x.shadowBlur = 24; x.fillText(t, 512, 105);
  x.shadowBlur = 0; x.font = '34px sans-serif'; x.fillStyle = '#9fe6b0'; x.fillText('BILLIARD  •  CAFE  •  LOUNGE', 512, 205); signT.needsUpdate = true;
}
const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 0.9), new THREE.MeshBasicMaterial({ map: signT })); sign.position.set(2.1, 2.7, -3.09); scene.add(sign); drawSign();

// ===== Meja =====
const tables = [];
const tpos = i => new THREE.Vector3((i % 2) * 4.2, 0, Math.floor(i / 2) * 3.2);
function addBall(parent, x, z, col, y) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(R, 24, 16), new THREE.MeshStandardMaterial({ color: col, roughness: 0.12, metalness: 0.1 }));
  m.position.set(x, y === undefined ? BALL_Y : y, z); m.castShadow = true; parent.add(m); return m;
}
function buildTable(i) {
  const g = new THREE.Group(); g.position.copy(tpos(i)); g.userData.idx = i;
  const fm = new THREE.MeshStandardMaterial({ color: FRAME[0], roughness: 0.4, metalness: 0.1 });
  const cm = new THREE.MeshStandardMaterial({ color: CLOTH[0], roughness: 0.95 });
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; g.add(m); return m; };
  add(new THREE.BoxGeometry(HX * 2, 0.05, HZ * 2), cm, 0, 0.86, 0);
  add(new THREE.BoxGeometry(HX * 2 + 0.34, 0.14, HZ * 2 + 0.34), fm, 0, 0.78, 0);
  [[0, HZ + 0.1, HX * 2 + 0.34, 0.2], [0, -HZ - 0.1, HX * 2 + 0.34, 0.2], [HX + 0.1, 0, 0.2, HZ * 2], [-HX - 0.1, 0, 0.2, HZ * 2]].forEach(([x, z, w, d]) => add(new THREE.BoxGeometry(w, 0.1, d), fm, x, 0.92, z));
  [[1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(([a, b]) => add(new THREE.CylinderGeometry(0.07, 0.09, 0.72, 12), fm, a * (HX - 0.1), 0.36, b * (HZ - 0.05)));
  const pm = new THREE.MeshBasicMaterial({ color: 0x050505 });
  [[HX, HZ], [HX, -HZ], [-HX, HZ], [-HX, -HZ], [0, HZ + 0.02], [0, -HZ - 0.02]].forEach(([x, z]) => add(new THREE.CylinderGeometry(POCKET, POCKET, 0.02, 20), pm, x, 0.888, z));
  const lampM = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xffd9a0, emissiveIntensity: 0.9 });
  add(new THREE.CylinderGeometry(0.25, 0.5, 0.25, 16, 1, true), lampM, 0, 2.5, 0).material.side = THREE.DoubleSide;
  const pl = new THREE.PointLight(0xffd9a0, 0.9, 6); pl.position.set(0, 2.3, 0); g.add(pl);
  const t = { group: g, fm, cm, idx: i, occ: false, idle: [] };
  if (i > 0) { const sx = 0.45; let k = 0; for (let r = 0; r < 3; r++) for (let c = 0; c <= r; c++) t.idle.push(addBall(g, sx + r * 0.09, (c - r / 2) * 0.095, BALLC[k++ % 10])); addBall(g, -0.6, 0, 0xffffff); }
  scene.add(g); return t;
}
function styleTable(t) { const l = Math.min(S.tables[t.idx], MAX_LV) - 1; t.fm.color.setHex(FRAME[l]); t.cm.color.setHex(CLOTH[l]); t.fm.roughness = Math.max(0.08, 0.45 - l * 0.07); t.fm.metalness = l >= 3 ? 0.7 : 0.1; }
function syncTables() { while (tables.length < S.tables.length) tables.push(buildTable(tables.length)); tables.forEach(styleTable); }

// ===== Fisika meja utama =====
const balls = []; const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.017, 1.4, 8), new THREE.MeshStandardMaterial({ color: 0xd9b27c, roughness: 0.4 }));
stick.castShadow = true; stick.visible = false; scene.add(stick);
const aimGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
const aim = new THREE.Line(aimGeo, new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 })); aim.visible = false; aim.frustumCulled = false; scene.add(aim);
let rackTimer = 0;
function rack() {
  balls.forEach(b => scene.remove(b.m)); balls.length = 0;
  const mk = (x, z, c) => { const b = { x, z, vx: 0, vz: 0, alive: true, m: addBall(scene, x, z, c) }; balls.push(b); return b; };
  mk(-0.6, 0, 0xffffff); let k = 0;
  for (let r = 0; r < 4; r++) for (let c = 0; c <= r; c++) mk(0.45 + r * R * 1.75, (c - r / 2) * R * 2.05, BALLC[k++ % 10]);
}
const moving = () => balls.some(b => b.alive && (b.vx || b.vz));
const pockets = [[HX, HZ], [HX, -HZ], [-HX, HZ], [-HX, -HZ], [0, HZ], [0, -HZ]];
function physics(dt) {
  const n = 4, h = dt / n;
  for (let s = 0; s < n; s++) {
    for (const b of balls) {
      if (!b.alive) continue;
      b.x += b.vx * h; b.z += b.vz * h;
      const f = Math.exp(-0.75 * h); b.vx *= f; b.vz *= f;
      if (b.vx * b.vx + b.vz * b.vz < 0.0009) b.vx = b.vz = 0;
      let potted = false;
      for (const [px, pz] of pockets) if ((b.x - px) ** 2 + (b.z - pz) ** 2 < POCKET * POCKET) potted = true;
      if (potted) { pot(b); continue; }
      if (b.x > HX - R) { b.x = HX - R; b.vx *= -0.8; } else if (b.x < -HX + R) { b.x = -HX + R; b.vx *= -0.8; }
      if (b.z > HZ - R) { b.z = HZ - R; b.vz *= -0.8; } else if (b.z < -HZ + R) { b.z = -HZ + R; b.vz *= -0.8; }
    }
    for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
      const a = balls[i], b = balls[j]; if (!a.alive || !b.alive) continue;
      const dx = a.x - b.x, dz = a.z - b.z, d2 = dx * dx + dz * dz;
      if (d2 > 0 && d2 < 4 * R * R) {
        const d = Math.sqrt(d2), nx = dx / d, nz = dz / d, ov = (2 * R - d) / 2;
        a.x += nx * ov; a.z += nz * ov; b.x -= nx * ov; b.z -= nz * ov;
        const imp = (a.vx - b.vx) * nx + (a.vz - b.vz) * nz;
        if (imp < 0) { const k = imp * 0.97; a.vx -= k * nx; a.vz -= k * nz; b.vx += k * nx; b.vz += k * nz; }
      }
    }
  }
}
function pot(b) {
  if (b === balls[0]) { b.x = -0.6; b.z = 0; b.vx = b.vz = 0; return; }
  b.alive = false; b.vx = b.vz = 0; b.m.visible = false;
  const g = Math.round(20 * Math.pow(1.25, S.tables[0] - 1) * bonus()); addCash(g);
  floatText(new THREE.Vector3(b.x, 1.2, b.z), '+$' + g);
  if (!balls.some((q, i) => i > 0 && q.alive)) rackTimer = 1.2;
}

// ===== Input =====
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -BALL_Y);
function worldAt(e) { ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera); const p = new THREE.Vector3(); return ray.ray.intersectPlane(plane, p) ? p : null; }
let drag = null, shot = null;
renderer.domElement.addEventListener('pointerdown', e => { drag = { px: e.clientX, py: e.clientY, w: worldAt(e), moved: 0 }; });
renderer.domElement.addEventListener('pointermove', e => {
  if (!drag) return; const w = worldAt(e); if (!w || !drag.w) return;
  drag.moved = Math.hypot(e.clientX - drag.px, e.clientY - drag.py);
  if (drag.moved < 8 || moving()) { shot = null; return; }
  const dx = drag.w.x - w.x, dz = drag.w.z - w.z, L = Math.hypot(dx, dz) || 1;
  shot = { dx: dx / L, dz: dz / L, p: Math.min(1, drag.moved / 160) };
});
const end = e => {
  if (!drag) return;
  if (drag.moved < 8) { ray.setFromCamera(ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1), camera);
    const hit = ray.intersectObjects(tables.map(t => t.group), true)[0];
    if (hit) { let o = hit.object; while (o && o.userData.idx === undefined) o = o.parent; if (o) { sel = o.userData.idx; refresh(); } } }
  else if (shot && shot.p > 0.05 && !moving()) { const sp = 0.6 + shot.p * 5.4, c = balls[0]; c.vx = shot.dx * sp; c.vz = shot.dz * sp; }
  drag = null; shot = null;
};
renderer.domElement.addEventListener('pointerup', end); renderer.domElement.addEventListener('pointercancel', () => { drag = null; shot = null; });

// ===== Pengunjung =====
const visitors = []; let spawnT = 2;
const SHIRT = [0xc0392b, 0x2980b9, 0x16a085, 0xf39c12, 0x8e44ad, 0x34495e, 0xecf0f1];
function mkVisitor(t) {
  const g = new THREE.Group(), m = (geo, c, y, x = 0) => { const o = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: c, roughness: 0.8 })); o.position.set(x, y, 0); o.castShadow = true; g.add(o); return o; };
  m(new THREE.CylinderGeometry(0.15, 0.17, 0.55, 12), SHIRT[Math.random() * SHIRT.length | 0], 0.88);
  m(new THREE.CylinderGeometry(0.07, 0.07, 0.6, 8), 0x1f2a44, 0.3, -0.07); m(new THREE.CylinderGeometry(0.07, 0.07, 0.6, 8), 0x1f2a44, 0.3, 0.07);
  m(new THREE.SphereGeometry(0.11, 14, 12), [0xf1c27d, 0xc68642, 0x8d5524][Math.random() * 3 | 0], 1.35);
  const st = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.013, 1.3, 6), new THREE.MeshStandardMaterial({ color: 0xd9b27c })); st.rotation.x = Math.PI / 2; st.position.set(0.2, 1.0, 0.5); st.visible = false; g.add(st);
  g.position.set(-3.1, 0, 2.0); scene.add(g);
  return { g, st, t, state: 'in', time: 0, ph: Math.random() * 6 };
}
function standPoint(t) { const p = tpos(t.idx); return new THREE.Vector3(p.x + 0.3, 0, p.z + HZ + 0.55); }
function stepV(v, to, dt, sp = 1.5) {
  const dx = to.x - v.g.position.x, dz = to.z - v.g.position.z, d = Math.hypot(dx, dz);
  if (d < 0.06) return true;
  v.g.position.x += dx / d * sp * dt; v.g.position.z += dz / d * sp * dt; v.g.rotation.y = Math.atan2(dx, dz);
  v.g.position.y = Math.abs(Math.sin(v.time * 9)) * 0.035; return false;
}
function updVisitors(dt) {
  spawnT -= dt;
  if (spawnT <= 0) { spawnT = Math.max(1.6, (7 - stars() - 0.4 * S.fac.park) * (0.7 + 0.1 * S.price));
    const free = tables.filter(t => !t.occ);
    if (free.length && visitors.length < tables.length * 2) { const t = free[Math.random() * free.length | 0]; t.occ = true; visitors.push(mkVisitor(t)); } }
  for (let i = visitors.length - 1; i >= 0; i--) {
    const v = visitors[i]; v.time += dt;
    if (v.state === 'in') { if (stepV(v, standPoint(v.t), dt)) { v.state = 'play'; v.time = 0; v.dur = 6 + Math.random() * 3; v.st.visible = true; v.g.position.y = 0; const p = tpos(v.t.idx); v.g.rotation.y = Math.PI; } }
    else if (v.state === 'play') {
      v.st.position.z = 0.5 + Math.sin(v.time * 4 + v.ph) * 0.12; v.g.rotation.x = 0.12 + Math.sin(v.time * 4 + v.ph) * 0.04;
      if (v.time > v.dur) { const g = Math.round(rate(S.tables[v.t.idx]) * 7 * (0.8 + Math.random() * 0.4)); addCash(g);
        S.visits++; floatText(v.g.position.clone().setY(1.7), '+$' + g); v.t.occ = false; v.state = 'out'; v.st.visible = false; v.g.rotation.x = 0; }
    } else if (stepV(v, new THREE.Vector3(-3.1, 0, 2.0), dt, 1.8)) { scene.remove(v.g); visitors.splice(i, 1); }
  }
}
function floatText(p, txt) {
  const v = p.clone().project(camera); if (v.z > 1) return;
  const d = document.createElement('div'); d.className = 'fl'; d.textContent = txt;
  d.style.left = ((v.x + 1) / 2 * innerWidth - 20) + 'px'; d.style.top = ((1 - v.y) / 2 * innerHeight) + 'px';
  document.body.appendChild(d); setTimeout(() => d.remove(), 1100);
}

// ===== UI =====
const PAYMENT_ENABLED = false; // true jika Google Play Billing sudah dipasang (isi window.onBuyGems)
const PACKS = [{ g: 50, rp: 5000 }, { g: 120, rp: 10000 }, { g: 350, rp: 25000 }, { g: 800, rp: 50000 }];
const FAC = {
  cafe: { n: 'Kafe & Minuman', ic: '☕', base: 400, max: 5, d: '+12% pendapatan per level' },
  ac: { n: 'AC & Ruang Nyaman', ic: '❄️', base: 700, max: 5, d: '+10% pendapatan per level' },
  park: { n: 'Lahan Parkir', ic: '🅿️', base: 500, max: 5, d: 'Pengunjung datang lebih sering' }
};
const TNAME = ['Meja Kayu Sederhana', 'Meja Hijau Klasik', 'Meja Profesional', 'Meja VIP Emas', 'Meja Turnamen', 'Meja Legendaris'];
const rupiah = n => 'Rp' + n.toLocaleString('id-ID');
const sheetEl = $('sheet'), sheetBody = $('sb');
let tab = null;
const can = (c, cur) => (cur === 'g' ? S.gems : S.cash) >= c;
const btn = (a, label, cost, cur, x, cls) => `<button class="btn ${cls || (cur === 'g' ? 'g' : '')}" data-a="${a}" data-x="${x === undefined ? 0 : x}" data-cost="${cost}" data-cur="${cur}"${can(cost, cur) ? '' : ' disabled'}>${label}</button>`;
const card = (ic, t, sub, right, prog) => `<div class="card"><div class="ic">${ic}</div><div class="tx"><b>${t}</b><small>${sub}</small>${prog != null ? `<i class="bar"><u style="width:${Math.round(prog * 100)}%"></u></i>` : ''}</div><div class="rt">${right}</div></div>`;
function spend(c, cur) { if (!can(c, cur)) return false; if (cur === 'g') S.gems -= c; else S.cash -= c; return true; }

function tTables() {
  const lv = S.tables[sel], mx = lv >= MAX_LV, uc = upCost(lv), full = S.tables.length >= MAX_TABLES, bc = buyCost();
  let h = '<div class="chips">' + S.tables.map((l, i) => `<button class="chip2 ${i === sel ? 'on' : ''}" data-a="selT" data-x="${i}">Meja ${i + 1} · Lv${l}</button>`).join('') + '</div>';
  h += card('🎱', `Meja ${sel + 1}: ${TNAME[lv - 1]}`, `Lv.${lv}/${MAX_LV} · +$${fmt(rate(lv))}/dtk`, mx ? '<span class="max">MAX</span>' : btn('upT', `⬆ $${fmt(uc)}`, uc, 'c'), lv / MAX_LV);
  h += card('➕', 'Tambah Meja Baru', `${S.tables.length}/${MAX_TABLES} meja di ruanganmu`, full ? '<span class="max">PENUH</span>' : btn('buyT', `$${fmt(bc)}`, bc, 'c'));
  return h;
}
function tBiz() {
  const sc = staffCost(), sm = S.staff >= 8, pm = priceMult();
  let h = '<h4>Harga & Karyawan</h4>';
  h += card('🏷️', 'Tarif Sewa Meja', `Tingkat ${S.price}/5 · bayaran ×${pm.toFixed(1)} · pengunjung ${S.price > 3 ? 'lebih jarang' : S.price < 3 ? 'lebih ramai' : 'normal'}`, `<button class="btn s" data-a="pr" data-x="-1">−</button><button class="btn s" data-a="pr" data-x="1">+</button>`, S.price / 5);
  h += card('👔', 'Karyawan Kasir', `Lv.${S.staff}/8 · +15% pendapatan per level`, sm ? '<span class="max">MAX</span>' : btn('staff', `$${fmt(sc)}`, sc, 'c'), S.staff / 8);
  h += '<h4>Fasilitas</h4>';
  for (const k in FAC) { const F = FAC[k], l = S.fac[k], c = Math.round(F.base * Math.pow(2.2, l));
    h += card(F.ic, F.n, `Lv.${l}/${F.max} · ${F.d}`, l >= F.max ? '<span class="max">MAX</span>' : btn('fac', `$${fmt(c)}`, c, 'c', k), l / F.max); }
  h += '<h4>Statistik</h4>' + card('📊', S.name || 'Bisnisku', `${S.visits} pengunjung dilayani · total pendapatan $${fmt(S.total)}`, `<span class="max">${rank()}</span>`);
  return h;
}
function tShop() {
  const rdy = Date.now() - S.daily >= 864e5, left = Math.ceil((864e5 - (Date.now() - S.daily)) / 36e5);
  let h = card('💎', 'Saldo Berlian', 'Untuk boost, paket uang, dan kosmetik', `<b>${S.gems} 💎</b>`);
  h += card('🎁', 'Hadiah Harian', rdy ? 'Gratis +20 berlian, klaim sekarang!' : `Klaim lagi ${left} jam lagi`, rdy ? '<button class="btn" data-a="daily" data-x="0">Klaim</button>' : '<span class="max">✔</span>');
  h += '<h4>Top Up Berlian</h4><div class="grid">' + PACKS.map((p, i) => `<button class="pack" data-a="topup" data-x="${i}"><b>💎 ${p.g}</b><span>${rupiah(p.rp)}</span></button>`).join('') + '</div>';
  if (!PAYMENT_ENABLED) h += '<div class="note">⚠ Mode demo: pembayaran belum terhubung ke Google Play Billing, jadi berlian diberikan gratis untuk uji coba.</div>';
  h += '<h4>Toko Berlian</h4>';
  h += card('⚡', 'Boost Pendapatan ×2', 'Aktif 10 menit (bisa ditumpuk)', btn('boost', '💎 30', 30, 'g'));
  h += card('💰', 'Paket Uang', `Langsung dapat ±$${fmt(income() * 7200)} (2 jam pendapatan)`, btn('cash', '💎 40', 40, 'g'));
  return h;
}
function tSet() {
  return card('✏️', 'Ganti Nama Bisnis', S.name || '-', '<button class="btn" data-a="rename" data-x="0">Ubah</button>')
    + card('🗑️', 'Hapus Semua Data', 'Mulai bisnis dari nol (tidak bisa dibatalkan)', '<button class="btn s" style="width:auto;padding:9px 12px" data-a="reset" data-x="0">Reset</button>')
    + '<div class="note" style="color:#9fc">Billiard Business Tycoon 3D · v0.2<br>Progres tersimpan otomatis di perangkat ini.</div>';
}
const TABS = { tables: ['🎱 Meja', tTables], biz: ['🏪 Kelola Bisnis', tBiz], shop: ['💎 Top Up & Toko', tShop], set: ['⚙️ Lainnya', tSet] };
function render() {
  document.querySelectorAll('.nv').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  sheetEl.classList.toggle('open', !!tab); document.body.classList.toggle('sheetopen', !!tab);
  if (!tab) return;
  $('st').textContent = TABS[tab][0]; const top = sheetBody.scrollTop; sheetBody.innerHTML = TABS[tab][1](); sheetBody.scrollTop = top;
}
function afford() { sheetBody.querySelectorAll('[data-cost]').forEach(b => { b.disabled = !can(+b.dataset.cost, b.dataset.cur); }); }
function hud() {
  $('bn').textContent = S.name || 'Billiard Business'; $('rk').textContent = rank();
  $('cash').textContent = '💵 $' + fmt(S.cash); $('gem').textContent = '💎 ' + S.gems;
  $('stars').textContent = '★'.repeat(stars()) + '☆'.repeat(5 - stars()); $('inc').textContent = '+$' + fmt(income()) + '/dtk';
  const b = $('bst'); if (boosted()) { b.style.display = 'block'; b.textContent = '⚡ ×2 · ' + Math.ceil((S.boostUntil - Date.now()) / 60000) + ' mnt'; } else b.style.display = 'none';
  afford(); const p = tpos(sel); hl.position.x = p.x; hl.position.z = p.z;
}
function refresh() { hud(); if (tab === 'tables') render(); }

function act(a, x) {
  if (a === 'selT') sel = x;
  else if (a === 'upT') { const lv = S.tables[sel]; if (lv < MAX_LV && spend(upCost(lv), 'c')) { S.tables[sel]++; styleTable(tables[sel]); toast(`Meja ${sel + 1} naik ke Lv.${S.tables[sel]}`); } }
  else if (a === 'buyT') { if (S.tables.length < MAX_TABLES && spend(buyCost(), 'c')) { S.tables.push(1); syncTables(); sel = S.tables.length - 1; toast('Meja baru dibeli!'); } }
  else if (a === 'staff') { if (S.staff < 8 && spend(staffCost(), 'c')) { S.staff++; toast('Karyawan baru: pendapatan +15%'); } }
  else if (a === 'fac') { const F = FAC[x], l = S.fac[x]; if (l < F.max && spend(Math.round(F.base * Math.pow(2.2, l)), 'c')) { S.fac[x]++; toast(F.n + ' naik ke Lv.' + S.fac[x]); } }
  else if (a === 'pr') S.price = Math.max(1, Math.min(5, S.price + x));
  else if (a === 'daily') { if (Date.now() - S.daily >= 864e5) { S.gems += 20; S.daily = Date.now(); toast('+20 💎 hadiah harian'); } }
  else if (a === 'boost') { if (spend(30, 'g')) { S.boostUntil = Math.max(Date.now(), S.boostUntil) + 10 * 60000; toast('⚡ Boost ×2 aktif 10 menit'); } }
  else if (a === 'cash') { if (spend(40, 'g')) { const g = Math.round(income() * 7200); addCash(g); toast('+$' + fmt(g)); } }
  else if (a === 'topup') {
    const p = PACKS[x];
    if (PAYMENT_ENABLED && window.onBuyGems) { window.onBuyGems(p, ok => { if (ok) { S.gems += p.g; save(); render(); hud(); toast('+' + p.g + ' 💎'); } }); return; }
    S.gems += p.g; toast(`Mode demo: +${p.g} 💎 (tanpa bayar)`);
  }
  else if (a === 'rename') { const n = prompt('Nama bisnis:', S.name); if (n && n.trim()) { S.name = n.trim().slice(0, 24); drawSign(); } }
  else if (a === 'reset') { if (confirm('Hapus semua progres?')) { window.__reset = true; try { localStorage.removeItem(SAVE); } catch (e) {} location.reload(); return; } }
  save(); render(); hud();
}
sheetBody.addEventListener('click', ev => { const b = ev.target.closest('[data-a]'); if (b && !b.disabled) act(b.dataset.a, isNaN(+b.dataset.x) ? b.dataset.x : +b.dataset.x); });
document.querySelectorAll('.nv').forEach(b => b.onclick = () => { tab = tab === b.dataset.tab ? null : b.dataset.tab; render(); hud(); });
$('sx').onclick = () => { tab = null; render(); };
if (S.name) $('intro').style.display = 'none';
$('go').onclick = () => { S.name = ($('nm').value || '').trim().slice(0, 24) || 'Billiard Bisnis Saya'; save(); drawSign(); $('intro').style.display = 'none'; hud(); toast('Bisnis "' + S.name + '" resmi dibuka! 🎉'); };

// ===== Kamera & loop =====
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
function frameCam(snap) {
  const ps = S.tables.map((_, i) => tpos(i)), xs = ps.map(p => p.x), zs = ps.map(p => p.z);
  const w = (Math.max(...xs) - Math.min(...xs)) / 2 + 2.3, d = (Math.max(...zs) - Math.min(...zs)) / 2 + 1.7;
  const tv = Math.tan(camera.fov * Math.PI / 360), th = tv * camera.aspect, dist = Math.max(w / th, d / tv / 0.8) + 0.5, el = 58 * Math.PI / 180;
  const tgt = new THREE.Vector3((Math.max(...xs) + Math.min(...xs)) / 2 - 0.2, 0.8, (Math.max(...zs) + Math.min(...zs)) / 2 + 0.4);
  const pos = tgt.clone().add(new THREE.Vector3(0, Math.sin(el) * dist, Math.cos(el) * dist));
  if (snap) { camT.copy(tgt); camP.copy(pos); } else { camT.lerp(tgt, 0.05); camP.lerp(pos, 0.05); }
  camera.position.copy(camP); camera.lookAt(camT);
}
syncTables(); rack(); refresh(); frameCam(true);
let last = performance.now(), acc = 0, auto = 0, vo = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  physics(dt);
  balls.forEach(b => b.m.position.set(b.x, BALL_Y, b.z));
  if (rackTimer > 0) { rackTimer -= dt; if (rackTimer <= 0) { const c = balls[0]; rack(); balls[0].x = c.x; balls[0].z = c.z; } }
  const c = balls[0], ok = shot && !moving();
  stick.visible = aim.visible = !!ok; $('pow').style.opacity = ok ? 1 : 0;
  if (ok) {
    const L = 0.35 + shot.p * 1.0, a = aimGeo.attributes.position;
    a.setXYZ(0, c.x, BALL_Y, c.z); a.setXYZ(1, c.x + shot.dx * L, BALL_Y, c.z + shot.dz * L); a.needsUpdate = true;
    const off = 0.06 + shot.p * 0.35 + 0.7; stick.position.set(c.x - shot.dx * off, BALL_Y, c.z - shot.dz * off);
    stick.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(shot.dx, 0, shot.dz));
    $('pow').firstChild.style.width = shot.p * 100 + '%';
  }
  acc += dt; if (acc >= 1) { acc = 0; hud(); }
  auto += dt; if (auto >= 10) { auto = 0; save(); }
  updVisitors(dt); frameCam(false);
  const tvo = tab ? (sheetEl.offsetHeight + 60) * 0.5 : 0; vo += (tvo - vo) * 0.15;
  camera.setViewOffset(innerWidth, innerHeight, 0, vo, innerWidth, innerHeight);
  renderer.render(scene, camera);
}
requestAnimationFrame(loop);
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
addEventListener('pagehide', save);
})();
