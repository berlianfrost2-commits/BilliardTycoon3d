# Billiard Tycoon 3D

Game tycoon biliar 3D (Three.js). Bermain biliar di meja utama, kelola pengunjung,
upgrade meja, beli meja baru, rekrut karyawan. Ada pendapatan offline (maks 4 jam).

## Main di browser
```
npm install
npm run copy-three
npm start
```
Buka alamat yang ditampilkan (mis. http://localhost:3000).

## Kontrol
- Geser di layar lalu lepas: menyodok bola putih (arah berlawanan dengan geseran, makin jauh makin kuat)
- Ketuk meja: pilih meja untuk di-upgrade
- Tombol bawah: Upgrade Meja, Beli Meja, Karyawan

## Build APK
Lihat `PANDUAN_GITHUB.md`.

Lisensi: MIT
