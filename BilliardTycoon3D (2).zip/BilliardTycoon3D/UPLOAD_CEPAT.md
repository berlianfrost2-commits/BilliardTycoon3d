# Upload Cepat (tanpa install apa pun di komputer)

1. Buka github.com → **+** → **New repository** → nama `billiard-tycoon-3d` → Public → **Create repository**.
2. Di halaman repo kosong klik **uploading an existing file**.
3. Ekstrak `BilliardTycoon3D.zip`, lalu seret **isi** foldernya (www, scripts, package.json, capacitor.config.json, LICENSE, README.md, dll.) ke halaman upload. Klik **Commit changes**.
4. Folder tersembunyi `.github` sering tidak ikut terseret. Cek tab **Code**: kalau tidak ada folder `.github`, buat manual:
   **Add file → Create new file**, ketik nama `.github/workflows/build-apk.yml`, tempel isi file `build-apk.yml` dari zip (di folder `.github/workflows`), lalu **Commit**.
5. Buka tab **Actions**. Build jalan otomatis (±5–10 menit). Kalau belum jalan: **Build APK → Run workflow**.
6. Setelah hijau ✔, ambil APK di dua tempat:
   - Sisi kanan halaman repo → **Releases → Billiard Tycoon 3D (build terbaru)** → `BilliardTycoon3D.apk`
   - atau di run Actions → **Artifacts**
7. Pasang APK di HP (izinkan "install dari sumber tidak dikenal").

Opsional sebelum upload: ganti `GANTI_DENGAN_NAMAMU` di `LICENSE` dan `appId` di `capacitor.config.json`.
Jika build merah: buka run → klik langkah yang gagal → kirim log-nya ke saya.
