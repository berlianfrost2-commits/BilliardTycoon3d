(() => {
'use strict';
// ===== Konstanta =====
const R = 0.045, HX = 1.27, HZ = 0.635, POCKET = 0.085, BALL_Y = 0.885 + R;
const SAVE = 'bt3d_save_v1', MAX_TABLES = 6, MAX_LV = 6;
const FRAME = [0x5c3a1e, 0x4a2a12, 0x2b1608, 0xc9a227, 0xd8d8e0, 0xe8c14a];
const CLOTH = [0x1f6b35, 0x1a5e30, 0x0f5a3a, 0x0a6b4a, 0x0b5d6b, 0x0b4f7a];
const BALLC = [0xf1c40f, 0x2e86de, 0xe74c3c, 0x8e44ad, 0xe67e22, 0x27ae60, 0x7b241c, 0x111111, 0xf39c12, 0x1abc9c];
const $ = id => document.getElementById(id);

// ===== Data & simpan =====
let S = (() => { try { const d = JSON.parse(localStorage.getItem(SAVE)); if (d && d.tables) return d; } catch (e) {} return { cash: 300, total: 0, tables: [1], staff: 0, t: Date.now() }; })();
const save = () => { try { S.t = Date.now(); localStorage.setItem(SAVE, JSON.stringify(S)); } catch (e) {} };
const bonus = () => 1 + 0.15 * S.staff;
const rate = lv => 2 * Math.pow(1.35, lv - 1) * bonus();
const income = () => S.tables.reduce((a, l) => a + rate(l), 0);
const stars = () => Math.min(5, Math.floor(Math.log10(S.total + 10)));
const upCost = lv => Math.round(100 * Math.pow(1.7, lv));
const buyCost = () => Math.round(600 * Math.pow(3, S.tables.length - 1));
const staffCost = () => Math.round(500 * Math.pow(2.3, S.staff));
const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(2) + 'jt' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'rb' : Math.floor(n) + '';
function addCash(n) { S.cash += n; S.total += n; }

let sel = 0;
function toast(m) { const t = $('toast'); t.textContent = m; t.style.opacity = 1; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.opacity = 0, 2800); }

// Pendapatan offline (maks 4 jam, efisiensi 50%)
{ const dt = Math.min((Date.now() - (S.t || Date.now())) / 1000, 4 * 3600);
  if (dt > 60) { const g = Math.floor(dt * income() * 0.5); if (g > 0) { addCash(g); setTimeout(() => toast('Pendapatan offline: $' + fmt(g)), 600); } } }

// ===== Three.js =====
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.outputEncoding = THREE.sRGBEncoding;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x140f0a);
scene.fog = new THREE.Fog(0x140f0a, 14, 34);
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 80);
const camT = new THREE.Vector3(0, 0.8, 0), camP = new THREE.Vector3(0, 5, 4);

scene.add(new THREE.HemisphereLight(0xffe8cc, 0x3a2a1a, 0.55));
const sun = new THREE.DirectionalLight(0xfff0dd, 0.5);
sun.position.set(4, 9, 5); sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 30 });
scene.add(sun);

function woodTex() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  for (let i = 0; i < 8; i++) { const l = 45 + Math.random() * 10; x.fillStyle = `hsl(28,45%,${l}%)`; x.fillRect(0, i * 32, 256, 32); x.fillStyle = '#0004'; x.fillRect(0, i * 32, 256, 2);
    for (let k = 0; k < 30; k++) { x.fillStyle = `rgba(60,30,10,${Math.random() * .12})`; x.fillRect(Math.random() * 256, i * 32 + Math.random() * 30, 40 + Math.random() * 80, 1); } }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(6, 6); return t;
}
const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ map: woodTex(), roughness: 0.35, metalness: 0.05 }));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
const wallM = new THREE.MeshStandardMaterial({ color: 0xb9a48a, roughness: 0.9 });
const wall1 = new THREE.Mesh(new THREE.BoxGeometry(40, 4, 0.2), wallM); wall1.position.set(0, 2, -3.2); scene.add(wall1);
const wall2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 40), wallM); wall2.position.set(-3.6, 2, 0); scene.add(wall2);
const door = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, 1.1), new THREE.MeshStandardMaterial({ color: 0x3b2412, roughness: 0.5 })); door.position.set(-3.48, 1.1, 2.0); scene.add(door);

const hl = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2 + 1, HZ * 2 + 1), new THREE.MeshBasicMaterial({ color: 0xffdd55, transparent: true, opacity: 0.28 }));
hl.rotation.x = -Math.PI / 2; hl.position.y = 0.012; scene.add(hl);

// ===== Meja =====
const tables = [];
const tpos = i => new THREE.Vector3((i % 2) * 4.2, 0, Math.floor(i / 2) * 3.2);
function addBall(parent, x, z, col, y) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(R, 24, 16), new THREE.MeshStandardMaterial({ color: col, roughness: 0.12, metalness: 0.1 }));
  m.position.set(x, y === undefined ? BALL_Y : y, z); m.castShadow = true; parent.add(m); return m;
}
function buildTable(i) {
  const g = new THREE.Group(); g.position.copy(tpos(i)); g.userData.idx = i;
  const fm = new THREE.MeshStandardMaterial({ color: FRAME[0], roughness: 0.4, metalness: 0.1 });
  const cm = new THREE.MeshStandardMaterial({ color: CLOTH[0], roughness: 0.95 });
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; g.add(m); return m; };
  add(new THREE.BoxGeometry(HX * 2, 0.05, HZ * 2), cm, 0, 0.86, 0);
  add(new THREE.BoxGeometry(HX * 2 + 0.34, 0.14, HZ * 2 + 0.34), fm, 0, 0.78, 0);
  [[0, HZ + 0.1, HX * 2 + 0.34, 0.2], [0, -HZ - 0.1, HX * 2 + 0.34, 0.2], [HX + 0.1, 0, 0.2, HZ * 2], [-HX - 0.1, 0, 0.2, HZ * 2]].forEach(([x, z, w, d]) => add(new THREE.BoxGeometry(w, 0.1, d), fm, x, 0.92, z));
  [[1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(([a, b]) => add(new THREE.CylinderGeometry(0.07, 0.09, 0.72, 12), fm, a * (HX - 0.1), 0.36, b * (HZ - 0.05)));
  const pm = new THREE.MeshBasicMaterial({ color: 0x050505 });
  [[HX, HZ], [HX, -HZ], [-HX, HZ], [-HX, -HZ], [0, HZ + 0.02], [0, -HZ - 0.02]].forEach(([x, z]) => add(new THREE.CylinderGeometry(POCKET, POCKET, 0.02, 20), pm, x, 0.888, z));
  const lampM = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: 0xffd9a0, emissiveIntensity: 0.9 });
  add(new THREE.CylinderGeometry(0.25, 0.5, 0.25, 16, 1, true), lampM, 0, 2.5, 0).material.side = THREE.DoubleSide;
  const pl = new THREE.PointLight(0xffd9a0, 0.9, 6); pl.position.set(0, 2.3, 0); g.add(pl);
  const t = { group: g, fm, cm, idx: i, occ: false, idle: [] };
  if (i > 0) { const sx = 0.45; let k = 0; for (let r = 0; r < 3; r++) for (let c = 0; c <= r; c++) t.idle.push(addBall(g, sx + r * 0.09, (c - r / 2) * 0.095, BALLC[k++ % 10])); addBall(g, -0.6, 0, 0xffffff); }
  scene.add(g); return t;
}
function styleTable(t) { const l = Math.min(S.tables[t.idx], MAX_LV) - 1; t.fm.color.setHex(FRAME[l]); t.cm.color.setHex(CLOTH[l]); t.fm.roughness = Math.max(0.08, 0.45 - l * 0.07); t.fm.metalness = l >= 3 ? 0.7 : 0.1; }
function syncTables() { while (tables.length < S.tables.length) tables.push(buildTable(tables.length)); tables.forEach(styleTable); }

// ===== Fisika meja utama =====
const balls = []; const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.017, 1.4, 8), new THREE.MeshStandardMaterial({ color: 0xd9b27c, roughness: 0.4 }));
stick.castShadow = true; stick.visible = false; scene.add(stick);
const aimGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
const aim = new THREE.Line(aimGeo, new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 })); aim.visible = false; aim.frustumCulled = false; scene.add(aim);
let rackTimer = 0;
function rack() {
  balls.forEach(b => scene.remove(b.m)); balls.length = 0;
  const mk = (x, z, c) => { const b = { x, z, vx: 0, vz: 0, alive: true, m: addBall(scene, x, z, c) }; balls.push(b); return b; };
  mk(-0.6, 0, 0xffffff); let k = 0;
  for (let r = 0; r < 4; r++) for (let c = 0; c <= r; c++) mk(0.45 + r * R * 1.75, (c - r / 2) * R * 2.05, BALLC[k++ % 10]);
}
const moving = () => balls.some(b => b.alive && (b.vx || b.vz));
const pockets = [[HX, HZ], [HX, -HZ], [-HX, HZ], [-HX, -HZ], [0, HZ], [0, -HZ]];
function physics(dt) {
  const n = 4, h = dt / n;
  for (let s = 0; s < n; s++) {
    for (const b of balls) {
      if (!b.alive) continue;
      b.x += b.vx * h; b.z += b.vz * h;
      const f = Math.exp(-0.75 * h); b.vx *= f; b.vz *= f;
      if (b.vx * b.vx + b.vz * b.vz < 0.0009) b.vx = b.vz = 0;
      let potted = false;
      for (const [px, pz] of pockets) if ((b.x - px) ** 2 + (b.z - pz) ** 2 < POCKET * POCKET) potted = true;
      if (potted) { pot(b); continue; }
      if (b.x > HX - R) { b.x = HX - R; b.vx *= -0.8; } else if (b.x < -HX + R) { b.x = -HX + R; b.vx *= -0.8; }
      if (b.z > HZ - R) { b.z = HZ - R; b.vz *= -0.8; } else if (b.z < -HZ + R) { b.z = -HZ + R; b.vz *= -0.8; }
    }
    for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
      const a = balls[i], b = balls[j]; if (!a.alive || !b.alive) continue;
      const dx = a.x - b.x, dz = a.z - b.z, d2 = dx * dx + dz * dz;
      if (d2 > 0 && d2 < 4 * R * R) {
        const d = Math.sqrt(d2), nx = dx / d, nz = dz / d, ov = (2 * R - d) / 2;
        a.x += nx * ov; a.z += nz * ov; b.x -= nx * ov; b.z -= nz * ov;
        const imp = (a.vx - b.vx) * nx + (a.vz - b.vz) * nz;
        if (imp < 0) { const k = imp * 0.97; a.vx -= k * nx; a.vz -= k * nz; b.vx += k * nx; b.vz += k * nz; }
      }
    }
  }
}
function pot(b) {
  if (b === balls[0]) { b.x = -0.6; b.z = 0; b.vx = b.vz = 0; return; }
  b.alive = false; b.vx = b.vz = 0; b.m.visible = false;
  const g = Math.round(20 * Math.pow(1.25, S.tables[0] - 1) * bonus()); addCash(g);
  floatText(new THREE.Vector3(b.x, 1.2, b.z), '+$' + g);
  if (!balls.some((q, i) => i > 0 && q.alive)) rackTimer = 1.2;
}

// ===== Input =====
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -BALL_Y);
function worldAt(e) { ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera); const p = new THREE.Vector3(); return ray.ray.intersectPlane(plane, p) ? p : null; }
let drag = null, shot = null;
renderer.domElement.addEventListener('pointerdown', e => { drag = { px: e.clientX, py: e.clientY, w: worldAt(e), moved: 0 }; });
renderer.domElement.addEventListener('pointermove', e => {
  if (!drag) return; const w = worldAt(e); if (!w || !drag.w) return;
  drag.moved = Math.hypot(e.clientX - drag.px, e.clientY - drag.py);
  if (drag.moved < 8 || moving()) { shot = null; return; }
  const dx = drag.w.x - w.x, dz = drag.w.z - w.z, L = Math.hypot(dx, dz) || 1;
  shot = { dx: dx / L, dz: dz / L, p: Math.min(1, drag.moved / 160) };
});
const end = e => {
  if (!drag) return;
  if (drag.moved < 8) { ray.setFromCamera(ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1), camera);
    const hit = ray.intersectObjects(tables.map(t => t.group), true)[0];
    if (hit) { let o = hit.object; while (o && o.userData.idx === undefined) o = o.parent; if (o) { sel = o.userData.idx; refresh(); } } }
  else if (shot && shot.p > 0.05 && !moving()) { const sp = 0.6 + shot.p * 5.4, c = balls[0]; c.vx = shot.dx * sp; c.vz = shot.dz * sp; }
  drag = null; shot = null;
};
renderer.domElement.addEventListener('pointerup', end); renderer.domElement.addEventListener('pointercancel', () => { drag = null; shot = null; });

// ===== Pengunjung =====
const visitors = []; let spawnT = 2;
const SHIRT = [0xc0392b, 0x2980b9, 0x16a085, 0xf39c12, 0x8e44ad, 0x34495e, 0xecf0f1];
function mkVisitor(t) {
  const g = new THREE.Group(), m = (geo, c, y, x = 0) => { const o = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: c, roughness: 0.8 })); o.position.set(x, y, 0); o.castShadow = true; g.add(o); return o; };
  m(new THREE.CylinderGeometry(0.15, 0.17, 0.55, 12), SHIRT[Math.random() * SHIRT.length | 0], 0.88);
  m(new THREE.CylinderGeometry(0.07, 0.07, 0.6, 8), 0x1f2a44, 0.3, -0.07); m(new THREE.CylinderGeometry(0.07, 0.07, 0.6, 8), 0x1f2a44, 0.3, 0.07);
  m(new THREE.SphereGeometry(0.11, 14, 12), [0xf1c27d, 0xc68642, 0x8d5524][Math.random() * 3 | 0], 1.35);
  const st = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.013, 1.3, 6), new THREE.MeshStandardMaterial({ color: 0xd9b27c })); st.rotation.x = Math.PI / 2; st.position.set(0.2, 1.0, 0.5); st.visible = false; g.add(st);
  g.position.set(-3.1, 0, 2.0); scene.add(g);
  return { g, st, t, state: 'in', time: 0, ph: Math.random() * 6 };
}
function standPoint(t) { const p = tpos(t.idx); return new THREE.Vector3(p.x + 0.3, 0, p.z + HZ + 0.55); }
function stepV(v, to, dt, sp = 1.5) {
  const dx = to.x - v.g.position.x, dz = to.z - v.g.position.z, d = Math.hypot(dx, dz);
  if (d < 0.06) return true;
  v.g.position.x += dx / d * sp * dt; v.g.position.z += dz / d * sp * dt; v.g.rotation.y = Math.atan2(dx, dz);
  v.g.position.y = Math.abs(Math.sin(v.time * 9)) * 0.035; return false;
}
function updVisitors(dt) {
  spawnT -= dt;
  if (spawnT <= 0) { spawnT = Math.max(2.2, 7 - stars());
    const free = tables.filter(t => !t.occ);
    if (free.length && visitors.length < tables.length * 2) { const t = free[Math.random() * free.length | 0]; t.occ = true; visitors.push(mkVisitor(t)); } }
  for (let i = visitors.length - 1; i >= 0; i--) {
    const v = visitors[i]; v.time += dt;
    if (v.state === 'in') { if (stepV(v, standPoint(v.t), dt)) { v.state = 'play'; v.time = 0; v.dur = 6 + Math.random() * 3; v.st.visible = true; v.g.position.y = 0; const p = tpos(v.t.idx); v.g.rotation.y = Math.PI; } }
    else if (v.state === 'play') {
      v.st.position.z = 0.5 + Math.sin(v.time * 4 + v.ph) * 0.12; v.g.rotation.x = 0.12 + Math.sin(v.time * 4 + v.ph) * 0.04;
      if (v.time > v.dur) { const g = Math.round(rate(S.tables[v.t.idx]) * 7 * (0.8 + Math.random() * 0.4)); addCash(g);
        floatText(v.g.position.clone().setY(1.7), '+$' + g); v.t.occ = false; v.state = 'out'; v.st.visible = false; v.g.rotation.x = 0; }
    } else if (stepV(v, new THREE.Vector3(-3.1, 0, 2.0), dt, 1.8)) { scene.remove(v.g); visitors.splice(i, 1); }
  }
}
function floatText(p, txt) {
  const v = p.clone().project(camera); if (v.z > 1) return;
  const d = document.createElement('div'); d.className = 'fl'; d.textContent = txt;
  d.style.left = ((v.x + 1) / 2 * innerWidth - 20) + 'px'; d.style.top = ((1 - v.y) / 2 * innerHeight) + 'px';
  document.body.appendChild(d); setTimeout(() => d.remove(), 1100);
}

// ===== UI =====
function refresh() {
  const lv = S.tables[sel], mx = lv >= MAX_LV, uc = upCost(lv);
  $('bUp').innerHTML = mx ? `Meja ${sel + 1}<br>Level MAX` : `⬆ Upgrade Meja ${sel + 1}<br>Lv.${lv} · $${fmt(uc)}`;
  $('bUp').disabled = mx || S.cash < uc;
  const full = S.tables.length >= MAX_TABLES, bc = buyCost();
  $('bBuy').innerHTML = full ? 'Meja<br>Penuh' : `➕ Beli Meja<br>$${fmt(bc)}`; $('bBuy').disabled = full || S.cash < bc;
  const sc = staffCost(), sm = S.staff >= 8;
  $('bStaff').innerHTML = sm ? 'Karyawan<br>MAX' : `👔 Karyawan ${S.staff}<br>$${fmt(sc)}`; $('bStaff').disabled = sm || S.cash < sc;
  $('cash').textContent = '$' + fmt(S.cash); $('stars').textContent = '★'.repeat(stars()) + '☆'.repeat(5 - stars()); $('inc').textContent = '+$' + fmt(income()) + '/dtk';
  const p = tpos(sel); hl.position.x = p.x; hl.position.z = p.z;
}
$('bUp').onclick = () => { const c = upCost(S.tables[sel]); if (S.cash >= c && S.tables[sel] < MAX_LV) { S.cash -= c; S.tables[sel]++; styleTable(tables[sel]); toast('Meja ' + (sel + 1) + ' naik ke Lv.' + S.tables[sel]); save(); refresh(); } };
$('bBuy').onclick = () => { const c = buyCost(); if (S.cash >= c && S.tables.length < MAX_TABLES) { S.cash -= c; S.tables.push(1); syncTables(); sel = S.tables.length - 1; toast('Meja baru dibeli!'); save(); refresh(); } };
$('bStaff').onclick = () => { const c = staffCost(); if (S.cash >= c && S.staff < 8) { S.cash -= c; S.staff++; toast('Karyawan baru: pendapatan +15%'); save(); refresh(); } };

// ===== Kamera & loop =====
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
function frameCam(snap) {
  const ps = S.tables.map((_, i) => tpos(i)), xs = ps.map(p => p.x), zs = ps.map(p => p.z);
  const w = (Math.max(...xs) - Math.min(...xs)) / 2 + 2.3, d = (Math.max(...zs) - Math.min(...zs)) / 2 + 1.7;
  const tv = Math.tan(camera.fov * Math.PI / 360), th = tv * camera.aspect, dist = Math.max(w / th, d / tv / 0.8) + 0.5, el = 58 * Math.PI / 180;
  const tgt = new THREE.Vector3((Math.max(...xs) + Math.min(...xs)) / 2 - 0.2, 0.8, (Math.max(...zs) + Math.min(...zs)) / 2 + 0.4);
  const pos = tgt.clone().add(new THREE.Vector3(0, Math.sin(el) * dist, Math.cos(el) * dist));
  if (snap) { camT.copy(tgt); camP.copy(pos); } else { camT.lerp(tgt, 0.05); camP.lerp(pos, 0.05); }
  camera.position.copy(camP); camera.lookAt(camT);
}
syncTables(); rack(); refresh(); frameCam(true);
let last = performance.now(), acc = 0, auto = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  physics(dt);
  balls.forEach(b => b.m.position.set(b.x, BALL_Y, b.z));
  if (rackTimer > 0) { rackTimer -= dt; if (rackTimer <= 0) { const c = balls[0]; rack(); balls[0].x = c.x; balls[0].z = c.z; } }
  const c = balls[0], ok = shot && !moving();
  stick.visible = aim.visible = !!ok; $('pow').style.opacity = ok ? 1 : 0;
  if (ok) {
    const L = 0.35 + shot.p * 1.0, a = aimGeo.attributes.position;
    a.setXYZ(0, c.x, BALL_Y, c.z); a.setXYZ(1, c.x + shot.dx * L, BALL_Y, c.z + shot.dz * L); a.needsUpdate = true;
    const off = 0.06 + shot.p * 0.35 + 0.7; stick.position.set(c.x - shot.dx * off, BALL_Y, c.z - shot.dz * off);
    stick.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(shot.dx, 0, shot.dz));
    $('pow').firstChild.style.width = shot.p * 100 + '%';
  }
  acc += dt; if (acc >= 1) { acc = 0; refresh(); }
  auto += dt; if (auto >= 10) { auto = 0; save(); }
  updVisitors(dt); frameCam(false);
  renderer.render(scene, camera);
}
requestAnimationFrame(loop);
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
addEventListener('pagehide', save);
})();
