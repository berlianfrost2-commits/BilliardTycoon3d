# Panduan Pasang di GitHub + Build APK Otomatis

## A. Siapkan sekali
1. Punya akun GitHub (github.com).
2. Pasang **Git** dan **Node.js 20** di komputer (di HP bisa pakai Termux: `pkg install git nodejs`).
3. Ekstrak `BilliardTycoon3D.zip`, buka foldernya di terminal.

## B. Siapkan file game
```
npm install
npm run copy-three
```
Perintah kedua membuat `www/three.min.js`. File ini **harus ikut di-commit** supaya game bisa jalan juga di GitHub Pages.

Tes dulu: `npm start`, lalu buka di browser.

Ganti `GANTI_DENGAN_NAMAMU` di `LICENSE`. Ganti `appId` di `capacitor.config.json` dengan ID unikmu, mis. `com.namamu.billiardtycoon`.

## C. Buat repo di GitHub
1. GitHub → tombol **+** → **New repository**.
2. Nama: `billiard-tycoon-3d`. Pilih Public (gratis, cocok untuk open source). **Jangan** centang README/LICENSE (sudah ada).
3. Klik **Create repository**.

## D. Unggah kode
Ganti `USERNAME` dengan nama akun GitHub-mu:
```
git init
git add .
git commit -m "Versi awal Billiard Tycoon 3D"
git branch -M main
git remote add origin https://github.com/USERNAME/billiard-tycoon-3d.git
git push -u origin main
```
Jika diminta password, pakai **Personal Access Token** (GitHub → Settings → Developer settings → Personal access tokens, centang `repo` dan `workflow`).

## E. Ambil APK dari GitHub Actions
1. Buka repo → tab **Actions**. Workflow **Build APK** berjalan otomatis setelah push (±5–10 menit).
2. Kalau tidak jalan sendiri: **Build APK → Run workflow**.
3. Setelah hijau ✔, buka run tersebut → bagian **Artifacts** → unduh `BilliardTycoon3D-debug-apk`.
4. Ekstrak zip, pasang `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal").

## F. Main langsung di browser (GitHub Pages, opsional)
1. Repo → **Settings → Pages**.
2. Source: **Deploy from a branch**, branch `main`.
3. Folder hanya mendukung `/ (root)` atau `/docs`. Cara mudah: ganti nama folder `www` menjadi `docs` (ubah juga `webDir` di `capacitor.config.json` dan `scripts/copy-three.js`), lalu pilih `/docs`.
4. Tunggu beberapa menit, game ada di `https://USERNAME.github.io/billiard-tycoon-3d/`.

## G. Rilis ke Play Store (nanti)
APK debug **tidak bisa** diunggah ke Play Store. Langkah ringkas:
1. Buat keystore (`keytool -genkey -v -keystore rilis.jks -alias rilis -keyalg RSA -keysize 2048 -validity 10000`). Simpan aman, **jangan di-commit**.
2. Simpan keystore (base64) dan passwordnya di **Settings → Secrets and variables → Actions**.
3. Tambah langkah `./gradlew bundleRelease` dengan signing di workflow, hasilnya file `.aab` untuk Play Console.
4. Siapkan ikon, screenshot, kebijakan privasi, dan ikuti syarat uji tertutup akun baru di Play Console (cek aturan terbaru).

## Masalah umum
| Masalah | Solusi |
|---|---|
| Layar hitam di game | `www/three.min.js` belum ada: jalankan `npm run copy-three` |
| `npx cap add android` gagal | Pastikan Node 18+ dan `npm install` sudah jalan |
| Build Actions merah di Gradle | Buka log langkah yang gagal; biasanya versi Java. Workflow memakai Java 17 |
| Push ditolak | Pakai Personal Access Token, bukan password akun |
