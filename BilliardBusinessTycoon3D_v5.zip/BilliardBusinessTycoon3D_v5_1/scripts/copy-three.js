const fs = require('fs');
fs.mkdirSync('www', { recursive: true });
fs.copyFileSync('node_modules/three/build/three.min.js', 'www/three.min.js');
console.log('three.min.js disalin ke www/');
const cap = 'node_modules/@capacitor/core/dist/capacitor.js';
if (fs.existsSync(cap)) { fs.copyFileSync(cap, 'www/capacitor.js'); console.log('capacitor.js disalin ke www/'); }
else console.log('PERINGATAN: capacitor.js tidak ditemukan; memakai jembatan native bawaan');
