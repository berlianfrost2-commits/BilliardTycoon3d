# Panduan Rilis ke Google Play Console

Versi game: **1.1.1 (Play Store, dengan top up)**. Proyek memakai **Capacitor 8** (target Android 16 / API 36) dan build otomatis lewat GitHub Actions. Aturan Google sering berubah, jadi cek ulang peringatan di Play Console saat kamu mengunggah.

## 0. Urutan singkat
1. Perbarui repo GitHub dengan versi ini
2. Buat kunci tanda tangan (keystore) dan simpan di GitHub Secrets
3. Jalankan build, unduh file **.aab**
4. Hosting kebijakan privasi (GitHub Pages)
5. Buat aplikasi di Play Console, isi semua formulir
6. Uji tertutup (closed testing), lalu rilis produksi

---
## 1. Perbarui repo GitHub (metode ZIP)
1. Di repo, hapus zip lama (ikon sampah, Commit). **Hanya boleh ada satu zip.**
2. **Add file → Upload files** → unggah `BilliardBusinessTycoon3D_v5_1.zip` tanpa diekstrak → Commit.
3. Ganti workflow lama (wajib, versi lama memakai Node 20 dan Java 17, sedangkan Capacitor 8 butuh Node 22 dan Java 21):
   buka `.github/workflows/build.yml` → ikon pensil → hapus semua isinya → tempel isi file `WORKFLOW_build.yml` dari zip → Commit.
4. Buka tab **Actions**. Build jalan otomatis.
Jika `npm install` gagal dengan pesan versi tidak ditemukan (ETARGET) pada `@capacitor/app`, hapus baris itu di `package.json` (hanya dipakai untuk tombol Kembali Android).

## 2. Buat keystore (kunci upload)
Kunci ini **tidak boleh hilang** dan jangan diunggah ke repo. Gunakan **Play App Signing** (default): Google menyimpan kunci utama, kamu hanya memegang kunci *upload*.

**Cara A: lewat GitHub Actions (paling mudah dari HP, tanpa Termux)**
1. **Jadikan repo Private sementara**: Settings → paling bawah *Danger Zone* → *Change visibility* → Private. (Hasil keystore berupa Artifact yang bisa diunduh siapa saja jika repo publik.)
2. **Add file → Create new file**, nama `.github/workflows/keystore.yml`, tempel isi file `WORKFLOW_buat_keystore.yml` dari zip → Commit.
3. Tab **Actions → Buat Keystore (sekali saja) → Run workflow**.
4. Setelah hijau ✔, buka run itu → **Artifacts → keystore-RAHASIA** → unduh dan ekstrak. Isinya:
   - `upload.jks` (kunci asli) → **simpan di 2 tempat aman** (mis. Google Drive pribadi + HP). Jangan hilang.
   - `KEYSTORE_BASE64.txt` → isi untuk secret `KEYSTORE_BASE64`
   - `RAHASIA.txt` → berisi `KEYSTORE_PASSWORD`, `KEY_PASSWORD`, `KEY_ALIAS`
5. Masukkan keempat secret (tabel di bawah). Lalu **hapus run dan artifact-nya** (Actions → run → ⋯ → Delete) dan hapus file `keystore.yml`. Repo boleh dijadikan Public lagi.

**Cara B: di komputer.** Windows/Mac/Linux dengan JDK (atau Android Studio: *Build → Generate Signed Bundle → Create new*):

**Cara C: Termux di HP** (`pkg install openjdk-21`):
```
keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
```
Isi kata sandi dan data diri. Simpan `upload.jks` dan sandinya di tempat aman (cadangkan di 2 tempat).

Ubah ke base64:
```
base64 -w0 upload.jks > upload.b64
```
Di GitHub: **Settings → Secrets and variables → Actions → New repository secret**. Buat 4 secret:
| Nama | Isi |
|---|---|
| `KEYSTORE_BASE64` | isi file `upload.b64` |
| `KEYSTORE_PASSWORD` | sandi keystore |
| `KEY_ALIAS` | `upload` |
| `KEY_PASSWORD` | sandi kunci |

## 3. Build dan unduh AAB
1. Tab **Actions → Build Android → Run workflow**.
2. Setelah hijau ✔, buka run tersebut → **Artifacts → BilliardBusinessTycoon3D-AAB** (zip berisi file `.aab` yang sudah ditandatangani).
3. `versionCode` naik otomatis setiap build (wajib bertambah tiap unggahan ke Play).
Jika secret belum diisi, workflow tetap jalan tapi AAB tidak ditandatangani (tidak bisa diunggah).

**Ganti ID aplikasi** sebelum rilis pertama: file `capacitor.config.json` → `appId` (contoh `com.namamu.billiardbusiness`). ID **tidak bisa diubah** setelah dipublikasikan.

## 4. Hosting kebijakan privasi (wajib)
1. Edit `docs/privacy-policy.html`: ganti `GANTI-EMAIL@contoh.com` dan `GANTI-NAMA-PENGEMBANG`.
2. Karena kamu memakai metode ZIP, folder `docs` harus ada di **root repo** (bukan di dalam zip): **Add file → Create new file**, ketik `docs/privacy-policy.html`, tempel isinya, Commit.
3. **Settings → Pages** → Source: *Deploy from a branch* → Branch `main` → folder `/docs` → Save.
4. Tunggu 1–3 menit. URL-nya: `https://USERNAME.github.io/NAMA-REPO/privacy-policy.html`. Buka di peramban untuk memastikan tampil.
5. Isi URL itu juga di game: **Settings → Secrets and variables → Actions → tab Variables → New repository variable**, nama `PRIVACY_URL`, nilai URL tadi. Jalankan build ulang. Tombol "Kebijakan Privasi" di game akan membukanya.

## 5. Buat aplikasi di Play Console
1. Daftar akun developer (biaya sekali bayar US$25) dan selesaikan verifikasi identitas.
2. **Create app** → nama `Billiard Business Tycoon 3D`, bahasa Indonesia, **Game**, **Gratis**, centang pernyataan.
3. **Set up your app** (Dashboard) → isi satu per satu. Jawaban saran ada di `play-store/FORMULIR_PLAY_CONSOLE.md`:
   - Privacy policy (URL dari langkah 4)
   - Ads → Tidak
   - App access → tanpa akses khusus
   - Content rating → isi kuesioner IARC (hasilnya wajib ada)
   - Target audience → 13+ (atau 18+)
   - Data safety → tidak mengumpulkan data
   - Government apps, Financial features, Health → tidak
4. **Store listing**: salin teks dari `play-store/listing-id.md`. Unggah ikon 512×512 (`play-store/icon-512.png`), feature graphic 1024×500, dan minimal 2 screenshot ponsel dari game.

## 6. Uji tertutup lalu produksi
Akun developer **pribadi baru** biasanya wajib menjalankan **closed testing dengan minimal 12 penguji selama 14 hari berturut-turut** sebelum boleh mengajukan akses produksi. Akun organisasi biasanya tidak wajib. Cek status di Play Console bagian **Production access** untuk aturan terbaru akunmu.
1. **Testing → Closed testing → Create track** → buat daftar penguji (email Gmail) → unggah `.aab` → **Release**.
2. Bagikan link opt-in ke penguji; mereka harus bergabung dan tetap terpasang selama 14 hari.
3. Setelah syarat terpenuhi: **Apply for production** → jawab kuesioner singkat → tunggu persetujuan.
4. **Production → Create new release** → pilih AAB yang sama atau yang lebih baru → catatan rilis → **Review → Start rollout**. Review pertama bisa memakan beberapa hari.

## 7. Memperbarui aplikasi
Ubah isi zip di repo (unggah zip baru) → build → unggah AAB baru ke track yang diinginkan. `versionCode` otomatis lebih besar.

## 8. Daftar periksa sebelum rilis
- [ ] `appId` sudah unik dan final
- [ ] Email dan nama di kebijakan privasi sudah diganti, URL bisa dibuka publik
- [ ] AAB ditandatangani, `versionCode` lebih besar dari sebelumnya
- [ ] Content rating, Data safety, Target audience, Ads sudah diisi
- [ ] Target API: Capacitor 8 memakai API 36 secara bawaan. Play Console akan memperingatkan jika kurang, lihat **App bundle explorer** atau halaman peringatan
- [ ] Screenshot asli dari HP, bukan gambar yang menyesatkan
- [ ] Deskripsi tidak menjanjikan hal yang tidak ada (mis. uang sungguhan)
- [ ] Game diuji di HP asli: tidak crash, tidak patah-patah

## 9. Penyebab ditolak yang umum
| Masalah | Solusi |
|---|---|
| Tanpa kebijakan privasi / URL tidak bisa dibuka | Perbaiki hosting, pastikan bukan PDF dan tanpa login |
| Data safety tidak sesuai isi app | Jawab jujur; update formulir bila ada fitur baru |
| Menyesatkan di deskripsi/screenshot | Pakai screenshot asli dari game |
| Konten tiruan / hak cipta | Logo dan aset harus milikmu sendiri |
| Target API terlalu rendah | Pastikan build memakai Capacitor 8 (API 36) |

## 10. Top up berlian (Google Play Billing)
Versi ini sudah berisi tombol Top Up yang memakai Google Play Billing (plugin `@capgo/native-purchases`, dipasang otomatis oleh workflow). Item digital di dalam game wajib dijual lewat Play Billing; QRIS atau transfer di luar Play tidak diperbolehkan untuk itu.

**Syarat di akun:** profil pembayaran (merchant) harus aktif di Play Console (Setup → Payments profile). Jika belum, tombol beli tidak akan berfungsi.

**Buat 4 produk** di Play Console: *Monetize with Play → Products → In-app products* (atau *One-time products*). Gunakan ID **persis** berikut, status **Active**, dan atur harga rupiah:
| Product ID | Berlian | Harga saran |
|---|---|---|
| `gems_50` | 50 | Rp5.000 |
| `gems_120` | 120 | Rp10.000 |
| `gems_350` | 350 | Rp25.000 |
| `gems_800` | 800 | Rp50.000 |

**Uji tanpa bayar:**
1. *Setup → License testing* → tambahkan email Gmail penguji (termasuk emailmu). Pembelian oleh akun ini bersifat uji dan tidak menagih uang.
2. Unggah AAB baru ke track pengujian (Closed/Internal), pasang dari Play Store (bukan APK dari GitHub), lalu coba beli.
3. Beli **produk yang sama dua kali** untuk memastikan bisa dibeli ulang. Jika pembelian kedua gagal dengan pesan "sudah dimiliki", kirim pesan errornya ke saya.
4. Cek bahwa berlian bertambah dan tidak bertambah dua kali untuk satu pembelian.

**Catatan keamanan:** berlian diberikan langsung oleh aplikasi tanpa server validasi. Game ini offline dan tidak ada papan peringkat, jadi kecurangan hanya merugikan pemain itu sendiri. Jika nanti kamu menambah fitur online, tambahkan validasi token pembelian di server.

**Setelah produk aktif:** perbarui kebijakan privasi (sudah memuat bagian pembelian), isi kuesioner rating dengan "pembelian digital: Ya", dan pastikan Play Console tidak menampilkan peringatan versi Billing Library. Jika muncul peringatan versi, kabari saya.

## 10b. Top up tidak muncul / tombol tidak berfungsi
Buka **Lainnya → Toko**, bagian Top Up akan menampilkan status:
| Status | Arti dan solusi |
|---|---|
| "Plugin pembayaran tidak terdeteksi" | Kamu memakai build lama. Perbarui ke versi 1.1.1 atau lebih baru dari Play Store |
| "Produk belum ditemukan di Play" | Pastikan 4 produk berstatus **Active**, ID persis `gems_50`/`gems_120`/`gems_350`/`gems_800`, dan aplikasi dipasang dari jalur uji/produksi Play Store (bukan APK GitHub). Produk baru bisa butuh beberapa jam sebelum muncul |
| "Billing tidak didukung" | Perangkat tanpa Google Play atau akun Google belum login |
| Pesan error lain | Tekan "Coba lagi", lalu kirim pesan statusnya ke pengembang |

Setiap versi baru harus diunggah lagi ke Play Console (versionCode naik otomatis) lalu diperbarui di HP.

## 11. Masalah build
| Gejala | Kemungkinan penyebab |
|---|---|
| `ETARGET` saat npm install | Hapus `@capacitor/app` dari package.json. Untuk plugin billing, workflow mencoba versi 8 lalu versi terbaru |
| Gradle: Java version | Pastikan workflow memakai Java 21 (pakai `WORKFLOW_build.yml` terbaru) |
| AAB tidak ada di Artifacts | Secret `KEYSTORE_BASE64` belum diisi |
| Ikon bawaan Capacitor muncul | Langkah ikon gagal; kirim log langkah itu |
| Layar putih di game | Pastikan file `www/three.min.js` dibuat oleh langkah "Install dependensi" |
