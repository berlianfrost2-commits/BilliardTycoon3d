# Billiard Business Tycoon 3D

Game simulasi bisnis billiard 3D (Three.js + Capacitor) untuk Android.

- Panduan lengkap rilis ke Google Play: `PANDUAN_PLAYSTORE.md`
- Teks listing dan jawaban formulir: folder `play-store/`
- Kebijakan privasi (siap dihosting): `docs/privacy-policy.html`

Lisensi: MIT
