# Jawaban Formulir Play Console (saran)

Jawab sesuai kondisi sebenarnya aplikasimu. Ini panduan berdasarkan versi 1.0 yang tidak memakai akun, iklan, atau pembelian.

## App content → Kebijakan privasi
Isi URL halaman `privacy-policy.html` (harus bisa dibuka publik, bukan PDF).

## Ads (iklan)
"Does your app contain ads?" → **No**.

## App access
"All functionality is available without special access" → pilih opsi tanpa login/akses khusus.

## Content rating (IARC)
Kategori: Game. Jawab jujur. Untuk game ini:
- Pembelian digital (in-app purchases): **Ya** (berlian, lewat Google Play Billing)
- Kekerasan: Tidak
- Konten seksual: Tidak
- Bahasa kasar: Tidak
- Zat terlarang (narkoba/alkohol/rokok): Tidak (jangan menambah konten ini)
- Judi atau judi simulasi: **Tidak** (tidak ada taruhan atau uang sungguhan di dalam game; "liga" hanya simulasi bisnis)
- Interaksi pengguna / berbagi lokasi / pembelian digital: Tidak
Hasil biasanya "Semua umur / PEGI 3 / Everyone". Peringkat wajib diisi, aplikasi tanpa peringkat tidak bisa dirilis.

## Target audience
Pilih **13 tahun ke atas** (atau 18+ jika kamu ingin lebih aman). Jangan pilih kelompok usia anak-anak jika tidak ingin masuk kebijakan Keluarga.

## Data safety
- "Does your app collect or share any of the required user data types?" → **No**
- "Is all of the user data collected by your app encrypted in transit?" → tidak berlaku (tidak ada pengumpulan)
- Data hanya tersimpan lokal di perangkat → tidak dihitung sebagai "dikumpulkan".
- Kamu tidak perlu opsi penghapusan akun karena tidak ada akun.
Pembelian lewat Google Play Billing diproses Google; selama kamu tidak mengirim data pembelian ke server sendiri, kamu tidak perlu mendeklarasikannya sebagai data yang kamu kumpulkan. Jika nanti menambah iklan, analitik, atau server sendiri, formulir ini WAJIB diperbarui.

## Pembelian dalam aplikasi
Menu Monetize → Products → In-app products: buat produk `gems_50`, `gems_120`, `gems_350`, `gems_800` (lihat PANDUAN_PLAYSTORE.md bagian 10).

## Kategori & detail toko
Kategori: Game → Simulasi. Tag: Simulasi, Bisnis. Email kontak wajib.

## Government apps / News / COVID / Financial features / Health
Semua: **Bukan / tidak ada**.

## Harga & distribusi
Gratis. Pilih negara (mis. Indonesia dan lainnya). Centang pernyataan kepatuhan ekspor dan Content Guidelines.

## Aset grafis yang diperlukan
- Ikon aplikasi: 512 × 512 PNG → file `play-store/icon-512.png`
- Feature graphic: 1024 × 500 → file `play-store/feature-graphic-1024x500.png` (boleh kamu ganti dengan desain yang lebih bagus)
- Screenshot ponsel: minimal 2, rekomendasi 4–8 (ambil dari HP saat game berjalan: tampilan overview, menonton meja, menu bisnis, liga, laporan)
