(() => {
'use strict';
const E = window.Engine, R = E.R, HX = E.HX, HZ = E.HZ, POCKET = E.POCKET;
const $ = id => document.getElementById(id);
const SAVE = 'bbt3d_v4', TOP = 0.885, BALL_Y = TOP + R, MAX_LV = 10;
const COL_X = 5.0, ROW_Z = 3.7, DOOR_Z = 1.8, DAY = 300, MATCH_SEC = 100, PADR = 0.34;
const PRIVACY_URL = (window.APP_CONFIG && window.APP_CONFIG.privacyUrl) || 'https://GANTI-USERNAME.github.io/billiard-business-tycoon-3d/privacy-policy.html';
const VEN = [
  { n: 'Ruko Sederhana', cap: 2, cols: 2, maxLv: 4, cost: 0, rent: 5 }, { n: 'Billiard Kampung', cap: 4, cols: 2, maxLv: 5, cost: 5000, rent: 18 },
  { n: 'Billiard Kota', cap: 6, cols: 2, maxLv: 6, cost: 30000, rent: 45 }, { n: 'Pusat Billiard', cap: 9, cols: 3, maxLv: 7, cost: 150000, rent: 110 },
  { n: 'Billiard Premium', cap: 12, cols: 3, maxLv: 8, cost: 7e5, rent: 260 }, { n: 'Billiard Lounge', cap: 16, cols: 4, maxLv: 9, cost: 3e6, rent: 600 },
  { n: 'Arena Nasional', cap: 20, cols: 4, maxLv: 10, cost: 5e6, rent: 1400 }, { n: 'Arena Internasional', cap: 24, cols: 4, maxLv: 10, cost: 15e6, rent: 3200 }];
const FRAMEC = [0x6b4426, 0x5a3820, 0x4a2a12, 0x2b1608, 0x3a1d0c, 0x1d1d22, 0x24262c, 0x2a2144, 0x4a1020, 0x161212];
const CLOTHS = ['#1f6b35', '#1d6a3a', '#16603f', '#0f6a4f', '#0b6a63', '#0b5d7a', '#1b4f86', '#4a2a86', '#7a1f5a', '#8a1c2c'];
const ACC = [0xb0b0b0, 0xc9a227, 0xc9a227, 0xe8c14a, 0xffd34d, 0x35e0ff, 0x9bd2ff, 0xc79bff, 0xff6f9a, 0xffe27a];
const TNAME = ['Meja Kayu Sederhana', 'Meja Hijau Klasik', 'Meja Semi-Pro', 'Meja Profesional', 'Meja VIP Emas', 'Meja Neon Racing', 'Meja Karbon Turnamen', 'Meja Kristal', 'Meja Royal', 'Meja Legendaris'];
const TDESC = ['Bingkai kayu polos dengan kaki balok.', 'Kaki bubut kayu dan sudut kuningan.', 'Bingkai membulat, stiker garis emas.', 'Stiker logo, lambang di kain, kaki bulat.', 'Bingkai emas berukir dan filigree.', 'Lampu LED bawah meja dan stiker balap.', 'Rangka pedestal serat karbon.', 'Hiasan kristal dan stiker prisma.', 'Mahkota dan ornamen kerajaan.', 'Edisi Legendaris: permata dan cahaya berdenyut.'];
const BALLC = [0xffffff, 0xf1c40f, 0x2e86de, 0xe74c3c, 0x8e44ad, 0xe67e22, 0x27ae60, 0x7b241c, 0x111111, 0xf5d142];
const NAMES = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eko', 'Fajar', 'Gita', 'Hadi', 'Indra', 'Joko', 'Kiki', 'Lina', 'Maya', 'Nando', 'Oki', 'Putri', 'Rian', 'Sari', 'Tono', 'Udin', 'Wawan', 'Yoga', 'Zaki', 'Bayu', 'Dimas', 'Rani', 'Tia', 'Vino', 'Lutfi', 'Nia', 'Hendra', 'Salsa'];
const rr = (a, b) => a + Math.random() * (b - a);
const pick = a => a[Math.random() * a.length | 0];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// ===== Data & simpan =====
const DEF = () => ({ name: '', cash: 600, gems: 25, total: 0, venue: 1, tables: [{ lv: 1, cond: 100 }], staff: { kasir: 0, pelayan: 0, bersih: 0, pelatih: 0 },
  fac: { cafe: 0, ac: 0, park: 0, toilet: 0, musik: 0, tribun: 0, vip: 0 }, price: 3, boostUntil: 0, matches: 0, drinks: 0, cleaned: 0, leagues: 0, trophies: 0, daily: 0,
  quality: 'auto', mute: false, tx: {}, rating: 3, day: 1, dayT: 0, fin: { rev: {}, exp: {}, hist: [] }, revs: [], ach: {}, mis: { day: 0, list: [] }, lcd: 0, tutorial: false, t: Date.now() });
let S = (() => { let d = {}; try { d = JSON.parse(localStorage.getItem(SAVE)) || {}; } catch (e) {} const o = Object.assign(DEF(), d); for (const k of ['staff', 'fac', 'mis', 'ach', 'tx']) o[k] = Object.assign(DEF()[k] || {}, d[k] || {}); o.fin = Object.assign(DEF().fin, d.fin || {}); o.fin.rev = o.fin.rev || {}; o.fin.exp = o.fin.exp || {}; if (!Array.isArray(o.tables) || !o.tables.length) o.tables = [{ lv: 1, cond: 100 }]; return o; })();
S.league = null; // liga tidak dilanjutkan setelah aplikasi ditutup
const save = () => { if (window.__reset) return; try { S.t = Date.now(); const c = Object.assign({}, S); localStorage.setItem(SAVE, JSON.stringify(c)); } catch (e) {} };
const fmt = n => { n = Math.abs(n) < 1 && n !== 0 ? n : n; const a = Math.abs(n), s = n < 0 ? '-' : ''; return s + (a >= 1e9 ? (a / 1e9).toFixed(2) + 'M' : a >= 1e6 ? (a / 1e6).toFixed(2) + 'jt' : a >= 1e4 ? (a / 1e3).toFixed(1) + 'rb' : Math.floor(a) + ''); };
const tables = [], chars = [], ctls = [], staffList = [], dirts = [], specs = [];
let sel = 0, tab = null, sub = {}, LG = null;

// ===== Ekonomi =====
const boosted = () => Date.now() < S.boostUntil;
const priceMult = () => 0.4 + 0.2 * S.price;
const ratingMult = () => 0.8 + 0.08 * S.rating;
const feeBase = lv => 60 * Math.pow(1.42, lv - 1);
const condMult = t => 0.6 + 0.4 * t.cond / 100;
const matchFee = t => feeBase(t.lv) * priceMult() * ratingMult() * condMult(t) * (boosted() ? 2 : 1) * (1 + 0.04 * S.fac.ac + 0.03 * S.fac.musik);
const SAL = { kasir: 10, pelayan: 9, bersih: 7, pelatih: 12 };
const expRent = () => VEN[S.venue - 1].rent / 60;
const expElec = () => S.tables.reduce((a, t) => a + 1.5 * Math.pow(1.3, t.lv - 1), 0) / 60 * (1 + 0.2 * S.fac.ac + 0.1 * S.fac.musik);
const expStaff = () => Object.keys(SAL).reduce((a, k) => a + SAL[k] * S.staff[k] * (1 + 0.35 * (S.venue - 1)), 0) / 60;
const expFac = () => Object.keys(S.fac).reduce((a, k) => a + S.fac[k] * 2 * S.venue, 0) / 60;
const expenses = () => expRent() + expElec() + expStaff() + expFac();
const revPerSec = () => S.tables.reduce((a, t) => a + matchFee(t) / 125, 0) * 0.8;
const net = () => revPerSec() - expenses();
const stars = () => Math.round(S.rating * 2) / 2;
const upCost = lv => Math.round(180 * Math.pow(1.85, lv - 1));
const buyCost = () => Math.round(450 * Math.pow(1.75, S.tables.length - 1));
const svcCost = lv => Math.round(40 * Math.pow(1.5, lv - 1));
const FAC = {
  cafe: { n: 'Kafe & Minuman', ic: '☕', base: 500, max: 5, minV: 1, d: 'Pesanan minuman diantar pelayan' },
  ac: { n: 'AC & Ruang Nyaman', ic: '❄️', base: 800, max: 5, minV: 1, d: 'Rating naik, tarif +4%/lv' },
  park: { n: 'Lahan Parkir', ic: '🅿️', base: 600, max: 5, minV: 1, d: 'Pengunjung lebih sering datang' },
  toilet: { n: 'Toilet Bersih', ic: '🚻', base: 1500, max: 3, minV: 2, d: 'Rating naik' },
  musik: { n: 'Sound System', ic: '🔊', base: 2500, max: 5, minV: 2, d: 'Rating naik, tarif +3%/lv' },
  tribun: { n: 'Tribun Penonton', ic: '🏟️', base: 9000, max: 5, minV: 3, d: 'Penonton liga lebih banyak' },
  vip: { n: 'Lounge VIP', ic: '🛋️', base: 40000, max: 5, minV: 4, d: 'Tamu VIP bayar lebih besar' }
};
const STAFF = {
  kasir: { n: 'Kasir', ic: '🧾', base: 600, d: 'Menerima pembayaran. Tanpa kasir 20% pembayaran hilang.' },
  pelayan: { n: 'Pelayan', ic: '🍹', base: 900, d: 'Mengantar minuman ke meja (butuh Kafe).' },
  bersih: { n: 'Petugas Kebersihan', ic: '🧹', base: 700, d: 'Mengepel noda di lantai, menjaga rating.' },
  pelatih: { n: 'Pelatih', ic: '🎓', base: 1200, d: 'Melatih pemain pemula, bayaran +15% per sesi.' }
};
const stCost = (k, l) => Math.round(STAFF[k].base * Math.pow(2.4, l));
const facCost = (k, l) => Math.round(FAC[k].base * Math.pow(2.2, l));
function earn(cat, n) { n = Math.round(n); S.cash += n; S.total += n; S.fin.rev[cat] = (S.fin.rev[cat] || 0) + n; prog('earn', n); }
function pay(cat, n) { const a = Math.min(S.cash, n); S.cash -= a; S.fin.exp[cat] = (S.fin.exp[cat] || 0) + a; if (a < n * 0.9) S.broke = 3; }
function bounds() { const v = VEN[S.venue - 1], rows = Math.ceil(v.cap / v.cols); return { W0: -4.4, W1: (v.cols - 1) * COL_X + 3.9, Z0: -3.4, Z1: rows * ROW_Z - 0.6, cols: v.cols, rows }; }
const tpos = i => { const b = bounds(); return new THREE.Vector3((i % b.cols) * COL_X, 0, Math.floor(i / b.cols) * ROW_Z); };

// rating, kebersihan, ulasan
const cleanliness = () => clamp(1 - dirts.length / 10, 0, 1);
const avgCond = () => S.tables.reduce((a, t) => a + t.cond, 0) / S.tables.length / 100;
function targetRating() {
  const f = S.fac, fac = Math.min(1.5, f.cafe * 0.1 + f.ac * 0.12 + f.toilet * 0.16 + f.musik * 0.1 + f.vip * 0.06 + f.park * 0.06 + f.tribun * 0.04);
  return clamp(1.3 + cleanliness() * 1.2 + avgCond() * 0.9 + fac + (3 - S.price) * 0.12 + S.staff.pelatih * 0.04 - (S.broke > 0 ? 0.5 : 0), 1, 5);
}
const REV_POS = ['Meja bersih dan nyaman!', 'Tempat asyik, wajib balik lagi.', 'Pelayanan ramah, kafenya enak.', 'Meja bagus, bola meluncur mulus.', 'Fasilitas lengkap dan rapi.'];
const REV_NEG = ['Lantai kotor, tolong dibersihkan.', 'Kain meja sudah usang.', 'Antrean lama dan harga mahal.', 'Toilet kurang bersih.', 'Pelayanan kurang cepat.'];
function addReview() { const st = Math.max(1, Math.min(5, Math.round(S.rating + rr(-1, 1)))); S.revs.unshift({ st, who: pick(NAMES), txt: st >= 4 ? pick(REV_POS) : pick(REV_NEG) }); S.revs.length = Math.min(S.revs.length, 15); }

// misi & pencapaian
const MP = [
  { id: 'matches', t: n => `Layani ${n} pertandingan pengunjung`, n: [3, 5, 8] }, { id: 'drinks', t: n => `Antar ${n} minuman ke pelanggan`, n: [2, 4] },
  { id: 'clean', t: n => `Bersihkan ${n} noda lantai`, n: [3, 6] }, { id: 'service', t: n => `Servis meja ${n} kali`, n: [1, 2] }, { id: 'up', t: n => `Upgrade meja ${n} kali`, n: [1, 2] },
  { id: 'earn', t: n => `Raih pendapatan $${fmt(n)}`, n: [0] }];
function genMissions() {
  const day = Math.floor(Date.now() / 864e5); if (S.mis.day === day && S.mis.list.length) return;
  S.mis = { day, list: MP.slice().sort(() => Math.random() - 0.5).slice(0, 3).map(p => ({ id: p.id, need: p.id === 'earn' ? Math.max(500, Math.round(revPerSec() * 400 / 100) * 100) : pick(p.n), got: 0, done: false, claimed: false, gem: Math.random() < 0.5 })) };
}
function prog(id, k) { for (const m of S.mis.list) if (m.id === id && !m.done) { m.got += k; if (m.got >= m.need) { m.done = true; toast('✅ Misi selesai! Klaim di Lainnya → Misi'); } } }
const ACH = [
  { id: 'm25', n: 'Pebisnis Pemula', d: 'Layani 25 pertandingan', ok: () => S.matches >= 25, g: 5 }, { id: 'm250', n: 'Langganan Ramai', d: 'Layani 250 pertandingan', ok: () => S.matches >= 250, g: 20 },
  { id: 't4', n: 'Ruang Penuh', d: 'Punya 4 meja', ok: () => S.tables.length >= 4, g: 8 }, { id: 't12', n: 'Raja Meja', d: 'Punya 12 meja', ok: () => S.tables.length >= 12, g: 30 },
  { id: 'v3', n: 'Naik Kelas', d: 'Capai lokasi ke-3', ok: () => S.venue >= 3, g: 10 }, { id: 'v6', n: 'Kelas Atas', d: 'Capai lokasi ke-6', ok: () => S.venue >= 6, g: 40 },
  { id: 'l5', n: 'Meja Hebat', d: 'Upgrade satu meja ke Lv.5', ok: () => S.tables.some(t => t.lv >= 5), g: 10 }, { id: 'l10', n: 'Meja Legendaris', d: 'Upgrade satu meja ke Lv.10', ok: () => S.tables.some(t => t.lv >= 10), g: 60 },
  { id: 'r45', n: 'Bintang Lima', d: 'Rating 4,5 atau lebih', ok: () => S.rating >= 4.5, g: 25 }, { id: 'lg1', n: 'Penyelenggara', d: 'Selenggarakan 1 liga', ok: () => S.leagues >= 1, g: 12 },
  { id: 'lg5', n: 'Promotor Liga', d: 'Selenggarakan 5 liga', ok: () => S.leagues >= 5, g: 35 }, { id: 'st4', n: 'Tim Lengkap', d: 'Rekrut keempat jenis karyawan', ok: () => Object.keys(S.staff).every(k => S.staff[k] > 0), g: 15 },
  { id: 'e1', n: 'Jutawan', d: 'Total pendapatan $1jt', ok: () => S.total >= 1e6, g: 25 }];

function toast(m) { const t = $('toast'); t.textContent = m; t.style.opacity = 1; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.opacity = 0, 2600); }
let AC = null, sfxN = 0;
function sfx(kind, v) {
  if (S.mute || sfxN > 3) return; sfxN++;
  try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain(); o.connect(g); g.connect(AC.destination);
    const f = { click: 1500, rail: 320, pot: 170, cue: 760, win: 880, coin: 1200 }[kind] || 600; o.type = kind === 'pot' ? 'sine' : 'triangle'; o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 0.5, t + 0.08);
    g.gain.setValueAtTime(Math.min(0.2, 0.03 + (v || 1) * 0.035), t); g.gain.exponentialRampToValueAtTime(0.0001, t + (kind === 'pot' ? 0.22 : 0.08)); o.start(t); o.stop(t + 0.25); } catch (e) {}
}


// ===== Top up berlian (Google Play Billing) =====
const PACKS = [{ id: 'gems_50', g: 50, rp: 'Rp5.000' }, { id: 'gems_120', g: 120, rp: 'Rp10.000' }, { id: 'gems_350', g: 350, rp: 'Rp25.000' }, { id: 'gems_800', g: 800, rp: 'Rp50.000' }];
const NP = (() => { try { const C = window.Capacitor; if (C && C.isNativePlatform && C.isNativePlatform()) return C.registerPlugin('NativePurchases'); } catch (e) {} return null; })();
const bill = { ok: false, price: {}, busy: false };
function grantPack(id, txid) {
  const p = PACKS.find(q => q.id === id); if (!p || !txid) return false; const k = String(txid); if (S.tx[k]) return false;
  S.tx[k] = 1; const ks = Object.keys(S.tx); if (ks.length > 80) delete S.tx[ks[0]]; S.gems += p.g; save(); return true;
}
async function billingInit() {
  if (!NP) return;
  try {
    const r = await NP.isBillingSupported(); bill.ok = !!(r && r.isBillingSupported); if (!bill.ok) return;
    const res = await NP.getProducts({ productIdentifiers: PACKS.map(p => p.id), productType: 'inapp' });
    (res.products || []).forEach(pr => { bill.price[pr.identifier || pr.productIdentifier || pr.id] = pr.priceString || ''; });
    try { const rp = await NP.getPurchases({ productType: 'inapp' }); for (const pu of (rp.purchases || [])) { const id = pu.productIdentifier || pu.identifier, tid = pu.transactionId || pu.orderId || pu.purchaseToken; if (grantPack(id, tid)) toast('Pembelian dipulihkan: +' + PACKS.find(q => q.id === id).g + ' 💎'); } } catch (e) {}
  } catch (e) { bill.ok = false; }
}
async function buyPack(id) {
  if (!NP || !bill.ok) { toast('Top up tersedia di aplikasi dari Google Play dan butuh koneksi internet'); return; } if (bill.busy) return; bill.busy = true;
  try { const tx = await NP.purchaseProduct({ productIdentifier: id, productType: 'inapp', quantity: 1 }); const ok = grantPack(id, tx && (tx.transactionId || tx.orderId || tx.purchaseToken)); if (ok) { sfx('win', 2); toast('Terima kasih! +' + PACKS.find(q => q.id === id).g + ' 💎'); } else toast('Pembelian sudah tercatat'); }
  catch (e) { toast('Pembelian dibatalkan atau gagal'); }
  bill.busy = false; if (tab) render(); hud();
}

// ===== Renderer & cahaya =====
const QS = S.quality === 'low' ? { pr: 1, sh: 0, aa: false } : S.quality === 'mid' ? { pr: 1.5, sh: 1024, aa: true } : { pr: 2.25, sh: 2048, aa: true };
const renderer = new THREE.WebGLRenderer({ antialias: QS.aa, powerPreference: 'high-performance' });
let prCur = Math.min(window.devicePixelRatio || 1, QS.pr); renderer.setPixelRatio(prCur);
renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.2;
if (QS.sh) { renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; }
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0a0c10); scene.fog = new THREE.Fog(0x0a0c10, 28, 80);
const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 120);
const UP = new THREE.Vector3(0, 1, 0), camT = new THREE.Vector3(), camP = new THREE.Vector3(), tgtT = new THREE.Vector3(), tgtP = new THREE.Vector3();
scene.add(new THREE.HemisphereLight(0xfff1dd, 0x3a2e26, 0.85));
const sun = new THREE.DirectionalLight(0xfff0dd, 0.95); sun.position.set(8, 16, 10);
if (QS.sh) { sun.castShadow = true; sun.shadow.mapSize.set(QS.sh, QS.sh); Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 2, far: 50 }); sun.shadow.bias = -0.0004; }
scene.add(sun); scene.add(sun.target);
const fill = new THREE.DirectionalLight(0x9bb8ff, 0.28); fill.position.set(-8, 8, -6); scene.add(fill);
const CAST = !!QS.sh;
function fitSun(b) { const cx = (b.W0 + b.W1) / 2, cz = (b.Z0 + b.Z1) / 2, ext = Math.max(b.W1 - b.W0, b.Z1 - b.Z0) / 2 + 3; sun.target.position.set(cx, 0, cz); sun.position.set(cx + 8, 16 + ext * 0.4, cz + 10); if (QS.sh) { Object.assign(sun.shadow.camera, { left: -ext, right: ext, top: ext, bottom: -ext, far: 60 + ext }); sun.shadow.camera.updateProjectionMatrix(); } }

// ===== Tekstur =====
function ctex(w, h, fn, rx, ry) { const c = document.createElement('canvas'); c.width = w; c.height = h; fn(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; if (rx) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); } return t; }
function grain(x, w, h, n, a, col) { x.fillStyle = col; for (let i = 0; i < n; i++) { x.globalAlpha = Math.random() * a; x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2); } x.globalAlpha = 1; }
function floorTex(type, W, H) {
  return ctex(512, 512, (x, w, h) => {
    if (type === 0) { x.fillStyle = '#7d7b76'; x.fillRect(0, 0, w, h); grain(x, w, h, 8000, 0.35, '#000'); grain(x, w, h, 3000, 0.3, '#fff'); x.strokeStyle = '#0003'; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(Math.random() * w, Math.random() * h); x.lineTo(Math.random() * w, Math.random() * h); x.stroke(); } }
    else if (type === 1) { x.fillStyle = '#d9cfbd'; x.fillRect(0, 0, w, h); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { x.fillStyle = `rgba(0,0,0,${Math.random() * 0.07})`; x.fillRect(i * 128, j * 128, 128, 128); } x.strokeStyle = '#9c9382'; x.lineWidth = 3; for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(i * 128, 0); x.lineTo(i * 128, h); x.moveTo(0, i * 128); x.lineTo(w, i * 128); x.stroke(); } grain(x, w, h, 2500, 0.2, '#000'); }
    else if (type === 2) { for (let i = 0; i < 8; i++) { x.fillStyle = `hsl(28,48%,${38 + Math.random() * 12}%)`; x.fillRect(i * 64, 0, 64, h); x.strokeStyle = 'rgba(50,25,8,.25)'; for (let k = 0; k < 14; k++) { x.beginPath(); const px = i * 64 + Math.random() * 64; x.moveTo(px, 0); x.lineTo(px + Math.random() * 6 - 3, h); x.stroke(); } x.fillStyle = '#0005'; x.fillRect(i * 64, 0, 2, h); } }
    else if (type === 3) { x.fillStyle = '#e8e6e2'; x.fillRect(0, 0, w, h); x.lineCap = 'round'; for (let i = 0; i < 16; i++) { x.strokeStyle = `rgba(110,115,130,${0.15 + Math.random() * 0.3})`; x.lineWidth = 1 + Math.random() * 3; x.beginPath(); x.moveTo(Math.random() * w, 0); x.bezierCurveTo(Math.random() * w, h * 0.3, Math.random() * w, h * 0.6, Math.random() * w, h); x.stroke(); } grain(x, w, h, 1500, 0.15, '#000'); }
    else { x.fillStyle = '#1b1d23'; x.fillRect(0, 0, w, h); x.strokeStyle = '#c9a22755'; x.lineWidth = 2; for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(i * 128, 0); x.lineTo(i * 128, h); x.moveTo(0, i * 128); x.lineTo(w, i * 128); x.stroke(); } grain(x, w, h, 3000, 0.25, '#fff'); }
  }, W / 3, H / 3);
}
const FA = HX + 0.24, FB = HZ + 0.24, cache = {};
function frameTex(lv) {
  const k = 'f' + lv; if (cache[k]) return cache[k];
  const hex = '#' + FRAMEC[lv - 1].toString(16).padStart(6, '0'), gold = '#' + ACC[lv - 1].toString(16).padStart(6, '0');
  const t = ctex(1024, 512, (x, w, h) => {
    x.fillStyle = hex; x.fillRect(0, 0, w, h);
    if (lv <= 5) for (let i = 0; i < 40; i++) { x.fillStyle = `rgba(255,220,170,${Math.random() * 0.08})`; x.fillRect(Math.random() * w, Math.random() * h, 60 + Math.random() * 200, 1 + Math.random() * 2); }
    else if (lv <= 7) { x.fillStyle = 'rgba(255,255,255,.05)'; for (let i = 0; i < w; i += 8) for (let j = 0; j < h; j += 8) if ((i + j) % 16 === 0) x.fillRect(i, j, 8, 8); }
    const X = v => (v + FA) / (2 * FA) * w, Y = v => (0.5 - v / (2 * FB)) * h;
    x.fillStyle = lv >= 4 ? gold : '#eae3d2';
    for (let k2 = 1; k2 <= 3; k2++) for (const sx of [-1, 1]) for (const sy of [-1, 1]) { x.beginPath(); x.arc(X(sx * HX * k2 / 4), Y(sy * (HZ + 0.12)), 8, 0, 7); x.fill(); }
    for (const sx of [-1, 1]) for (const v of [-0.4, 0, 0.4]) { x.beginPath(); x.arc(X(sx * (HX + 0.12)), Y(v), 8, 0, 7); x.fill(); }
    if (lv >= 5) { x.strokeStyle = gold; x.lineWidth = 3; x.strokeRect(X(-HX - 0.06), Y(HZ + 0.06), X(HX + 0.06) - X(-HX - 0.06), Y(-HZ - 0.06) - Y(HZ + 0.06)); x.lineWidth = 1.5; x.strokeRect(X(-HX - 0.16), Y(HZ + 0.16), X(HX + 0.16) - X(-HX - 0.16), Y(-HZ - 0.16) - Y(HZ + 0.16)); }
    if (lv >= 9) { x.fillStyle = gold; for (const sx of [-1, 1]) for (const sy of [-1, 1]) { x.beginPath(); x.arc(X(sx * (HX + 0.12)), Y(sy * (HZ + 0.12)), 14, 0, 7); x.fill(); } }
  });
  t.repeat.set(1 / (2 * FA), 1 / (2 * FB)); t.offset.set(0.5, 0.5); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return cache[k] = t;
}
function clothTex(lv) {
  const k = 'c' + lv; if (cache[k]) return cache[k];
  return cache[k] = ctex(1024, 512, (x, w, h) => {
    x.fillStyle = CLOTHS[lv - 1]; x.fillRect(0, 0, w, h); grain(x, w, h, 16000, 0.16, '#000'); grain(x, w, h, 9000, 0.1, '#fff');
    const s = w / (2 * HX), u = v => (v + HX) * s, vv = v => (v + HZ) * s;
    x.fillStyle = 'rgba(0,0,0,.18)'; x.fillRect(0, 0, w, 14); x.fillRect(0, h - 14, w, 14); x.fillRect(0, 0, 14, h); x.fillRect(w - 14, 0, 14, h);
    x.strokeStyle = 'rgba(255,255,255,.12)'; x.lineWidth = 2; x.beginPath(); x.moveTo(u(-0.6), 0); x.lineTo(u(-0.6), h); x.stroke();
    x.fillStyle = 'rgba(255,255,255,.35)'; x.beginPath(); x.arc(u(0.45), vv(0), 4, 0, 7); x.fill();
    if (lv >= 4) { x.save(); x.globalAlpha = 0.14; x.fillStyle = '#fff'; x.strokeStyle = '#fff'; x.lineWidth = 4; x.beginPath(); x.arc(u(-0.05), vv(0), 70, 0, 7); x.stroke(); x.font = 'bold 54px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('BB', u(-0.05), vv(0) + 3); x.restore(); }
    for (const p of E.POCKETS) { x.fillStyle = '#050505'; x.beginPath(); x.arc(u(p[0]), vv(p[1]), POCKET * s, 0, 7); x.fill(); x.strokeStyle = 'rgba(40,25,10,.8)'; x.lineWidth = 8; x.stroke(); }
  });
}
function decalTex(lv, long) {
  const k = 'd' + lv + (long ? 'L' : 'S'); if (cache[k]) return cache[k]; const gold = '#' + ACC[lv - 1].toString(16).padStart(6, '0');
  return cache[k] = ctex(long ? 512 : 256, 64, (x, w, h) => {
    x.clearRect(0, 0, w, h);
    if (lv >= 3) { x.strokeStyle = gold; x.lineWidth = 3; x.strokeRect(4, 6, w - 8, h - 12); }
    if (lv >= 5) { x.lineWidth = 1.5; for (let i = 20; i < w - 20; i += 18) { x.beginPath(); x.arc(i, h / 2, 6, 0, Math.PI); x.stroke(); } }
    if (lv === 6) { x.fillStyle = gold; x.globalAlpha = 0.9; x.beginPath(); x.moveTo(w * 0.1, h); x.lineTo(w * 0.2, 0); x.lineTo(w * 0.28, 0); x.lineTo(w * 0.18, h); x.fill(); x.beginPath(); x.moveTo(w * 0.3, h); x.lineTo(w * 0.4, 0); x.lineTo(w * 0.43, 0); x.lineTo(w * 0.33, h); x.fill(); x.globalAlpha = 1; }
    if (lv >= 8) { for (let i = 0; i < 8; i++) { x.fillStyle = `hsla(${200 + i * 20},90%,70%,.5)`; x.beginPath(); const px = 20 + i * (w - 40) / 8; x.moveTo(px, h - 8); x.lineTo(px + 14, 8); x.lineTo(px + 28, h - 8); x.fill(); } }
    if (long && lv >= 2) { x.fillStyle = gold; x.font = 'bold 26px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(lv >= 9 ? '♛ BILLIARD BUSINESS ♛' : 'BILLIARD BUSINESS', w * 0.5, h / 2 + 1); x.font = 'bold 16px sans-serif'; x.textAlign = 'right'; x.fillText('LV ' + lv, w - 14, h - 14); }
    else if (lv >= 2) { x.fillStyle = gold; x.font = 'bold 26px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(lv >= 9 ? '♛' : '🎱', w / 2, h / 2 + 2); }
  });
}
const poolTex = ctex(128, 128, (x, w, h) => { const g = x.createRadialGradient(64, 64, 4, 64, 64, 62); g.addColorStop(0, 'rgba(255,225,170,.5)'); g.addColorStop(1, 'rgba(255,225,170,0)'); x.fillStyle = g; x.fillRect(0, 0, w, h); });
const ballMat = [];
for (let n = 0; n <= 9; n++) {
  const col = '#' + BALLC[n].toString(16).padStart(6, '0');
  const tx = ctex(256, 128, (x, w, h) => { x.fillStyle = (n === 0 || n === 9) ? '#f4f4ef' : col; x.fillRect(0, 0, w, h); if (n === 9) { x.fillStyle = col; x.fillRect(0, h * 0.25, w, h * 0.5); }
    for (const cx of [w * 0.25, w * 0.75]) { if (n > 0) { x.fillStyle = '#fff'; x.beginPath(); x.arc(cx, h / 2, 22, 0, 7); x.fill(); x.fillStyle = '#111'; x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(String(n), cx, h / 2 + 2); } else { x.fillStyle = '#c0392b'; x.beginPath(); x.arc(cx, h / 2, 6, 0, 7); x.fill(); } } });
  ballMat.push(new THREE.MeshStandardMaterial({ map: tx, roughness: 0.14, metalness: 0.05 }));
}
const ballGeo = new THREE.SphereGeometry(R, 22, 16);
const lam = c => new THREE.MeshLambertMaterial({ color: c });
const std = (c, r, m, e) => new THREE.MeshStandardMaterial({ color: c, roughness: r == null ? 0.6 : r, metalness: m || 0, emissive: e || 0x000000 });
function box(g, w, h, d, mat, x, y, z, cast) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.castShadow = !!cast && CAST; m.receiveShadow = true; g.add(m); return m; }
function cyl(g, rt, rb, h, mat, x, y, z, seg) { const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg || 12), mat); m.position.set(x, y, z); m.castShadow = CAST; g.add(m); return m; }
function labelTex(txt, w, h, bg, fg, fs) { return ctex(w, h, (x, ww, hh) => { x.fillStyle = bg; x.fillRect(0, 0, ww, hh); x.fillStyle = fg; x.font = 'bold ' + (fs || 40) + 'px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(txt, ww / 2, hh / 2 + 2); }); }

// ===== Lokasi & fasilitas =====
const COUNTER = { x: -3.2, z: -1.5 };
const venueG = new THREE.Group(); scene.add(venueG); const anim = [];
const signC = document.createElement('canvas'); signC.width = 1024; signC.height = 256;
const signT = new THREE.CanvasTexture(signC); signT.encoding = THREE.sRGBEncoding;
function drawSign() {
  const x = signC.getContext('2d'); x.shadowBlur = 0; x.fillStyle = '#10161a'; x.fillRect(0, 0, 1024, 256); x.strokeStyle = '#ffd75e'; x.lineWidth = 10; x.strokeRect(10, 10, 1004, 236);
  const t = (S.name || 'BILLIARD BUSINESS').toUpperCase(); let fs = 100; x.font = 'bold ' + fs + 'px sans-serif'; while (x.measureText(t).width > 940 && fs > 30) { fs -= 4; x.font = 'bold ' + fs + 'px sans-serif'; }
  x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#fff3b0'; x.shadowColor = '#ffb300'; x.shadowBlur = 24; x.fillText(t, 512, 105); x.shadowBlur = 0; x.font = '34px sans-serif'; x.fillStyle = '#9fe6b0'; x.fillText('BILLIARD  •  CAFE  •  LOUNGE', 512, 205); signT.needsUpdate = true;
}
const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 0.9), new THREE.MeshBasicMaterial({ map: signT })); drawSign();
const hl = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2 + 1.1, HZ * 2 + 1.1), new THREE.MeshBasicMaterial({ color: 0xffdd55, transparent: true, opacity: 0.22, depthWrite: false })); hl.rotation.x = -Math.PI / 2; hl.position.y = 0.016;
const slot = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2 + 0.6, HZ * 2 + 0.6), new THREE.MeshBasicMaterial({ map: labelTex('+ MEJA BARU', 256, 128, '#12301c', '#7dffa0', 30), transparent: true, opacity: 0.55, depthWrite: false })); slot.rotation.x = -Math.PI / 2; slot.position.y = 0.02;
const WALLC = [0x8d8272, 0xc9bb9b, 0xb59a74, 0x3b4658, 0x1d2333, 0x2a1f33, 0x1a2a36, 0x16161c];
function carMesh(G, x, z, col) {
  const g = new THREE.Group(); g.position.set(x, 0, z);
  box(g, 1.9, 0.5, 0.95, std(col, 0.3, 0.4), 0, 0.42, 0, true); box(g, 1.0, 0.4, 0.85, std(0x9ec7e8, 0.1, 0.6), -0.1, 0.84, 0);
  for (const sx of [-0.6, 0.6]) for (const sz of [-0.48, 0.48]) { const w = cyl(g, 0.22, 0.22, 0.18, lam(0x151515), sx, 0.22, sz, 10); w.rotation.x = Math.PI / 2; }
  box(g, 0.05, 0.12, 0.2, std(0xffffcc, 0.2, 0, 0xffffaa), 0.96, 0.5, 0.3); box(g, 0.05, 0.12, 0.2, std(0xffffcc, 0.2, 0, 0xffffaa), 0.96, 0.5, -0.3); G.add(g);
}
function buildVenue() {
  while (venueG.children.length) venueG.remove(venueG.children[0]); anim.length = 0;
  const b = bounds(), W0 = b.W0, W1 = b.W1, Z0 = b.Z0, Z1 = b.Z1, v = S.venue, G = venueG, cx = (W0 + W1) / 2, cz = (Z0 + Z1) / 2, wid = W1 - W0, dep = Z1 - Z0; fitSun(b);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(wid, dep), new THREE.MeshStandardMaterial({ map: floorTex([0, 1, 2, 3, 4, 4, 3, 4][v - 1], wid, dep), roughness: v >= 4 ? 0.2 : 0.6, metalness: v >= 4 ? 0.1 : 0 })); fl.rotation.x = -Math.PI / 2; fl.position.set(cx, 0, cz); fl.receiveShadow = true; G.add(fl);
  const gnd = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), lam(0x14161a)); gnd.rotation.x = -Math.PI / 2; gnd.position.set(cx, -0.03, cz); G.add(gnd);
  const wm = lam(WALLC[v - 1]), d0 = DOOR_Z - 0.65, d1 = DOOR_Z + 0.65;
  box(G, wid + 0.4, 3.4, 0.2, wm, cx, 1.7, Z0 - 0.1); box(G, 0.2, 3.4, dep, wm, W1 + 0.1, 1.7, cz);
  box(G, 0.2, 3.4, d0 - Z0, wm, W0 - 0.1, 1.7, (Z0 + d0) / 2); box(G, 0.2, 3.4, Z1 - d1, wm, W0 - 0.1, 1.7, (d1 + Z1) / 2); box(G, 0.2, 1.1, d1 - d0, wm, W0 - 0.1, 2.85, DOOR_Z);
  const base = lam(v >= 3 ? 0x4a2f1a : 0x5a5348); box(G, wid, 0.16, 0.06, base, cx, 0.08, Z0 + 0.03); box(G, 0.06, 0.16, dep, base, W1 - 0.03, 0.08, cz);
  if (v >= 3) { const pn = lam(0x5b3a22); box(G, wid, 1.0, 0.05, pn, cx, 0.65, Z0 + 0.05); box(G, 0.05, 1.0, dep, pn, W1 - 0.05, 0.65, cz); }
  sign.position.set(cx, 2.55, Z0 + 0.02); G.add(sign);
  const pivot = new THREE.Group(); pivot.position.set(W0 + 0.02, 0, d1); pivot.rotation.y = 1.25; G.add(pivot); const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.2, 1.28), std(0x3b2412, 0.5)); leaf.position.set(0, 1.1, -0.64); leaf.castShadow = CAST; pivot.add(leaf);
  box(G, 0.14, 0.06, 1.4, std(0xc9a227, 0.3, 0.8), W0 + 0.02, 2.32, DOOR_Z); box(G, 0.12, 0.5, 0.12, std(0x333, 0.5), W0 + 0.0, 2.7, DOOR_Z);
  // meja kasir
  const cm = v >= 2 ? std(0x5a3a22, 0.35, 0.1) : std(0x7a5a3a, 0.7); box(G, 0.8, 1.0, 2.2, cm, COUNTER.x, 0.5, COUNTER.z, true); box(G, 0.95, 0.06, 2.35, std(v >= 2 ? 0x202428 : 0x9a8060, 0.25, 0.2), COUNTER.x + 0.02, 1.03, COUNTER.z);
  box(G, 0.3, 0.22, 0.34, std(0x222, 0.4, 0.3, 0x113322), COUNTER.x, 1.17, COUNTER.z + 0.4); box(G, 0.04, 0.3, 0.45, std(0x111, 0.3, 0.3, 0x0a2a1a), COUNTER.x + 0.1, 1.2, COUNTER.z - 0.5);
  if (v >= 2) { box(G, 0.08, 0.05, 2.2, std(0x6a4a2e, 0.5), W0 + 0.08, 1.5, COUNTER.z); box(G, 0.08, 0.05, 2.2, std(0x6a4a2e, 0.5), W0 + 0.08, 1.9, COUNTER.z); for (let i = 0; i < 9; i++) box(G, 0.1, 0.28, 0.1, std([0x2e7d32, 0x8d6e63, 0x1565c0, 0xb71c1c][i % 4], 0.2, 0.1), W0 + 0.15, 1.67 + (i % 2) * 0.4, COUNTER.z - 0.9 + i * 0.22); }
  if (v >= 3) { for (let i = 0; i < 3; i++) { const p = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.75), new THREE.MeshBasicMaterial({ map: ctex(128, 96, (x, w, h) => { x.fillStyle = '#e9e1cf'; x.fillRect(0, 0, w, h); for (let k = 0; k < 6; k++) { x.fillStyle = `hsl(${(i * 70 + k * 50) % 360},55%,${40 + k * 4}%)`; x.beginPath(); x.arc(Math.random() * w, Math.random() * h, 12 + Math.random() * 26, 0, 7); x.fill(); } }) })); p.position.set(Math.max(W0 + 1, cx - 5.5 + i * 3.2), 1.7, Z0 + 0.03); G.add(p); }
    for (const [px, pz] of [[W0 + 0.5, Z1 - 0.5], [W1 - 0.5, Z1 - 0.5]]) { cyl(G, 0.2, 0.15, 0.4, lam(0x6d4c41), px, 0.2, pz, 10); for (let k = 0; k < 4; k++) { const lf = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), lam(0x2e7d32)); lf.position.set(px + rr(-0.12, 0.12), 0.6 + k * 0.2, pz + rr(-0.12, 0.12)); G.add(lf); } } }
  if (v >= 4) { for (let i = 0; i < 4; i++) { const zz = d1 + 1.6 + i * 2.6; if (zz > Z1 - 0.8) break; const wn = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.3), new THREE.MeshBasicMaterial({ color: [0x6fa8ff, 0xffb46a, 0x8f7bff, 0x6ee7b7][i] })); wn.rotation.y = Math.PI / 2; wn.position.set(W0 + 0.01, 1.8, zz); G.add(wn); }
    box(G, wid - 1, 0.08, 0.08, new THREE.MeshBasicMaterial({ color: 0x35f0b0 }), cx, 3.15, Z0 + 0.12); }
  if (v >= 5) { box(G, wid, 0.04, 0.12, new THREE.MeshBasicMaterial({ color: 0xffcf4a }), cx, 0.18, Z0 + 0.1); box(G, 0.12, 0.04, dep, new THREE.MeshBasicMaterial({ color: 0xffcf4a }), W1 - 0.1, 0.18, cz); for (const px of [W0 + 0.4, W1 - 0.4]) cyl(G, 0.22, 0.22, 3.4, std(0xd8d8e0, 0.25, 0.6), px, 1.7, Z0 + 0.4, 16); }
  if (v >= 6) { const sc = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 1.2), new THREE.MeshBasicMaterial({ map: labelTex('LIVE  9-BALL', 256, 96, '#071018', '#35f0b0', 40) })); sc.position.set(Math.min(W1 - 3, cx + 4.5), 2.1, Z0 + 0.03); G.add(sc); }
  // fasilitas
  const f = S.fac;
  if (f.cafe > 0) { const bx = W1 - 4.6, bz = Z0 + 0.62, n = f.cafe;
    box(G, 3.6, 1.0, 0.7, std(0x4a2f1a, 0.4, 0.1), bx, 0.5, bz, true); box(G, 3.75, 0.06, 0.85, std(n >= 3 ? 0x202428 : 0x9a8060, 0.2, 0.3), bx, 1.03, bz);
    box(G, 3.4, 0.05, 0.3, std(0x6a4a2e, 0.5), bx, 1.55, Z0 + 0.2); box(G, 3.4, 0.05, 0.3, std(0x6a4a2e, 0.5), bx, 1.95, Z0 + 0.2);
    for (let i = 0; i < 12; i++) box(G, 0.09, 0.26, 0.09, std([0x2e7d32, 0x8d6e63, 0x1565c0, 0xb71c1c, 0xf9a825][i % 5], 0.2, 0.1), bx - 1.5 + i * 0.27, 1.71 + (i % 2) * 0.4, Z0 + 0.2);
    box(G, 0.5, 0.35, 0.4, std(0xb0b0b8, 0.2, 0.8), bx + 1.2, 1.24, bz); cyl(G, 0.07, 0.07, 0.2, std(0x222, 0.4), bx + 1.2, 1.5, bz, 8);
    box(G, 0.9, 1.7, 0.6, new THREE.MeshStandardMaterial({ color: 0x9fd3ff, transparent: true, opacity: 0.35, roughness: 0.05 }), bx + 2.2, 0.85, Z0 + 0.4); for (let i = 0; i < 6; i++) box(G, 0.12, 0.3, 0.12, std([0xe53935, 0x43a047, 0x1e88e5][i % 3], 0.2), bx + 1.95 + (i % 3) * 0.25, 0.45 + Math.floor(i / 3) * 0.7, Z0 + 0.4);
    const mb = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: labelTex('MENU KAFE', 256, 128, '#10161a', '#ffd75e', 34) })); mb.position.set(bx - 0.6, 2.7, Z0 + 0.03); G.add(mb);
    for (let i = 0; i < Math.min(8, n + 2); i++) { cyl(G, 0.18, 0.18, 0.08, std(0xc62828, 0.4), bx - 1.4 + i * 0.7, 0.72, bz + 0.85, 12); cyl(G, 0.03, 0.03, 0.7, std(0x999, 0.3, 0.8), bx - 1.4 + i * 0.7, 0.35, bz + 0.85, 6); } }
  if (f.ac > 0) for (let i = 0; i < f.ac; i++) { const ax = W0 + 2.0 + i * 2.1, az = Z0 + 0.14; if (ax > W1 - 1) break;
    box(G, 1.0, 0.3, 0.26, std(0xf2f2f2, 0.5), ax, 3.12, az); box(G, 0.9, 0.03, 0.02, std(0x333, 0.5), ax, 3.04, az + 0.14); box(G, 0.05, 0.04, 0.02, std(0x33ff88, 0.3, 0, 0x22ff77), ax + 0.4, 3.16, az + 0.14);
    const gl = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.9), new THREE.MeshBasicMaterial({ color: 0x8fd0ff, transparent: true, opacity: 0.1, depthWrite: false })); gl.position.set(ax, 2.55, az + 0.05); G.add(gl); }
  if (f.park > 0) { const px0 = W0 - 10, px1 = W0 - 2.4; const asp = new THREE.Mesh(new THREE.PlaneGeometry(px1 - px0, dep + 2), lam(0x2a2c30)); asp.rotation.x = -Math.PI / 2; asp.position.set((px0 + px1) / 2, 0.01, cz); G.add(asp);
    for (let r = 0; r < 6; r++) for (let c = 0; c < 2; c++) { const zz = Z0 + 1.0 + r * 2.6; if (zz > Z1 - 0.4) continue; box(G, 3.2, 0.012, 0.06, lam(0xe8e8e8), W0 - 3.8 - c * 3.4, 0.015, zz - 1.3); }
    const n = Math.min(10, f.park * 2); for (let i = 0; i < n; i++) { const col = i % 2, row = Math.floor(i / 2), zz = Z0 + 1.0 + row * 2.6; if (zz > Z1 - 0.4) break; carMesh(G, W0 - 3.8 - col * 3.4, zz, [0xc62828, 0x1565c0, 0xeeeeee, 0x2e7d32, 0x222222, 0xf9a825][i % 6]); } }
  if (f.toilet > 0) { const tx = W1 - 1.05, tz = Z0 + 1.4, wm2 = std(0xe8e4dc, 0.7);
    box(G, 1.9, 2.2, 0.1, wm2, tx, 1.1, Z0 + 2.7, true); box(G, 0.1, 2.2, 2.7, wm2, W1 - 2.0, 1.1, tz, true); box(G, 0.7, 1.9, 0.06, std(0x6a4a2e, 0.5), tx - 0.4, 0.95, Z0 + 2.74);
    const ws = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.5), new THREE.MeshBasicMaterial({ map: labelTex('WC', 64, 64, '#1565c0', '#fff', 30) })); ws.position.set(tx + 0.5, 1.6, Z0 + 2.76); G.add(ws);
    if (f.toilet >= 2) box(G, 0.5, 0.05, 0.3, std(0xffffff, 0.2, 0, 0xffffee), tx, 2.15, Z0 + 2.5); }
  if (f.musik > 0) for (let i = 0; i < 2; i++) { const sx = W0 + 3.2 + i * 4.0, sz = Z0 + 0.55; box(G, 0.55, 1.25, 0.5, std(0x151515, 0.5, 0.2), sx, 0.62, sz, true); cyl(G, 0.2, 0.2, 0.04, std(0x333, 0.4), sx, 0.38, sz + 0.26, 16).rotation.x = Math.PI / 2; cyl(G, 0.1, 0.1, 0.04, std(0x333, 0.4), sx, 0.95, sz + 0.26, 12).rotation.x = Math.PI / 2;
    for (let k = 0; k < 5; k++) { const eq = box(G, 0.07, 0.3, 0.06, new THREE.MeshBasicMaterial({ color: [0x35f0b0, 0xffcf4a, 0xff6f9a, 0x6fa8ff, 0xc79bff][k] }), sx - 0.2 + k * 0.1, 1.45, sz + 0.2); eq.visible = f.musik >= 1; anim.push(t => { eq.scale.y = 0.4 + Math.abs(Math.sin(t * (3 + k * 1.3) + i)) * 1.2; }); } }
  if (f.tribun > 0) { const n = Math.min(4, f.tribun + 1), z0 = Z0 + 3.2, len = Math.max(1.6, Math.min(1.6 + 0.8 * f.tribun, Z1 - z0 - 3.4));
    for (let i = 0; i < n; i++) { const hh = 0.3 * (i + 1); box(G, 0.6, hh, len, std(0x5a5a62, 0.7), W1 - 1.5 + i * 0.6, hh / 2, z0 + len / 2, true); for (let s = 0; s < Math.floor(len / 0.5); s++) box(G, 0.32, 0.06, 0.38, std(s % 2 ? 0xc62828 : 0x1565c0, 0.5), W1 - 1.5 + i * 0.6, hh + 0.04, z0 + 0.3 + s * 0.5); }
    box(G, 0.04, 0.5, len, std(0xd0d0d8, 0.3, 0.8), W1 - 1.9, 0.55, z0 + len / 2); }
  if (f.vip > 0) { const vz = Z1 - 2.4, vx = W1 - 1.0, sofa = std(0x6a1b1b, 0.7);
    box(G, 1.0, 0.45, 2.0, sofa, vx, 0.22, vz, true); box(G, 0.25, 0.8, 2.0, sofa, W1 - 0.45, 0.5, vz, true); box(G, 0.7, 0.35, 0.8, new THREE.MeshStandardMaterial({ color: 0x9fd3ff, transparent: true, opacity: 0.5, roughness: 0.05 }), vx - 1.1, 0.18, vz);
    if (f.vip >= 2) { box(G, 1.0, 0.45, 1.4, sofa, vx - 0.2, 0.22, vz - 2.0, true); } if (f.vip >= 3) { const tv = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.9), new THREE.MeshBasicMaterial({ map: labelTex('VIP LOUNGE', 256, 128, '#12081c', '#ffcf4a', 34) })); tv.rotation.y = -Math.PI / 2; tv.position.set(W1 - 0.02, 1.9, vz); G.add(tv); } }
  if (S.trophies > 0 && v >= 4) { const tg = new THREE.MeshStandardMaterial({ color: 0xffd34d, roughness: 0.25, metalness: 0.9 }); box(G, 0.4, 0.05, 3.0, std(0x4a2f1a, 0.5), W1 - 0.3, 1.2, Z0 + 5.5); for (let i = 0; i < Math.min(8, S.trophies); i++) { const cp = cyl(G, 0.07, 0.03, 0.16, tg, W1 - 0.3, 1.3, Z0 + 4.2 + i * 0.35, 8); cp.castShadow = false; } }
  hl.visible = true; G.add(hl); G.add(slot); updSlot();
}
function updSlot() { const cap = VEN[S.venue - 1].cap; slot.visible = S.tables.length < cap; if (slot.visible) { const p = tpos(S.tables.length); slot.position.x = p.x; slot.position.z = p.z; } }

// ===== Meja biliar (desain berubah tiap level) =====
const gcache = {};
function rrPath(sh, hx, hy, r) { sh.moveTo(-hx + r, -hy); sh.lineTo(hx - r, -hy); sh.quadraticCurveTo(hx, -hy, hx, -hy + r); sh.lineTo(hx, hy - r); sh.quadraticCurveTo(hx, hy, hx - r, hy); sh.lineTo(-hx + r, hy); sh.quadraticCurveTo(-hx, hy, -hx, hy - r); sh.lineTo(-hx, -hy + r); sh.quadraticCurveTo(-hx, -hy, -hx + r, -hy); }
function pocketHole() {
  const p = POCKET, pts = [], D = Math.PI / 180, arc = (cx, cy, a0, a1) => { const n = Math.max(4, Math.round(Math.abs(a1 - a0) / 0.3)); for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; pts.push([cx + p * Math.cos(a), cy + p * Math.sin(a)]); } };
  pts.push([-HX + p, -HZ]); arc(0, -HZ, 180 * D, 360 * D); arc(HX, -HZ, 180 * D, 450 * D); arc(HX, HZ, 270 * D, 540 * D); arc(0, HZ, 0, 180 * D); arc(-HX, HZ, 0, 270 * D); arc(-HX, -HZ, 90 * D, 360 * D);
  const h = new THREE.Path(); pts.forEach((q, i) => i ? h.lineTo(q[0], q[1]) : h.moveTo(q[0], q[1])); return h;
}
const RAD = [0.03, 0.05, 0.07, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22];
function frameGeo(lv) { const k = 'fg' + lv; if (gcache[k]) return gcache[k]; const sh = new THREE.Shape(); rrPath(sh, FA, FB, RAD[lv - 1]); sh.holes.push(pocketHole());
  return gcache[k] = new THREE.ExtrudeGeometry(sh, { depth: 0.1, bevelEnabled: lv >= 3, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2, curveSegments: 8 }); }
function apronGeo(lv) { const k = 'ag' + lv; if (gcache[k]) return gcache[k]; const sh = new THREE.Shape(); rrPath(sh, FA - 0.02, FB - 0.02, Math.max(0.02, RAD[lv - 1] - 0.02)); return gcache[k] = new THREE.ExtrudeGeometry(sh, { depth: 0.2, bevelEnabled: false, curveSegments: 8 }); }
function latheGeo(st) { const k = 'lg' + st; if (gcache[k]) return gcache[k];
  const P = st === 1 ? [[0.07, 0], [0.07, 0.05], [0.045, 0.1], [0.06, 0.2], [0.04, 0.3], [0.065, 0.42], [0.05, 0.55], [0.075, 0.66], [0.075, 0.7]] : [[0.09, 0], [0.1, 0.04], [0.07, 0.12], [0.05, 0.2], [0.11, 0.35], [0.12, 0.45], [0.07, 0.58], [0.09, 0.7]];
  return gcache[k] = new THREE.LatheGeometry(P.map(q => new THREE.Vector2(q[0], q[1])), 14); }
const boxG = (w, h, d) => { const k = `b${w}_${h}_${d}`; return gcache[k] || (gcache[k] = new THREE.BoxGeometry(w, h, d)); };
const stickParts = [];
function mkStick() {
  const g = new THREE.Group(), carbon = std(0x14161a, 0.28, 0.8), chrome = std(0xdadde2, 0.15, 1), acc = std(0xffd34d, 0.25, 0.9), tip = std(0x2a6bff, 0.8), wht = std(0xf2f2f2, 0.4);
  const add = (r1, r2, h, y, m) => { const c = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, 10), m); c.position.y = y; c.castShadow = CAST; g.add(c); return c; };
  add(0.0065, 0.0065, 0.012, 0.744, tip); add(0.0075, 0.0075, 0.04, 0.718, wht); const shaft = add(0.0078, 0.0105, 0.64, 0.38, carbon); add(0.0115, 0.0115, 0.022, 0.056, chrome);
  const butt = add(0.0115, 0.0165, 0.56, -0.23, carbon), b1 = add(0.0145, 0.0145, 0.03, -0.1, acc), b2 = add(0.0165, 0.0165, 0.025, -0.38, acc), b3 = add(0.017, 0.017, 0.06, -0.49, std(0x111, 0.6)); add(0.0095, 0.0095, 0.012, 0.42, chrome);
  g.userData.acc = [b1, b2]; g.userData.parts = [shaft, butt]; g.visible = false; return g;
}
function buildDeco(tb) {
  const g = tb.deco; while (g.children.length) g.remove(g.children[0]); tb.glow = null; tb.gems = [];
  const lv = clamp(S.tables[tb.i].lv, 1, MAX_LV), accM = std(ACC[lv - 1], 0.22, 0.9), frM = new THREE.MeshStandardMaterial({ map: frameTex(lv), roughness: Math.max(0.08, 0.45 - lv * 0.04), metalness: lv >= 5 ? 0.45 : 0.1 });
  const fr = new THREE.Mesh(frameGeo(lv), frM); fr.rotation.x = -Math.PI / 2; fr.position.y = 0.88; fr.castShadow = CAST; fr.receiveShadow = true; g.add(fr);
  const apM = new THREE.MeshStandardMaterial({ color: FRAMEC[lv - 1], roughness: 0.4, metalness: lv >= 5 ? 0.5 : 0.1 });
  const ap = new THREE.Mesh(apronGeo(lv), apM); ap.rotation.x = -Math.PI / 2; ap.position.y = 0.68; ap.castShadow = CAST; g.add(ap);
  const legM = lv >= 7 && lv <= 8 ? std(0x15171b, 0.3, 0.8) : new THREE.MeshStandardMaterial({ color: FRAMEC[lv - 1], roughness: 0.4, metalness: lv >= 5 ? 0.5 : 0.1 });
  if (lv <= 6 || lv >= 9) { const st = lv === 1 ? 0 : (lv === 2 || lv === 3) ? 1 : 2;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const lg = new THREE.Mesh(st === 0 ? boxG(0.16, 0.7, 0.16) : latheGeo(st), legM); lg.position.set(sx * (HX - 0.15), st === 0 ? 0.35 : 0, sz * (HZ - 0.12)); if (lv >= 9) lg.scale.set(1.25, 1, 1.25); lg.castShadow = CAST; g.add(lg);
      if (lv >= 5) { const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.025, 12), accM); ring.position.set(sx * (HX - 0.15), 0.4, sz * (HZ - 0.12)); g.add(ring); } } }
  else { for (const sx of [-1, 1]) { const pd = new THREE.Mesh(boxG(0.32, 0.7, HZ * 1.7), legM); pd.position.set(sx * HX * 0.55, 0.35, 0); pd.castShadow = CAST; g.add(pd); if (lv === 8) { const gl = new THREE.Mesh(boxG(0.34, 0.5, HZ * 1.3), new THREE.MeshStandardMaterial({ color: 0x9bd2ff, transparent: true, opacity: 0.4, roughness: 0.05, metalness: 0.2 })); gl.position.set(sx * HX * 0.55, 0.35, 0); g.add(gl); } }
    const bar = new THREE.Mesh(boxG(HX * 1.1, 0.1, 0.18), accM); bar.position.y = 0.3; g.add(bar); }
  if (lv >= 2) for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const cp = new THREE.Mesh(new THREE.CylinderGeometry(0.07 + lv * 0.004, 0.08 + lv * 0.004, 0.045, 14), accM); cp.position.set(sx * (FA - 0.1), 1.015, sz * (FB - 0.1)); g.add(cp); if (lv >= 5) { const sp = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), accM); sp.position.set(sx * (FA - 0.1), 1.05, sz * (FB - 0.1)); g.add(sp); } }
  if (lv >= 3) { const dl = decalTex(lv, true), ds = decalTex(lv, false), dm = new THREE.MeshBasicMaterial({ map: dl, transparent: true, polygonOffset: true, polygonOffsetFactor: -2 }), dms = new THREE.MeshBasicMaterial({ map: ds, transparent: true, polygonOffset: true, polygonOffsetFactor: -2 });
    for (const sz of [-1, 1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(HX * 1.7, 0.2), dm); p.position.set(0, 0.78, sz * (FB - 0.02 + 0.004)); if (sz < 0) p.rotation.y = Math.PI; g.add(p); }
    for (const sx of [-1, 1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.2), dms); p.position.set(sx * (FA - 0.02 + 0.004), 0.78, 0); p.rotation.y = sx > 0 ? Math.PI / 2 : -Math.PI / 2; g.add(p); } }
  if (lv >= 6) { const gl = new THREE.Mesh(new THREE.PlaneGeometry(FA * 2 + 0.7, FB * 2 + 0.7), new THREE.MeshBasicMaterial({ color: ACC[lv - 1], transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })); gl.rotation.x = -Math.PI / 2; gl.position.y = 0.03; g.add(gl); tb.glow = gl; }
  if (lv >= 10) for (let i = 0; i < 8; i++) { const gm = new THREE.Mesh(new THREE.IcosahedronGeometry(0.04, 0), new THREE.MeshStandardMaterial({ color: [0xff3b6b, 0x35e0ff, 0x7dff9a, 0xffd34d][i % 4], emissive: [0xff3b6b, 0x35e0ff, 0x7dff9a, 0xffd34d][i % 4], emissiveIntensity: 0.6, roughness: 0.1, metalness: 0.3 })); gm.position.set(-HX * 0.8 + i * HX * 0.23, 0.82, (i % 2 ? 1 : -1) * (FB - 0.02 + 0.01)); g.add(gm); tb.gems.push(gm); }
  tb.cm.map = clothTex(lv); tb.cm.needsUpdate = true; tb.deco.userData.lv = lv;
  const col = ACC[lv - 1]; tb.stick.userData.acc.forEach(m => m.material.color.setHex(col)); tb.stick.userData.acc.forEach(m => { m.material.emissive.setHex(lv >= 6 ? col : 0); m.material.emissiveIntensity = lv >= 6 ? 0.5 : 0; });
}
function buildTable(i) {
  const g = new THREE.Group(); g.position.copy(tpos(i)); g.userData.i = i;
  const cm = new THREE.MeshStandardMaterial({ map: clothTex(1), roughness: 0.95, emissive: 0x0a2a14, emissiveIntensity: 0.3 });
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(HX * 2, HZ * 2), cm); cloth.rotation.x = -Math.PI / 2; cloth.position.y = TOP; cloth.receiveShadow = true; g.add(cloth);
  const pool = new THREE.Mesh(new THREE.PlaneGeometry(4.0, 2.7), new THREE.MeshBasicMaterial({ map: poolTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); pool.rotation.x = -Math.PI / 2; pool.position.y = 0.02; g.add(pool);
  const deco = new THREE.Group(); g.add(deco); const stick = mkStick(); g.add(stick);
  const bm = []; for (let n = 0; n <= 9; n++) { const b = new THREE.Mesh(ballGeo, ballMat[n]); b.castShadow = CAST; g.add(b); bm.push(b); }
  const mark = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.34), new THREE.MeshBasicMaterial({ map: labelTex('🔧', 64, 64, '#c62828', '#fff', 36), transparent: true })); mark.position.set(0, 1.6, 0); mark.visible = false; g.add(mark);
  scene.add(g);
  const tb = { i, group: g, cm, deco, stick, bm, mark, ctl: null, m: null, idle: E.newMatch(), butt: new THREE.Vector3(), tip: new THREE.Vector3(), glow: null, gems: [], svcT: 0, order: null };
  buildDeco(tb); return tb;
}
function styleTable(tb) { const t = S.tables[tb.i]; if (tb.deco.userData.lv !== t.lv) buildDeco(tb); const k = 0.62 + 0.38 * t.cond / 100; tb.cm.color.setRGB(k, k, k); tb.mark.visible = t.cond < 30 || tb.svcT > 0; }
function syncTables() { while (tables.length < S.tables.length) tables.push(buildTable(tables.length)); tables.forEach((tb, i) => { tb.group.position.copy(tpos(i)); styleTable(tb); }); updSlot(); }
const _ax = new THREE.Vector3(), _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3(), _v3 = new THREE.Vector3();
function setBalls(tb, dt) {
  const m = tb.m || tb.idle;
  for (const b of m.balls) { const me = tb.bm[b.n]; me.visible = b.alive; me.position.set(b.x, BALL_Y, b.z); const sp = Math.hypot(b.vx, b.vz); if (b.alive && sp > 0.01 && dt) me.rotateOnWorldAxis(_ax.set(b.vz / sp, 0, -b.vx / sp), sp * dt / R); }
}

// ===== Karakter 3D =====
const GEO = { leg: new THREE.CylinderGeometry(0.07, 0.06, 0.88, 8), torso: new THREE.CylinderGeometry(0.17, 0.15, 0.62, 10), head: new THREE.SphereGeometry(0.12, 14, 12), hair: new THREE.SphereGeometry(0.13, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), arm: new THREE.CylinderGeometry(0.04, 0.035, 1, 6), shoe: new THREE.BoxGeometry(0.1, 0.06, 0.2), tray: new THREE.CylinderGeometry(0.2, 0.2, 0.02, 14), cup: new THREE.CylinderGeometry(0.035, 0.03, 0.08, 8) };
const matC = {}; const mat = c => matC[c] || (matC[c] = new THREE.MeshLambertMaterial({ color: c }));
const SHL = new THREE.Vector3(-0.21, 0.54, 0), SHR = new THREE.Vector3(0.21, 0.54, 0);
function mkChar(L) {
  const g = new THREE.Group(), upper = new THREE.Group(); upper.position.y = 0.88; g.add(upper);
  const mk = (geo, c, x, y, z, par) => { const m = new THREE.Mesh(geo, mat(c)); m.position.set(x, y, z); m.castShadow = CAST; par.add(m); return m; };
  const legL = new THREE.Group(), legR = new THREE.Group(); legL.position.set(-0.09, 0.88, 0); legR.position.set(0.09, 0.88, 0); g.add(legL); g.add(legR);
  mk(GEO.leg, L.pants, 0, -0.44, 0, legL); mk(GEO.leg, L.pants, 0, -0.44, 0, legR); mk(GEO.shoe, 0x181818, 0, -0.86, 0.04, legL); mk(GEO.shoe, 0x181818, 0, -0.86, 0.04, legR);
  mk(GEO.torso, L.shirt, 0, 0.31, 0, upper); mk(GEO.head, L.skin, 0, 0.8, 0, upper); mk(GEO.hair, L.hair, 0, 0.82, -0.01, upper);
  const armL = mk(GEO.arm, L.shirt, 0, 0, 0, upper), armR = mk(GEO.arm, L.shirt, 0, 0, 0, upper);
  const ch = { g, upper, legL, legR, armL, armR, ph: Math.random() * 6, lean: 0, leanT: 0, walking: false, hw: null, path: [], speed: 1.35, hr: new THREE.Vector3(), hl: new THREE.Vector3(), cheer: false, pose: null, props: {} };
  scene.add(g); chars.push(ch); return ch;
}
function killChar(ch) { scene.remove(ch.g); const i = chars.indexOf(ch); if (i >= 0) chars.splice(i, 1); }
function limb(m, a, b) { const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz) || 1e-3; m.position.set((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2); m.scale.set(1, L, 1); m.quaternion.setFromUnitVectors(UP, _v3.set(dx / L, dy / L, dz / L)); }
function reach(a, h) { const d = Math.hypot(h.x - a.x, h.y - a.y, h.z - a.z); if (d > 0.8) { const k = 0.8 / d; h.set(a.x + (h.x - a.x) * k, a.y + (h.y - a.y) * k, a.z + (h.z - a.z) * k); } }
const _hw = { r: new THREE.Vector3(), l: new THREE.Vector3() };
// tangan target dalam koordinat lokal karakter (g)
function handsLocal(ch, rx, ry, rz, lx, ly, lz) { ch.g.updateMatrixWorld(true); ch.hw = ch.hw || {}; ch.hw = { r: ch.g.localToWorld(_hw.r.set(rx, ry, rz)).clone(), l: ch.g.localToWorld(_hw.l.set(lx, ly, lz)).clone() }; }
function animChar(ch, dt) {
  ch.lean += (ch.leanT - ch.lean) * Math.min(1, dt * 8); ch.upper.rotation.x = ch.lean; ch.leanT = 0;
  const mv = ch.walking ? 1 : 0; ch.ph += dt * (mv ? 7.5 : 1.5);
  ch.legL.rotation.x = Math.sin(ch.ph) * 0.65 * mv; ch.legR.rotation.x = -Math.sin(ch.ph) * 0.65 * mv; ch.upper.position.y = 0.88 + (mv ? Math.abs(Math.sin(ch.ph)) * 0.02 : Math.sin(ch.ph) * 0.004);
  if (ch.hw) { ch.g.updateMatrixWorld(true); ch.upper.worldToLocal(ch.hr.copy(ch.hw.r)); ch.upper.worldToLocal(ch.hl.copy(ch.hw.l)); reach(SHR, ch.hr); reach(SHL, ch.hl); ch.hw = null; }
  else if (ch.cheer) { const w = Math.sin(ch.ph * 3); ch.hr.set(0.25, 0.54 + 0.62 + w * 0.08, 0.06); ch.hl.set(-0.25, 0.54 + 0.62 - w * 0.08, 0.06); }
  else { const s = Math.sin(ch.ph) * 0.28 * mv, y = -0.5; ch.hr.set(0.22, 0.54 + y, -s + 0.02); ch.hl.set(-0.22, 0.54 + y, s + 0.02); }
  limb(ch.armR, SHR, ch.hr); limb(ch.armL, SHL, ch.hl); ch.walking = false;
}
function faceDir(ch, a, dt) { let da = a - ch.g.rotation.y; da = Math.atan2(Math.sin(da), Math.cos(da)); ch.g.rotation.y += da * Math.min(1, dt * 10); }
function faceAt(ch, x, z, dt) { faceDir(ch, Math.atan2(x - ch.g.position.x, z - ch.g.position.z), dt); }
function walkTo(ch, tx, tz, dt, sp) { const dx = tx - ch.g.position.x, dz = tz - ch.g.position.z, d = Math.hypot(dx, dz); if (d < 0.06) return true; const st = Math.min(d, (sp || ch.speed) * dt); ch.g.position.x += dx / d * st; ch.g.position.z += dz / d * st; ch.walking = true; faceDir(ch, Math.atan2(dx, dz), dt); return false; }
function walkPath(ch, dt) { if (!ch.path.length) return true; const t = ch.path[0]; if (walkTo(ch, t.x, t.z, dt)) ch.path.shift(); return !ch.path.length; }

// ===== Jalur memutari meja =====
function tableRects() { return tables.map(tb => { const p = tb.group.position; return { x0: p.x - HX - PADR, x1: p.x + HX + PADR, z0: p.z - HZ - PADR, z1: p.z + HZ + PADR }; }); }
function segHits(ax, az, bx, bz, r) {
  const dx = bx - ax, dz = bz - az, p = [-dx, dx, -dz, dz], q = [ax - (r.x0 + 0.01), (r.x1 - 0.01) - ax, az - (r.z0 + 0.01), (r.z1 - 0.01) - az]; let t0 = 0, t1 = 1;
  for (let i = 0; i < 4; i++) { if (p[i] === 0) { if (q[i] < 0) return false; } else { const t = q[i] / p[i]; if (p[i] < 0) { if (t > t0) t0 = t; } else if (t < t1) t1 = t; } }
  return t0 < t1 - 1e-6;
}
function pushOut(x, z) { for (const r of tableRects()) if (x > r.x0 && x < r.x1 && z > r.z0 && z < r.z1) { const d = [x - r.x0, r.x1 - x, z - r.z0, r.z1 - z], k = d.indexOf(Math.min(...d)); return k === 0 ? { x: r.x0 - 0.1, z } : k === 1 ? { x: r.x1 + 0.1, z } : k === 2 ? { x, z: r.z0 - 0.1 } : { x, z: r.z1 + 0.1 }; } return null; }
function routeAround(fx, fz, tx, tz) {
  const po = pushOut(fx, fz); if (po) return [{ x: po.x, z: po.z }].concat(routeAround(po.x, po.z, tx, tz));
  const pe = pushOut(tx, tz); if (pe) { tx = pe.x; tz = pe.z; }
  const near = tableRects().filter(r => !(Math.max(fx, tx) < r.x0 - 3 || Math.min(fx, tx) > r.x1 + 3 || Math.max(fz, tz) < r.z0 - 3 || Math.min(fz, tz) > r.z1 + 3));
  const blocked = (a, b, c, d) => near.some(r => segHits(a, b, c, d, r));
  if (!blocked(fx, fz, tx, tz)) return [{ x: tx, z: tz }];
  const nodes = [{ x: fx, z: fz }, { x: tx, z: tz }]; for (const r of near) for (const [x, z] of [[r.x0 - 0.06, r.z0 - 0.06], [r.x1 + 0.06, r.z0 - 0.06], [r.x0 - 0.06, r.z1 + 0.06], [r.x1 + 0.06, r.z1 + 0.06]]) nodes.push({ x, z });
  const n = nodes.length, dist = new Array(n).fill(1e9), prev = new Array(n).fill(-1), done = new Array(n).fill(false); dist[0] = 0;
  for (let it = 0; it < n; it++) { let u = -1; for (let i = 0; i < n; i++) if (!done[i] && (u < 0 || dist[i] < dist[u])) u = i; if (u < 0 || dist[u] >= 1e9) break; done[u] = true; if (u === 1) break;
    for (let j = 0; j < n; j++) { if (done[j]) continue; const d = dist[u] + Math.hypot(nodes[u].x - nodes[j].x, nodes[u].z - nodes[j].z); if (d < dist[j] && !blocked(nodes[u].x, nodes[u].z, nodes[j].x, nodes[j].z)) { dist[j] = d; prev[j] = u; } } }
  if (dist[1] >= 1e9) return [{ x: tx, z: tz }];
  const path = []; for (let c = 1; c !== 0 && c >= 0; c = prev[c]) path.unshift({ x: nodes[c].x, z: nodes[c].z }); return path;
}

// ===== Pengunjung & pertandingan NPC =====
const TYPES = [
  { n: 'Anak Muda', shirt: [0xc0392b, 0x2980b9, 0x16a085], pants: 0x2f4a7a, sk: [0.3, 0.55], pay: 1 }, { n: 'Karyawan', shirt: [0xecf0f1, 0xaed6f1, 0xf9e79f], pants: 0x2c3e50, sk: [0.4, 0.65], pay: 1.15 },
  { n: 'Pemain Pro', shirt: [0x111111, 0x1b5e20], pants: 0x151515, sk: [0.75, 0.92], pay: 1.6 }, { n: 'Tamu VIP', shirt: [0x1c1c24, 0x5b2c6f], pants: 0x1c1c24, sk: [0.5, 0.8], pay: 2.0, vip: true },
  { n: 'Influencer', shirt: [0xff6fa5, 0xffd166, 0x6ee7b7], pants: 0xe8e8e8, sk: [0.3, 0.6], pay: 1.4 }];
const SKIN = [0xf1c27d, 0xc68642, 0x8d5524, 0xe0ac69], HAIR = [0x111111, 0x2b1a0e, 0x4a3320, 0x6b4a2a];
const lookOf = t => ({ shirt: pick(t.shirt), pants: t.pants, skin: pick(SKIN), hair: pick(HAIR) });
function pickType() { const w = [3, 2, 0.6 + S.venue * 0.4, 0.2 + S.venue * 0.35 + S.fac.vip * 0.4, 1]; let r = Math.random() * w.reduce((a, b) => a + b, 0); for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0) return TYPES[i]; } return TYPES[0]; }
function mkPlayer(type, sk) { const t = type || pickType(); return { name: pick(NAMES), type: t, skill: sk != null ? sk : rr(t.sk[0], t.sk[1]), look: lookOf(t) }; }
const ent = () => { const b = bounds(); return { sp: { x: b.W0 - 3.4, z: DOOR_Z }, din: { x: b.W0 + 0.8, z: DOOR_Z } }; };
const PAY = k => ({ x: COUNTER.x + 1.0, z: COUNTER.z + (k ? 0.55 : -0.55) });
const standby = (tb, k) => { const p = tb.group.position, d = HZ + PADR + 0.14; return k === 0 ? { x: p.x - 0.9, z: p.z + d } : { x: p.x + 0.9, z: p.z - d }; };
let kasirBusy = 0;
function mkCtl(tb, pl0, pl1, opts) {
  const c = { tb, pl: [pl0, pl1], ch: [], state: 'enter', ph: '', t: 0, s: 0, m: null, ang: 0, speed: 2, plan: null, elapsed: 0, tp: new THREE.Vector3(), opts: opts || {}, coached: false, specs: [] };
  const e = ent();
  [pl0, pl1].forEach((p, k) => { const ch = mkChar(p.look); ch.g.position.set(e.sp.x, 0, e.sp.z + k * 0.7); ch.g.rotation.y = Math.PI / 2; const sb = standby(tb, k); ch.path = [{ x: e.din.x, z: e.din.z + k * 0.5 }].concat(routeAround(e.din.x, e.din.z + k * 0.5, sb.x, sb.z)); ch.speed = 1.35; c.ch.push(ch); });
  tb.ctl = c; ctls.push(c); return c;
}
function removeCtl(c) { c.ch.forEach(killChar); c.specs.forEach(killChar); const i = ctls.indexOf(c); if (i >= 0) ctls.splice(i, 1); c.tb.ctl = null; c.tb.m = null; c.tb.idle = E.newMatch(); c.tb.stick.visible = false; c.tb.order = null; }
function startNPC(tb) { mkCtl(tb, mkPlayer(), mkPlayer(), {}); }
function addDirt(tb) {
  if (dirts.length >= 14) return; const p = tb.group.position, x = p.x + rr(-1.4, 1.4), z = p.z + (Math.random() < 0.5 ? 1 : -1) * rr(1.15, 1.6);
  const m = new THREE.Mesh(new THREE.CircleGeometry(rr(0.12, 0.22), 10), new THREE.MeshBasicMaterial({ color: 0x2a1c10, transparent: true, opacity: 0.55 })); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.012, z); scene.add(m); dirts.push({ m, x, z });
}
function standPos(tb, cu, ang, out) {
  const dx = Math.cos(ang), dz = Math.sin(ang); let x = cu.x - dx * (R + 0.15 + 1.47), z = cu.z - dz * (R + 0.15 + 1.47);
  for (let i = 0; i < 20 && Math.abs(x) < HX + PADR + 0.08 && Math.abs(z) < HZ + PADR + 0.08; i++) { x -= dx * 0.12; z -= dz * 0.12; }
  const p = tb.group.position; return out.set(p.x + x, 0, p.z + z);
}
function setStick(tb, cu, ang, gap, vis) {
  const s = tb.stick; s.visible = vis; if (!vis) return;
  const dx = Math.cos(ang), dz = Math.sin(ang), tx = cu.x - dx * (R + gap), tz = cu.z - dz * (R + gap), ty = BALL_Y + 0.005, bx = tx - dx * 1.47, bz = tz - dz * 1.47, by = ty + 0.2;
  s.position.set((tx + bx) / 2, (ty + by) / 2, (tz + bz) / 2); const L = Math.hypot(tx - bx, ty - by, tz - bz); s.quaternion.setFromUnitVectors(UP, _v3.set((tx - bx) / L, (ty - by) / L, (tz - bz) / L)); tb.butt.set(bx, by, bz); tb.tip.set(tx, ty, tz);
}
function poseAim(c, ch, cu, ang, gap) {
  const tb = c.tb, p = tb.group.position; setStick(tb, cu, ang, gap, true);
  const bx = tb.butt.x, by = tb.butt.y, bz = tb.butt.z, k = 0.4 / 1.5, dx = Math.cos(ang), dz = Math.sin(ang);
  ch.hw = { r: new THREE.Vector3(p.x + bx + (tb.tip.x - bx) * k, by + (tb.tip.y - by) * k, p.z + bz + (tb.tip.z - bz) * k), l: new THREE.Vector3(p.x + cu.x - dx * 0.32, TOP + 0.04, p.z + cu.z - dz * 0.32) }; ch.leanT = 0.6;
}
function floatAt(x, y, z, txt, col) { floatText(_v1.set(x, y, z), txt, col); }
function begin(c) {
  const tb = c.tb; c.m = tb.m = E.newMatch(c.pl[0], c.pl[1]); c.state = 'play'; c.elapsed = 0;
  if (!c.opts.league && S.fac.cafe > 0 && Math.random() < 0.45 + 0.1 * S.fac.cafe) tb.order = { val: Math.round(10 * Math.pow(1.5, S.venue - 1) * (1 + 0.25 * S.fac.cafe)), t: 0, taken: false };
  startThink(c);
}
function startThink(c) {
  const m = c.m, me = m.turn, p = c.pl[me], cu = E.cue(m), tb = c.tb, ch = c.ch[me]; c.s = 0;
  const a = E.aiShot(m, p.skill); if (a.place) { cu.x = a.place.x; cu.z = a.place.z; m.inHand = false; }
  c.plan = a; c.ang = a.ang; c.speed = a.speed; c.t = rr(1.1, 2.5) * (p.skill > 0.7 ? 0.8 : 1.2); c.ph = 'think';
  standPos(tb, cu, c.ang, c.tp); ch.path = routeAround(ch.g.position.x, ch.g.position.z, c.tp.x, c.tp.z);
  const ot = c.ch[1 - me], sb = standby(tb, 1 - me); if (Math.hypot(ot.g.position.x - sb.x, ot.g.position.z - sb.z) > 0.3) ot.path = routeAround(ot.g.position.x, ot.g.position.z, sb.x, sb.z);
}
function endMatchByTime(c) { const m = c.m; m.winner = m.pots[0] > m.pots[1] ? 0 : m.pots[1] > m.pots[0] ? 1 : m.turn; m.phase = 'over'; }
function afterShot(c) {
  const m = c.m, L = m.last;
  if (L.foul) floatAt(c.tb.group.position.x, 1.9, c.tb.group.position.z, 'FOUL', '#ffd166'); else if (L.pots.length) floatAt(c.tb.group.position.x, 1.9, c.tb.group.position.z, '+' + L.pots.length, '#7dff9a');
  if (m.phase !== 'over' && c.elapsed >= MATCH_SEC) endMatchByTime(c);
  if (m.phase === 'over') { onOver(c); return; }
  startThink(c);
}
function crowdN(round) { return clamp(Math.round((1 + S.rating * 1.2 + S.fac.tribun * 2.2 + S.fac.vip * 1.2 + S.fac.cafe * 0.6) * (1 + 0.35 * round)), 2, 14); }
function onOver(c) {
  c.state = 'end'; c.t = 2.2; c.tb.stick.visible = false; sfx('win', 2);
  const tb = c.tb, t = S.tables[tb.i]; t.cond = Math.max(0, t.cond - rr(1.5, 3) * (1 + 0.04 * t.lv)); styleTable(tb); S.matches++; prog('matches', c.opts.league ? 0 : 1);
  if (Math.random() < 0.8) addDirt(tb);
  if (c.opts.league) leagueResult(c); c.cheer = true;
}
function consume(c) { const m = c.m; for (const e of m.events) { const v = 0.35; if (e.t === 'click') sfx('click', Math.min(3, e.v) * v); else if (e.t === 'rail') sfx('rail', v); else if (e.t === 'pot') sfx('pot', 2 * v); else if (e.t === 'cue') sfx('cue', 2 * v); } m.events.length = 0; }
function updCtl(c, dt) {
  const tb = c.tb, m = c.m;
  if (c.state === 'enter') { let ok = true; for (const ch of c.ch) if (!walkPath(ch, dt)) ok = false; if (ok) { c.state = 'rack'; c.t = 0.8; } return; }
  if (c.state === 'rack') { c.t -= dt; c.ch.forEach(ch => faceAt(ch, tb.group.position.x, tb.group.position.z, dt)); if (c.t <= 0) begin(c); return; }
  if (c.state === 'end') { c.t -= dt; c.ch.forEach(ch => { faceAt(ch, tb.group.position.x, tb.group.position.z, dt); }); c.specs.forEach(s => { s.cheer = true; }); if (c.t <= 0) endCtl(c); return; }
  if (c.state === 'pay') { let ok = true; for (const ch of c.ch) if (!walkPath(ch, dt)) ok = false; if (ok) { if (!c.paid) { c.paid = true; c.t = 1.4; kasirBusy = 1.6; c.ch.forEach(ch => faceAt(ch, COUNTER.x, COUNTER.z, 1)); } else { c.t -= dt; c.ch.forEach(ch => faceAt(ch, COUNTER.x - 1, COUNTER.z, dt * 3)); if (c.t <= 0) settle(c); } } return; }
  if (c.state === 'leave') { let ok = true; for (const ch of c.ch) if (!walkPath(ch, dt)) ok = false; c.specs.forEach(s => walkPath(s, dt)); if (ok) removeCtl(c); return; }
  c.elapsed += dt; const me = m.turn, ch = c.ch[me], ot = c.ch[1 - me], cu = E.cue(m);
  walkPath(ot, dt); if (!ot.path.length) faceAt(ot, tb.group.position.x, tb.group.position.z, dt);
  if (c.ph === 'think') { c.t -= dt; const arr = walkPath(ch, dt); if (arr) faceDir(ch, Math.atan2(Math.cos(c.ang), Math.sin(c.ang)), dt); if (c.t <= 0 && arr) { c.ph = 'aim'; c.t = rr(0.5, 1.0); } }
  else if (c.ph === 'aim') { poseAim(c, ch, cu, c.ang, 0.12); faceDir(ch, Math.atan2(Math.cos(c.ang), Math.sin(c.ang)), dt); c.t -= dt; if (c.t <= 0) { c.ph = 'stroke'; c.s = 0; } }
  else if (c.ph === 'stroke') { c.s += dt; const peak = 0.12 + 0.12 + c.speed * 0.03; let gap; if (c.s < 0.5) gap = 0.12 + (peak - 0.12) * (1 - Math.pow(1 - c.s / 0.5, 2)); else gap = Math.max(0, peak * (1 - (c.s - 0.5) / 0.1)); poseAim(c, ch, cu, c.ang, gap); if (c.s >= 0.6) { E.shoot(m, c.ang, c.speed, 0); c.ph = 'roll'; c.s = 0; } }
  else if (c.ph === 'roll') { c.s += dt; if (c.s > 0.35) tb.stick.visible = false; else poseAim(c, ch, cu, c.ang, 0); E.step(m, dt); consume(c); if (m.phase !== 'roll') afterShot(c); }
}
function endCtl(c) {
  const tb = c.tb; c.tb.m = null; c.tb.idle = E.newMatch(); tb.stick.visible = false; tb.order = null; c.specs.forEach(s => { s.cheer = false; });
  if (c.opts.league) { c.state = 'leave'; const e = ent(); c.ch.concat(c.specs).forEach((ch, k) => { ch.path = routeAround(ch.g.position.x, ch.g.position.z, e.din.x, e.din.z + (k % 3) * 0.4).concat([{ x: e.sp.x, z: e.sp.z }]); ch.speed = 1.6; }); return; }
  c.state = 'pay'; c.paid = false; c.ch.forEach((ch, k) => { const p = PAY(k); ch.path = routeAround(ch.g.position.x, ch.g.position.z, p.x, p.z); ch.speed = 1.4; });
}
function settle(c) {
  const tb = c.tb, t = S.tables[tb.i], mult = (c.pl[0].type.pay + c.pl[1].type.pay) / 2 * (c.pl.some(p => p.type.vip) ? 1 + 0.1 * S.fac.vip : 1);
  const loss = S.staff.kasir > 0 ? Math.max(0, 0.08 - 0.02 * S.staff.kasir) : 0.2; let fee = matchFee(t) * clamp(c.elapsed / MATCH_SEC, 0.6, 1.15) * mult * (c.coached ? 1.15 : 1) * (1 - loss) * rr(0.95, 1.05);
  earn('match', fee); sfx('coin', 2); floatAt(COUNTER.x + 1.0, 1.9, COUNTER.z, '+$' + fmt(fee), '#7dff9a');
  if (S.rating >= 4 && Math.random() < 0.5) { const tip = fee * 0.08; earn('tip', tip); }
  c.state = 'leave'; const e = ent(); c.ch.forEach((ch, k) => { ch.path = routeAround(ch.g.position.x, ch.g.position.z, e.din.x, e.din.z + k * 0.5).concat([{ x: e.sp.x, z: e.sp.z }]); ch.speed = 1.5; });
}
// penonton liga
function mkSpecs(c, n) {
  const tb = c.tb, p = tb.group.position, b = bounds(), col = Math.round(p.x / COL_X), gx = col < b.cols - 1 ? p.x + 2.5 : p.x - 2.5, e = ent();
  for (let i = 0; i < n; i++) { const ch = mkChar(lookOf(pick(TYPES))); ch.g.position.set(e.sp.x, 0, e.sp.z + (i % 4) * 0.6); const tx = gx + (i % 2) * 0.45 - 0.2, tz = p.z - 1.3 + i * 0.4 * (4 / Math.max(4, n)) * 2; ch.path = [{ x: e.din.x, z: e.din.z + (i % 3) * 0.4 }].concat(routeAround(e.din.x, e.din.z + (i % 3) * 0.4, tx, tz)); ch.speed = 1.5; ch.cheer = false; ch.spec = { tb }; c.specs.push(ch); }
}
function updSpecs(dt) { for (const c of ctls) for (const s of c.specs) { if (c.state !== 'leave') { walkPath(s, dt); if (!s.path.length) { faceAt(s, c.tb.group.position.x, c.tb.group.position.z, dt); if (c.m && c.m.last && c.m.last.pots && c.m.last.pots.length && c.ph === 'think') s.cheer = Math.random() < 0.02 ? !s.cheer : s.cheer; } } } }

// ===== Karyawan yang bekerja =====
const LOOKS = { kasir: { shirt: 0x1f5fbf, pants: 0x222222, skin: 0xe0ac69, hair: 0x111111 }, pelayan: { shirt: 0xf4f4f4, pants: 0x111111, skin: 0xc68642, hair: 0x2b1a0e }, bersih: { shirt: 0x2e7d32, pants: 0x2e7d32, skin: 0xf1c27d, hair: 0x4a3320 }, pelatih: { shirt: 0xc62828, pants: 0x222222, skin: 0x8d5524, hair: 0x111111 } };
const barSpot = () => { const b = bounds(); return { x: b.W1 - 4.6, z: b.Z0 + 2.2 }; };
function syncStaff() {
  for (const k in LOOKS) {
    const has = staffList.find(s => s.role === k), want = S.staff[k] > 0;
    if (want && !has) { const ch = mkChar(LOOKS[k]), s = { role: k, ch, st: 'idle', t: rr(0, 2), tb: null, d: null }; const p0 = tpos(0);
      if (k === 'kasir') { ch.g.position.set(COUNTER.x - 0.8, 0, COUNTER.z); ch.g.rotation.y = Math.PI / 2; }
      else if (k === 'pelatih') ch.g.position.set(p0.x + 2.4, 0, p0.z + 1.6); else if (k === 'pelayan') { const bs = barSpot(); ch.g.position.set(bs.x, 0, bs.z); } else ch.g.position.set(-1.6, 0, 3.0);
      if (k === 'pelayan') { const tray = new THREE.Group(); const tr = new THREE.Mesh(GEO.tray, mat(0xc0c0c8)); tray.add(tr); for (let i = 0; i < 3; i++) { const cp = new THREE.Mesh(GEO.cup, mat([0xffffff, 0xc62828, 0x1565c0][i])); cp.position.set(-0.08 + i * 0.08, 0.05, (i % 2) * 0.05); tray.add(cp); } tray.position.set(0, 1.0, 0.42); tray.visible = false; ch.g.add(tray); ch.props.tray = tray; }
      if (k === 'bersih') { const stick = new THREE.Mesh(GEO.arm, mat(0x8d6e63)); const head = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.05, 0.14), mat(0xdddddd)); ch.g.add(stick); ch.g.add(head); ch.props.mop = stick; ch.props.mophead = head; stick.visible = head.visible = false; }
      staffList.push(s); }
    else if (!want && has) { killChar(has.ch); staffList.splice(staffList.indexOf(has), 1); }
  }
}
function goTo(s, x, z, sp) { s.ch.path = routeAround(s.ch.g.position.x, s.ch.g.position.z, x, z); s.ch.speed = sp || 1.2; }
function updStaff(dt, tm) {
  for (const s of staffList) {
    const ch = s.ch;
    if (s.role === 'kasir') {
      const bob = Math.sin(tm * 6) * 0.015; ch.leanT = 0.12;
      if (kasirBusy > 0) { kasirBusy -= dt; const ex = 0.1 + Math.sin(tm * 5) * 0.05; handsLocal(ch, 0.14, 1.02, 0.75 + ex, -0.18, 0.98, 0.55); }
      else handsLocal(ch, 0.16, 1.0 + bob, 0.5, -0.16, 1.0 - bob, 0.5);
      faceDir(ch, Math.PI / 2, dt); continue;
    }
    if (s.role === 'pelatih') {
      if (s.st === 'idle') { s.t -= dt; const p0 = tpos(0); faceAt(ch, p0.x, p0.z, dt);
        if (s.t <= 0) { s.t = 3; const c = ctls.find(c => c.state === 'play' && !c.coached && !c.opts.league && Math.min(c.pl[0].skill, c.pl[1].skill) < 0.55); if (c) { s.c = c; const w = c.pl[0].skill <= c.pl[1].skill ? 0 : 1, sb = standby(c.tb, w); goTo(s, sb.x + (w ? 0.8 : -0.8), sb.z + (w ? -0.1 : 0.1), 1.3); s.st = 'go'; } } }
      else if (s.st === 'go') { if (walkPath(ch, dt)) { s.st = 'coach'; s.t = 6; s.c.coached = true; floatAt(ch.g.position.x, 2.0, ch.g.position.z, '🎓 Latihan', '#ffd166'); } }
      else if (s.st === 'coach') { s.t -= dt; faceAt(ch, s.c.tb.group.position.x, s.c.tb.group.position.z, dt); const sw = Math.sin(tm * 3); handsLocal(ch, 0.28, 1.45 + sw * 0.08, 0.55, -0.2, 1.0, 0.2); ch.leanT = 0.1; if (s.t <= 0 || !s.c.tb.ctl) { s.st = 'back'; const p0 = tpos(0); goTo(s, p0.x + 2.4, p0.z + 1.6, 1.3); s.t = 8; } }
      else if (s.st === 'back') { if (walkPath(ch, dt)) { s.st = 'idle'; } }
      continue;
    }
    if (s.role === 'pelayan') {
      const tray = ch.props.tray;
      if (s.st === 'idle') { tray.visible = false; s.t -= dt; const bs = barSpot(); faceDir(ch, 0, dt * 0 + dt); if (s.t <= 0) { s.t = 1; const tb = tables.find(t => t.order && !t.order.taken && t.ctl && t.ctl.state === 'play'); if (tb) { tb.order.taken = true; s.tb = tb; s.st = 'pickup'; s.t = 1.3; goTo(s, bs.x, bs.z, 1.4); } } }
      else if (s.st === 'pickup') { if (walkPath(ch, dt)) { s.t -= dt; tray.visible = true; handsLocal(ch, 0.22, 1.02, 0.45, -0.22, 1.02, 0.45); if (s.t <= 0) { s.st = 'deliver'; const sb = standby(s.tb, 0); goTo(s, sb.x + 0.9, sb.z + 0.2, 1.3); } } }
      else if (s.st === 'deliver') { tray.visible = true; handsLocal(ch, 0.22, 1.02, 0.45, -0.22, 1.02, 0.45); if (walkPath(ch, dt)) { s.st = 'serve'; s.t = 1.4; } }
      else if (s.st === 'serve') { s.t -= dt; faceAt(ch, s.tb.group.position.x - 0.9, s.tb.group.position.z + HZ + 1.2, dt); const off = 0.2 + Math.sin(tm * 6) * 0.04; handsLocal(ch, 0.22, 1.02, 0.45 + off, -0.22, 1.02, 0.45 + off);
        if (s.t <= 0) { if (s.tb.order) { earn('cafe', s.tb.order.val); S.drinks++; prog('drinks', 1); sfx('coin', 2); floatAt(ch.g.position.x, 2.0, ch.g.position.z, '+$' + fmt(s.tb.order.val) + ' ☕', '#7dff9a'); s.tb.order = null; } s.st = 'return'; tray.visible = false; const bs = barSpot(); goTo(s, bs.x, bs.z, 1.4); } }
      else if (s.st === 'return') { if (walkPath(ch, dt)) { s.st = 'idle'; s.t = 1; } }
      continue;
    }
    if (s.role === 'bersih') {
      const mop = ch.props.mop, mh = ch.props.mophead;
      if (s.st === 'idle') { mop.visible = mh.visible = false; s.t -= dt; if (s.t <= 0) { s.t = 1.5; const d = dirts.length ? dirts.reduce((a, b) => Math.hypot(a.x - ch.g.position.x, a.z - ch.g.position.z) < Math.hypot(b.x - ch.g.position.x, b.z - ch.g.position.z) ? a : b) : null; if (d) { s.d = d; s.st = 'go'; goTo(s, d.x, d.z + 0.5, 1.5); } } }
      else if (s.st === 'go') { if (walkPath(ch, dt)) { s.st = 'mop'; s.t = 3.0; } }
      else if (s.st === 'mop') { s.t -= dt; mop.visible = mh.visible = true; faceAt(ch, s.d.x, s.d.z, dt); const sw = Math.sin(tm * 5) * 0.28, H = _v1.set(sw, 0.05, 0.62), T = _v2.set(0.2 + sw * 0.4, 1.05, 0.3); limb(mop, H, T); mh.position.set(sw, 0.05, 0.62); handsLocal(ch, T.x + 0.02, T.y - 0.05, T.z, T.x - 0.02, T.y - 0.4, (H.z + T.z) / 2 + 0.05); ch.leanT = 0.25;
        if (s.t <= 0) { if (s.d && dirts.includes(s.d)) { scene.remove(s.d.m); dirts.splice(dirts.indexOf(s.d), 1); S.cleaned++; prog('clean', 1); sfx('coin', 1); } s.st = 'idle'; s.t = 1; mop.visible = mh.visible = false; } }
      continue;
    }
  }
}

// ===== Liga untuk NPC (kamu penyelenggara) =====
const LGS = [
  { id: 'k', n: 'Liga Kampung', N: 8, minV: 1, minT: 2, mult: 1, sk: [0.3, 0.6] }, { id: 'c', n: 'Piala Kota', N: 16, minV: 3, minT: 4, mult: 2.2, sk: [0.4, 0.7] },
  { id: 'n', n: 'Kejuaraan Nasional', N: 16, minV: 6, minT: 8, mult: 9, sk: [0.6, 0.85] }, { id: 'i', n: 'Piala Internasional', N: 16, minV: 8, minT: 12, mult: 40, sk: [0.75, 0.95] }];
const lgEntry = d => Math.round(30 * Math.pow(2.3, S.venue - 1) * d.mult), lgOps = d => Math.round(d.N * lgEntry(d) * 0.22), lgPrize = d => Math.round(d.N * lgEntry(d) * 0.55);
const lgSponsor = d => Math.round(d.N * lgEntry(d) * 0.30 * S.rating / 5), lgTicket = d => Math.max(1, Math.round(lgEntry(d) * 0.06));
const lgBlock = d => LG ? 'Liga lain sedang berjalan' : S.venue < d.minV ? `Butuh lokasi ke-${d.minV}` : S.tables.length < d.minT ? `Butuh ${d.minT} meja` : Date.now() < S.lcd ? `Jeda ${Math.ceil((S.lcd - Date.now()) / 60000)} mnt` : S.cash < lgOps(d) ? 'Kas kurang' : '';
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; }
function buildRound() { LG.pending = []; shuffle(LG.alive); for (let i = 0; i < LG.alive.length; i += 2) LG.pending.push([LG.alive[i], LG.alive[i + 1]]); LG.nextAlive = []; LG.total = LG.pending.length; LG.done = 0; }
function startLeague(d) {
  if (lgBlock(d)) { toast(lgBlock(d)); return; } const ops = lgOps(d); pay('liga', ops);
  const names = shuffle(NAMES.slice()), players = []; for (let i = 0; i < d.N; i++) { const p = mkPlayer(i < 2 && d.mult > 2 ? TYPES[2] : null, rr(d.sk[0], d.sk[1])); p.name = names[i]; players.push(p); }
  LG = { d, players, alive: players.map((_, i) => i), round: 0, pending: [], nextAlive: [], running: [], total: 0, done: 0, rev: 0, tickets: 0, sponsor: 0, cost: ops, prize: lgPrize(d), k: Math.min(S.tables.length, d.N / 2), t0: Date.now() };
  const entries = d.N * lgEntry(d), sp = lgSponsor(d); earn('liga', entries); earn('liga', sp); LG.rev = entries; LG.sponsor = sp; buildRound(); toast(`${d.n} dimulai! Peserta mendaftar: +$${fmt(entries)}`);
}
function leagueResult(c) {
  if (!LG) return; const pair = c.opts.league.pair, w = c.m.winner; LG.nextAlive.push(pair[w]); LG.done++; const i = LG.running.indexOf(c); if (i >= 0) LG.running.splice(i, 1);
  const tk = c.specs.length * lgTicket(LG.d); if (tk > 0) { earn('liga', tk); LG.tickets += tk; floatAt(c.tb.group.position.x, 2.2, c.tb.group.position.z, '🎟 +$' + fmt(tk), '#ffd166'); }
  if (LG.done >= LG.total && !LG.pending.length) { if (LG.nextAlive.length === 1) finishLeague(); else { LG.alive = LG.nextAlive; LG.round++; buildRound(); toast(`Babak ${LG.round + 1} dimulai`); } }
}
function finishLeague() {
  const d = LG.d, champ = LG.players[LG.nextAlive[0]], prize = LG.prize; pay('liga', prize); S.leagues++; S.trophies++; S.lcd = Date.now() + 6 * 60e3;
  const profit = LG.rev + LG.sponsor + LG.tickets - LG.cost - prize; const L = LG; LG = null; buildVenue();
  modal(`<h2>🏆 ${d.n} selesai</h2><p>Juara: <b>${champ.name}</b> (hadiah $${fmt(prize)})</p><p style="margin-top:8px">Pendaftaran $${fmt(L.rev)}<br>Sponsor $${fmt(L.sponsor)}<br>Tiket $${fmt(L.tickets)}<br>Biaya $${fmt(L.cost)} + hadiah $${fmt(prize)}<br><b style="color:${profit >= 0 ? '#7dff9a' : '#ff8a8a'}">Laba bersih: ${profit >= 0 ? '+' : '-'}$${fmt(Math.abs(profit))}</b></p>`);
}
function updLeague() {
  if (!LG) return;
  while (LG.pending.length && LG.running.length < LG.k) { const tb = tables.find(t => !t.ctl && !t.svcT && S.tables[t.i].cond > 10); if (!tb) break; const pair = LG.pending.shift(); const c = mkCtl(tb, LG.players[pair[0]], LG.players[pair[1]], { league: { pair, round: LG.round } }); mkSpecs(c, crowdN(LG.alive.length <= 2 ? 3 : LG.round)); LG.running.push(c); }
}

// ===== Waktu, pengeluaran, rating =====
let revT = 0, spawnT = 3, hudT = 0, autoT = 0, tmAcc = 0;
function closeDay() { const sum = o => Object.keys(o).reduce((a, k) => a + (k === 'modal' ? 0 : o[k]), 0); S.fin.hist.push({ rev: sum(S.fin.rev), exp: sum(S.fin.exp), day: S.day }); if (S.fin.hist.length > 7) S.fin.hist.shift(); S.fin.rev = {}; S.fin.exp = {}; S.day++; toast('Hari ' + S.day + ' dimulai · laporan di tab Laporan'); }
function tickWorld(dt) {
  S.dayT += dt; if (S.dayT >= DAY) { S.dayT -= DAY; closeDay(); }
  pay('rent', expRent() * dt); pay('listrik', expElec() * dt); pay('gaji', expStaff() * dt); pay('fasilitas', expFac() * dt);
  if (S.broke > 0) S.broke -= dt * 0.1; S.rating += (targetRating() - S.rating) * Math.min(1, dt * 0.05);
  revT += dt; if (revT > 90) { revT = 0; addReview(); }
  for (const tb of tables) { if (tb.order && !tb.order.taken) { tb.order.t += dt; if (tb.order.t > 35) tb.order = null; } if (tb.svcT > 0) { tb.svcT -= dt; if (tb.svcT <= 0) { tb.svcT = 0; S.tables[tb.i].cond = 100; styleTable(tb); } } }
  spawnT -= dt;
  if (spawnT <= 0) { const free = tables.filter(t => !t.ctl && !t.svcT && S.tables[t.i].cond >= 15); let avail = free.length; if (LG && LG.pending.length) avail -= Math.max(0, Math.min(LG.k - LG.running.length, LG.pending.length));
    if (avail > 0) startNPC(pick(free)); spawnT = Math.max(3, 10 - 0.8 * S.rating - 0.7 * S.fac.park) * (0.7 + 0.1 * S.price) * rr(0.8, 1.2); }
}

// ===== UI =====
const sheetEl = $('sheet'), sheetBody = $('sb');
const cashOK = c => S.cash >= c, gemOK = c => S.gems >= c;
const btn = (a, label, cost, cur, x, cls) => `<button class="btn ${cls || (cur === 'g' ? 'g' : '')}" data-a="${a}" data-x="${x === undefined ? 0 : x}" data-cost="${cost}" data-cur="${cur}"${(cur === 'g' ? S.gems : S.cash) >= cost ? '' : ' disabled'}>${label}</button>`;
const card = (ic, t, sub, right, p, tint) => `<div class="card"><div class="ic ${tint || ''}">${ic}</div><div class="tx"><b>${t}</b><small>${sub}</small>${p != null ? `<i class="bar"><u style="width:${Math.round(clamp(p, 0, 1) * 100)}%"></u></i>` : ''}</div><div class="rt">${right || ''}</div></div>`;
const chips = (items, cur, act) => '<div class="chips">' + items.map(([k, l]) => `<button class="chip2 ${k === cur ? 'on' : ''}" data-a="${act}" data-x="${k}">${l}</button>`).join('') + '</div>';
const sec = t => `<h4>${t}</h4>`;
function invest(n) { if (S.cash < n) return false; S.cash -= n; S.fin.exp.modal = (S.fin.exp.modal || 0) + n; return true; }
const starStr = r => { const f = Math.floor(r + 0.25); return '★'.repeat(f) + '☆'.repeat(5 - f); };
const maxLvNow = () => VEN[S.venue - 1].maxLv;

function tTables() {
  const t = S.tables[sel], lv = t.lv, mx = maxLvNow(), cap = VEN[S.venue - 1].cap, tb = tables[sel], use = tb && tb.ctl;
  let h = chips(S.tables.map((x, i) => [i, `Meja ${i + 1} · Lv${x.lv}`]).concat([['all', '🔍 Semua']]), sel, 'selT');
  h += card('🎱', `Meja ${sel + 1}: ${TNAME[lv - 1]}`, `Lv.${lv}/${mx} · Kondisi ${Math.round(t.cond)}% · ±$${fmt(matchFee(t))}/pertandingan`, lv >= MAX_LV ? '<span class="max">MAX</span>' : lv >= mx ? '<span class="max">Renovasi lokasi</span>' : btn('upT', `⬆ $${fmt(upCost(lv))}`, upCost(lv), 'c'), lv / MAX_LV);
  h += card('🔧', 'Servis Meja', use ? 'Meja sedang dipakai' : `Pulihkan kondisi jadi 100% (12 dtk)`, tb && tb.svcT > 0 ? '<span class="max">Diservis…</span>' : btn('svc', `$${fmt(svcCost(lv))}`, svcCost(lv), 'c'), t.cond / 100);
  h += card('👁️', 'Tonton Pertandingan', 'Dekati meja ini dan lihat permainan NPC', '<button class="btn" data-a="watch" data-x="0">Tonton</button>');
  if (lv < MAX_LV) h += card('✨', `Level ${lv + 1}: ${TNAME[lv]}`, TDESC[lv], '', null, 'gold');
  h += sec('Tambah Meja') + card('➕', 'Meja Baru', `${S.tables.length}/${cap} meja${S.tables.length >= cap && S.venue < 8 ? ' · pindah lokasi untuk menambah' : ''}`, S.tables.length >= cap ? '<span class="max">PENUH</span>' : btn('buyT', `$${fmt(buyCost())}`, buyCost(), 'c'));
  return h;
}
function tBiz() {
  const k = sub.biz || 'lokasi'; let h = chips(SUBS.biz, k, 'sub:biz');
  if (k === 'lokasi') { const v = VEN[S.venue - 1], nx = VEN[S.venue];
    h += card('🏢', v.n, `Lokasi ${S.venue}/8 · ${v.cap} meja · meja maks Lv.${v.maxLv} · sewa $${fmt(v.rent)}/menit`, '', S.venue / 8, 'gold');
    if (nx) h += card('🚚', `Pindah ke ${nx.n}`, `${nx.cap} meja, meja maks Lv.${nx.maxLv}, sewa $${fmt(nx.rent)}/menit. Pengunjung & liga dihentikan sebentar.`, btn('renov', `$${fmt(nx.cost)}`, nx.cost, 'c')); }
  else if (k === 'staff') { for (const r in STAFF) { const F = STAFF[r], l = S.staff[r], c = stCost(r, l); h += card(F.ic, `${F.n} · Lv.${l}/5`, `${F.d} Gaji $${fmt(SAL[r] * Math.max(1, l) * (1 + 0.35 * (S.venue - 1)))}/mnt`, l >= 5 ? '<span class="max">MAX</span>' : btn('staff', (l ? 'Naik ' : 'Rekrut ') + '$' + fmt(c), c, 'c', r), l / 5); } }
  else if (k === 'fac') { for (const f in FAC) { const F = FAC[f], l = S.fac[f], c = facCost(f, l); h += card(F.ic, `${F.n} · Lv.${l}/${F.max}`, F.minV > S.venue ? `Butuh lokasi ke-${F.minV}` : F.d, F.minV > S.venue ? '<span class="max">🔒</span>' : l >= F.max ? '<span class="max">MAX</span>' : btn('fac', '$' + fmt(c), c, 'c', f), l / F.max); } }
  else { h += card('🏷️', 'Tarif Sewa Meja', `Tingkat ${S.price}/5 · bayaran ×${priceMult().toFixed(1)} · ${S.price > 3 ? 'pengunjung lebih jarang, rating turun' : S.price < 3 ? 'pengunjung lebih ramai, rating naik' : 'seimbang'}`, '<button class="btn s" data-a="price" data-x="-1">−</button><button class="btn s" data-a="price" data-x="1">+</button>', S.price / 5); }
  return h;
}
function tLeague() {
  let h = card('🏆', 'Liga untuk NPC', 'Kamu penyelenggara: pemain NPC mendaftar, bertanding sungguhan di mejamu, penonton membeli tiket, sponsor membayar. Laba = pendaftaran + tiket + sponsor − biaya − hadiah.', '', null, 'gold');
  if (LG) { const d = LG.d, live = LG.rev + LG.sponsor + LG.tickets - LG.cost - LG.prize;
    h += sec('Sedang berlangsung') + card('📣', d.n, `Babak ${LG.round + 1} · ${LG.done}/${LG.total} selesai · ${LG.running.length} meja aktif · ${LG.alive.length} peserta`, '', LG.done / Math.max(1, LG.total));
    h += card('💰', 'Estimasi laba sementara', `Pendaftaran $${fmt(LG.rev)} · Sponsor $${fmt(LG.sponsor)} · Tiket $${fmt(LG.tickets)} · Biaya $${fmt(LG.cost)} · Hadiah $${fmt(LG.prize)}`, `<b style="color:${live >= 0 ? '#7dff9a' : '#ff8a8a'}">${live >= 0 ? '+' : '-'}$${fmt(Math.abs(live))}</b>`); }
  h += sec('Pilih liga');
  LGS.forEach((d, i) => { const blk = lgBlock(d); h += card('🎖️', `${d.n} · ${d.N} pemain`, `Daftar $${fmt(lgEntry(d))}/pemain · hadiah juara $${fmt(lgPrize(d))} · tiket $${fmt(lgTicket(d))} · sponsor ≈$${fmt(lgSponsor(d))}`, blk ? `<span class="max">${blk}</span>` : btn('league', `Buka $${fmt(lgOps(d))}`, lgOps(d), 'c', i)); });
  return h + `<div class="note" style="color:#9fc">Tips: Tribun, Lounge VIP, Kafe, dan rating tinggi menambah penonton. Piala juara dipajang di lokasi ke-4 ke atas.</div>`;
}
function tReport() {
  const so = o => Object.keys(o).reduce((a, k) => a + (k === 'modal' ? 0 : o[k]), 0), rev = so(S.fin.rev), ex = so(S.fin.exp), pr = rev - ex, H = S.fin.hist, mx = Math.max(1, ...H.map(x => Math.max(x.rev, x.exp)), rev, ex);
  let h = card('📅', `Hari ke-${S.day}`, `Pendapatan $${fmt(rev)} · Pengeluaran $${fmt(ex)} · <b style="color:${pr >= 0 ? '#7dff9a' : '#ff8a8a'}">Laba ${pr >= 0 ? '+' : '-'}$${fmt(Math.abs(pr))}</b>`, '', S.dayT / DAY);
  h += card('📈', 'Perkiraan per menit', `Pendapatan ±$${fmt(revPerSec() * 60)} · Biaya $${fmt(expenses() * 60)} (sewa $${fmt(expRent() * 60)}, listrik $${fmt(expElec() * 60)}, gaji $${fmt(expStaff() * 60)}, fasilitas $${fmt(expFac() * 60)})`, `<b style="color:${net() >= 0 ? '#7dff9a' : '#ff8a8a'}">${net() >= 0 ? '+' : '-'}$${fmt(Math.abs(net() * 60))}</b>`);
  h += sec('7 hari terakhir') + '<div class="chart">' + H.concat([{ rev, exp: ex, day: S.day, now: true }]).map(x => `<div class="cb"><i class="r" style="height:${Math.round(x.rev / mx * 100)}%"></i><i class="e" style="height:${Math.round(x.exp / mx * 100)}%"></i><small>${x.now ? 'Kini' : 'H' + x.day}</small></div>`).join('') + '</div><div class="note" style="color:#bcd">Hijau = pendapatan, merah = pengeluaran.</div>';
  h += sec('Rincian hari ini'); const L = { match: 'Sewa meja', cafe: 'Kafe', tip: 'Tip', liga: 'Liga', offline: 'Offline', rent: 'Sewa tempat', listrik: 'Listrik', gaji: 'Gaji', fasilitas: 'Fasilitas', modal: 'Investasi (upgrade, beli)' };
  const rows = Object.keys(S.fin.rev).map(k => `<div class="rw"><span>${L[k] || k}</span><b style="color:#7dff9a">+$${fmt(S.fin.rev[k])}</b></div>`).concat(Object.keys(S.fin.exp).map(k => `<div class="rw"><span>${L[k] || k}</span><b style="color:#ff9a9a">-$${fmt(S.fin.exp[k])}</b></div>`)).join('');
  h += `<div class="card" style="display:block">${rows || '<small>Belum ada transaksi.</small>'}</div>`;
  h += sec('Rating & kepuasan') + card('⭐', `${S.rating.toFixed(1)} / 5 ${starStr(S.rating)}`, `Kebersihan ${Math.round(cleanliness() * 100)}% · Kondisi meja ${Math.round(avgCond() * 100)}% · ${dirts.length} noda · rating memengaruhi jumlah pengunjung dan tarif`, '', S.rating / 5);
  h += sec('Ulasan pelanggan'); h += S.revs.length ? S.revs.slice(0, 6).map(r => card(r.st >= 4 ? '😊' : r.st === 3 ? '😐' : '😠', `${r.who} · ${'★'.repeat(r.st)}`, r.txt, '')).join('') : '<div class="note" style="color:#bcd">Belum ada ulasan.</div>';
  return h;
}
function tMore() {
  const k = sub.more || 'misi'; let h = chips(SUBS.more, k, 'sub:more');
  if (k === 'misi') { h += sec('Misi harian'); S.mis.list.forEach((m, i) => { const d = MP.find(p => p.id === m.id), rw = m.gem ? '10💎' : '$' + fmt(Math.max(200, revPerSec() * 300)); h += card('📋', d.t(m.need), `${Math.min(m.got, m.need)}/${m.need} · hadiah ${rw}`, m.claimed ? '<span class="max">✔</span>' : m.done ? `<button class="btn" data-a="claim" data-x="${i}">Klaim</button>` : '', m.got / m.need); }); }
  else if (k === 'ach') { h += sec('Pencapaian'); ACH.forEach(a => { const ok = a.ok(), cl = S.ach[a.id]; h += card(cl ? '🏅' : ok ? '🎁' : '🔒', a.n, `${a.d} · hadiah ${a.g}💎`, cl ? '<span class="max">✔</span>' : ok ? `<button class="btn" data-a="ach" data-x="${a.id}">Klaim</button>` : ''); }); }
  else if (k === 'shop') { const rdy = Date.now() - S.daily >= 864e5, left = Math.ceil((864e5 - (Date.now() - S.daily)) / 36e5);
    h += card('💎', 'Saldo Berlian', 'Berlian didapat dari hadiah harian, misi, dan pencapaian', `<b>${S.gems} 💎</b>`) + card('🎁', 'Hadiah Harian', rdy ? 'Gratis +20 berlian!' : `Klaim lagi ${left} jam lagi`, rdy ? '<button class="btn" data-a="daily" data-x="0">Klaim</button>' : '<span class="max">✔</span>');
    h += sec('Toko berlian') + card('⚡', 'Boost Pendapatan ×2', 'Aktif 10 menit (bisa ditumpuk)', btn('boost', '💎 30', 30, 'g')) + card('💰', 'Paket Uang', `±$${fmt(Math.max(500, revPerSec() * 7200))} (2 jam pendapatan)`, btn('pack', '💎 40', 40, 'g'));
    h += sec('Top Up Berlian');
    if (!NP) h += card('🛒', 'Top Up', 'Tersedia di aplikasi yang diunduh dari Google Play.', '');
    else { h += '<div class="grid">' + PACKS.map(p => `<button class="pack" data-a="buy" data-x="${p.id}"><b>💎 ${p.g}</b><span>${bill.price[p.id] || p.rp}</span></button>`).join('') + '</div>'; if (!bill.ok) h += '<div class="note" style="color:#ffcf4a">Menghubungkan ke Google Play… jika tombol tidak berfungsi, pastikan internet aktif dan akun Google terdaftar.</div>'; h += '<div class="note" style="color:#bcd">Pembayaran diproses oleh Google Play. Berlian tidak mempengaruhi kemampuan pemain NPC dan hanya mempercepat progres.</div>'; } }
  else if (k === 'set') { const qn = { auto: 'Otomatis (HD)', low: 'Rendah', mid: 'Sedang', high: 'Tinggi (HD)' }[S.quality];
    h += card('✏️', 'Nama Bisnis', S.name || '-', '<button class="btn" data-a="rename" data-x="0">Ubah</button>') + card('🖥️', 'Kualitas Grafis', qn + ' · pilih Rendah jika kurang lancar', '<button class="btn" data-a="quality" data-x="0">Ganti</button>') + card('🔊', 'Suara', S.mute ? 'Mati' : 'Hidup', '<button class="btn" data-a="mute" data-x="0">Ubah</button>')
      + card('🛡️', 'Kebijakan Privasi', 'Buka di peramban', '<button class="btn" data-a="privacy" data-x="0">Buka</button>') + card('🗑️', 'Hapus Semua Data', 'Mulai dari nol, tidak bisa dibatalkan', '<button class="btn s" style="width:auto;padding:9px 12px" data-a="reset" data-x="0">Hapus</button>'); }
  else if (k === 'help') { h += card('🎱', 'Cara bermain', 'Kamu pemilik tempat billiard. Pengunjung NPC bermain 9-ball sungguhan (±100 detik), lalu membayar di kasir. Tambah meja, upgrade, rekrut karyawan, dan bangun fasilitas.', '') + card('👆', 'Kontrol kamera', 'Geser = pindah, cubit = zoom. Ketuk meja untuk menonton dari dekat; geser di mode tonton untuk memutar.', '') + card('💸', 'Biaya', 'Sewa tempat, listrik, gaji, dan fasilitas berjalan terus. Pastikan pendapatan lebih besar dari biaya (lihat tab Laporan).', '') + card('🧹', 'Rating', 'Rating naik jika lantai bersih, meja terawat (servis), fasilitas lengkap, dan tarif wajar. Rating tinggi = lebih banyak pengunjung dan bayaran lebih besar.', '') + card('🏆', 'Liga', 'Buka liga untuk NPC: kamu untung dari pendaftaran, tiket penonton, dan sponsor setelah dikurangi hadiah.', ''); }
  else { h += `<div class="about"><img src="img/logo.png" alt="logo"><b>Billiard Business Tycoon 3D</b><small>Versi 1.1.0</small><small>Simulasi bisnis billiard. Tidak ada judi atau uang sungguhan dalam permainan. Data tersimpan hanya di perangkatmu.</small><button class="btn" data-a="privacy" data-x="0">Kebijakan Privasi</button></div>`; }
  return h;
}
const SUBS = { biz: [['lokasi', '🏢 Lokasi'], ['staff', '👔 Karyawan'], ['fac', '🏗️ Fasilitas'], ['harga', '🏷️ Harga']], more: [['misi', '📋 Misi'], ['ach', '🏅 Prestasi'], ['shop', '💎 Toko'], ['set', '⚙️ Pengaturan'], ['help', '❓ Bantuan'], ['about', 'ℹ️ Tentang']] };
const TABS = { tables: ['🎱 Meja', tTables], biz: ['🏪 Kelola Bisnis', tBiz], league: ['🏆 Liga NPC', tLeague], report: ['📊 Laporan', tReport], more: ['☰ Lainnya', tMore] };
function render() {
  document.querySelectorAll('.nv').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  sheetEl.classList.toggle('open', !!tab); document.body.classList.toggle('sheetopen', !!tab); if (!tab) return;
  $('st').textContent = TABS[tab][0]; const top = sheetBody.scrollTop; sheetBody.innerHTML = TABS[tab][1](); sheetBody.scrollTop = top;
}
function afford() { sheetBody.querySelectorAll('[data-cost]').forEach(b => { b.disabled = (b.dataset.cur === 'g' ? S.gems : S.cash) < +b.dataset.cost; }); }
function hud() {
  $('bn').textContent = S.name || 'Billiard Business'; $('rk').textContent = VEN[S.venue - 1].n + ' · ' + starStr(S.rating) + ' ' + S.rating.toFixed(1);
  $('cash').textContent = '$' + fmt(S.cash); $('gem').textContent = S.gems; const n = net() * 60; $('inc').textContent = (n >= 0 ? '+' : '-') + '$' + fmt(Math.abs(n)) + '/mnt'; $('inc').style.color = n >= 0 ? '' : '#ff9a9a';
  const b = $('bst'); if (boosted()) { b.style.display = 'block'; b.textContent = '⚡ ×2 · ' + Math.ceil((S.boostUntil - Date.now()) / 60000) + ' mnt'; } else b.style.display = 'none';
  const lb = $('lgb'); if (LG) { lb.style.display = 'block'; lb.textContent = `🏆 ${LG.d.n} · babak ${LG.round + 1} · ${LG.done}/${LG.total}`; } else lb.style.display = 'none';
  afford(); const p = tpos(sel); hl.position.x = p.x; hl.position.z = p.z; hl.visible = cam.spec < 0 && !!tab;
  if (cam.spec >= 0) tpHud();
}
function tpHud() {
  const i = cam.spec, t = S.tables[i], tb = tables[i]; if (!t || !tb) return; const c = tb.ctl, m = c && c.m;
  $('tpn').textContent = `Meja ${i + 1} · ${TNAME[t.lv - 1]}`; $('tpl').textContent = `Lv.${t.lv} · Kondisi ${Math.round(t.cond)}%`;
  $('tpm').textContent = m ? `${c.pl[0].name} ${m.pots[0]} – ${m.pots[1]} ${c.pl[1].name} · ${Math.floor(c.elapsed)} dtk` : c ? (c.state === 'pay' || c.state === 'leave' ? 'Pertandingan selesai' : 'Pemain bersiap…') : tb.svcT > 0 ? 'Sedang diservis' : 'Meja kosong';
  $('tpu').disabled = t.lv >= maxLvNow() || S.cash < upCost(t.lv); $('tpu').textContent = t.lv >= maxLvNow() ? 'Level maks' : '⬆ $' + fmt(upCost(t.lv)); $('tps').disabled = !!c || tb.svcT > 0 || S.cash < svcCost(t.lv); $('tps').textContent = '🔧 $' + fmt(svcCost(t.lv));
}
function refresh() { hud(); if (tab === 'tables') render(); }
function floatText(p, txt, col) { const v = p.clone().project(camera); if (v.z > 1 || Math.abs(v.x) > 1.1 || Math.abs(v.y) > 1.1) return; const d = document.createElement('div'); d.className = 'fl'; d.textContent = txt; if (col) d.style.color = col; d.style.left = ((v.x + 1) / 2 * innerWidth - 24) + 'px'; d.style.top = ((1 - v.y) / 2 * innerHeight) + 'px'; document.body.appendChild(d); setTimeout(() => d.remove(), 1200); }
function modal(html, ok) { $('modal').style.display = 'flex'; $('mc').innerHTML = html + '<button class="btn big" id="mok">OK</button>'; $('mok').onclick = () => { $('modal').style.display = 'none'; if (ok) ok(); }; }

function renovate() {
  const nx = VEN[S.venue]; if (!nx || LG) { if (LG) toast('Selesaikan liga dulu'); return; } if (!invest(nx.cost)) return;
  for (const c of ctls.slice()) removeCtl(c); dirts.forEach(d => scene.remove(d.m)); dirts.length = 0; S.venue++; staffList.slice().forEach(s => killChar(s.ch)); staffList.length = 0;
  buildVenue(); syncTables(); syncStaff(); fitAll(true); closeSpec(); toast('Selamat pindah ke ' + nx.n + '!');
}
function act(a, x) {
  if (a === 'selT') { if (x === 'all') { cam.dist = cam.maxD; cam.x = (bounds().W0 + bounds().W1) / 2; cam.z = (bounds().Z0 + bounds().Z1) / 2; closeSpec(); } else { sel = +x; } }
  else if (a === 'watch') { openSpec(sel); tab = null; }
  else if (a === 'upT') { const t = S.tables[sel]; if (t.lv < maxLvNow() && invest(upCost(t.lv))) { t.lv++; styleTable(tables[sel]); prog('up', 1); toast(`Meja ${sel + 1} naik ke Lv.${t.lv}: ${TNAME[t.lv - 1]}`); } }
  else if (a === 'svc') { const t = S.tables[sel], tb = tables[sel]; if (!tb.ctl && !tb.svcT && invest(svcCost(t.lv))) { tb.svcT = 12; styleTable(tb); prog('service', 1); toast('Meja diservis…'); } }
  else if (a === 'buyT') { if (S.tables.length < VEN[S.venue - 1].cap && invest(buyCost())) { S.tables.push({ lv: 1, cond: 100 }); syncTables(); sel = S.tables.length - 1; toast('Meja baru dibeli!'); } }
  else if (a === 'renov') { renovate(); }
  else if (a === 'staff') { if (S.staff[x] < 5 && invest(stCost(x, S.staff[x]))) { S.staff[x]++; syncStaff(); toast(STAFF[x].n + ' Lv.' + S.staff[x]); } }
  else if (a === 'fac') { const F = FAC[x], l = S.fac[x]; if (F.minV <= S.venue && l < F.max && invest(facCost(x, l))) { S.fac[x]++; buildVenue(); toast(F.n + ' Lv.' + S.fac[x]); } }
  else if (a === 'price') S.price = clamp(S.price + x, 1, 5);
  else if (a.indexOf('sub:') === 0) { sub[a.slice(4)] = x; }
  else if (a === 'league') startLeague(LGS[x]);
  else if (a === 'claim') { const m = S.mis.list[x]; if (m && m.done && !m.claimed) { m.claimed = true; if (m.gem) { S.gems += 10; toast('+10 💎'); } else { const g = Math.max(200, revPerSec() * 300); earn('misi', g); toast('+$' + fmt(g)); } } }
  else if (a === 'ach') { const d = ACH.find(q => q.id === x); if (d && d.ok() && !S.ach[x]) { S.ach[x] = 1; S.gems += d.g; toast('🏅 ' + d.n + ' +' + d.g + '💎'); } }
  else if (a === 'daily') { if (Date.now() - S.daily >= 864e5) { S.gems += 20; S.daily = Date.now(); toast('+20 💎 hadiah harian'); } }
  else if (a === 'boost') { if (S.gems >= 30) { S.gems -= 30; S.boostUntil = Math.max(Date.now(), S.boostUntil) + 10 * 60000; toast('⚡ Boost ×2 aktif 10 menit'); } }
  else if (a === 'pack') { if (S.gems >= 40) { S.gems -= 40; const g = Math.max(500, revPerSec() * 7200); earn('toko', g); toast('+$' + fmt(g)); } }
  else if (a === 'rename') { const n = prompt('Nama bisnis:', S.name); if (n && n.trim()) { S.name = n.trim().slice(0, 24); drawSign(); } }
  else if (a === 'quality') { const o = ['auto', 'low', 'mid', 'high']; S.quality = o[(o.indexOf(S.quality) + 1) % 4]; save(); toast('Memuat ulang dengan kualitas baru…'); setTimeout(() => location.reload(), 600); return; }
  else if (a === 'mute') S.mute = !S.mute;
  else if (a === 'buy') { buyPack(x); return; }
  else if (a === 'privacy') { try { window.open(PRIVACY_URL, '_blank'); } catch (e) { toast(PRIVACY_URL); } }
  else if (a === 'reset') { if (confirm('Hapus semua progres?')) { window.__reset = true; try { localStorage.removeItem(SAVE); } catch (e) {} location.reload(); return; } }
  save(); render(); hud();
}
sheetBody.addEventListener('click', ev => { const b = ev.target.closest('[data-a]'); if (b && !b.disabled) act(b.dataset.a, b.dataset.x); });
document.querySelectorAll('.nv').forEach(b => b.onclick = () => { tab = tab === b.dataset.tab ? null : b.dataset.tab; if (tab) closeSpec(); render(); hud(); });
$('gear').onclick = () => { tab = 'more'; sub.more = 'set'; render(); };
$('sx').onclick = () => { tab = null; render(); };
$('tpb').onclick = () => closeSpec();
$('tpu').onclick = () => { sel = cam.spec; act('upT', 0); }; $('tps').onclick = () => { sel = cam.spec; act('svc', 0); };
$('lgb').onclick = () => { tab = 'league'; render(); };
if (S.name) $('intro').style.display = 'none';
$('go').onclick = () => { S.name = ($('nm').value || '').trim().slice(0, 24) || 'Billiard Bisnis Saya'; save(); drawSign(); $('intro').style.display = 'none'; hud(); if (!S.tutorial) { S.tutorial = true; modal('<h2>Selamat datang! 🎱</h2><p style="text-align:left;line-height:1.6">• Pengunjung NPC bermain 9-ball di mejamu dan membayar di kasir.<br>• Geser untuk menggeser kamera, cubit untuk zoom, <b>ketuk meja</b> untuk menonton.<br>• Naikkan level meja untuk desain baru dan bayaran lebih besar.<br>• Awasi <b>Laporan</b>: sewa, listrik, dan gaji berjalan terus.<br>• Buka <b>Liga NPC</b> untuk untung besar.</p>'); } };
$('privlink').onclick = () => act('privacy', 0);

// ===== Kamera, input, loop =====
const cam = { x: 0, z: 0, dist: 20, maxD: 30, spec: -1, sdist: 5, syaw: 0, pitch: 58 * Math.PI / 180, yaw: 0 };
function resize() { renderer.setPixelRatio(prCur); renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();
function fitAll(snap) {
  const b = bounds(), tv = Math.tan(camera.fov * Math.PI / 360), asp = camera.aspect, w = (b.W1 - b.W0) / 2 + 0.5, d = (b.Z1 - b.Z0) / 2 + 1;
  cam.maxD = Math.max(w / (tv * asp), d / (tv * 0.75)) + 1; cam.dist = Math.min(cam.maxD, Math.max(7, Math.min(b.W1 - b.W0, 11) / 2 / (tv * asp)));
  cam.x = (Math.min(b.cols, 2) - 1) * COL_X / 2; cam.z = (Math.min(b.rows, 2) - 1) * ROW_Z / 2 + 0.3; cam.yaw = 0;
}
function openSpec(i) {
  cam.spec = i; sel = i; const tv = Math.tan(camera.fov * Math.PI / 360), asp = camera.aspect, portrait = asp < 0.9; cam.syaw = portrait ? Math.PI / 2 : 0;
  cam.sdist = clamp((portrait ? Math.max(1.15 / (tv * asp), 1.95 / (tv * 0.8)) : Math.max(1.85 / (tv * asp), 1.25 / (tv * 0.8))) + 0.3, 2.6, 9); $('tp').style.display = 'block'; document.body.classList.add('spec'); tab = null; render();
}
function closeSpec() { cam.spec = -1; $('tp').style.display = 'none'; document.body.classList.remove('spec'); }
function planCam() {
  if (cam.spec >= 0 && tables[cam.spec]) {
    const tb = tables[cam.spec], p = tb.group.position, c = tb.ctl; let tx = p.x, tz = p.z; if (c && c.m && c.ph) { const cu = E.cue(c.m); tx = p.x + cu.x * 0.45; tz = p.z + cu.z * 0.45; }
    const sp = 52 * Math.PI / 180, d = cam.sdist; tgtT.set(tx, 0.85, tz); tgtP.set(tx + Math.sin(cam.syaw) * Math.cos(sp) * d, 0.85 + Math.sin(sp) * d, tz + Math.cos(cam.syaw) * Math.cos(sp) * d); return;
  }
  const b = bounds(); cam.x = clamp(cam.x, b.W0, b.W1); cam.z = clamp(cam.z, b.Z0, b.Z1 + 1); tgtT.set(cam.x, 0.5, cam.z);
  tgtP.set(cam.x + Math.sin(cam.yaw) * Math.cos(cam.pitch) * cam.dist, 0.5 + Math.sin(cam.pitch) * cam.dist, cam.z + Math.cos(cam.yaw) * Math.cos(cam.pitch) * cam.dist);
}
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), gplane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
function groundAt(x, y) { ndc.set(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera); const p = new THREE.Vector3(); return ray.ray.intersectPlane(gplane, p) ? p : null; }
const ptrs = new Map(); let tapInfo = null, lastPinch = 0; const dom = renderer.domElement;
const pinchD = () => { const a = [...ptrs.values()]; return a.length < 2 ? 0 : Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y); };
function zoom(f) { if (cam.spec >= 0) cam.sdist = clamp(cam.sdist * f, 2.2, 10); else cam.dist = clamp(cam.dist * f, 5, cam.maxD); }
dom.addEventListener('pointerdown', e => { try { dom.setPointerCapture(e.pointerId); } catch (er) {} ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); tapInfo = { t: performance.now(), moved: 0 }; if (ptrs.size === 2) { lastPinch = pinchD(); tapInfo = null; } });
dom.addEventListener('pointermove', e => {
  const p = ptrs.get(e.pointerId); if (!p) return; const px = p.x, py = p.y, dx = e.clientX - px, dy = e.clientY - py; p.x = e.clientX; p.y = e.clientY; if (tapInfo) tapInfo.moved += Math.abs(dx) + Math.abs(dy);
  if (ptrs.size === 2) { const d = pinchD(); if (lastPinch > 0 && d > 0) zoom(lastPinch / d); lastPinch = d; }
  else if (ptrs.size === 1 && tapInfo && tapInfo.moved > 8) { if (cam.spec >= 0) cam.syaw -= dx * 0.006; else { const a = groundAt(px, py), b = groundAt(e.clientX, e.clientY); if (a && b) { cam.x += a.x - b.x; cam.z += a.z - b.z; } } }
});
function endPtr(e) {
  const ti = tapInfo; ptrs.delete(e.pointerId); if (ptrs.size < 2) lastPinch = 0; if (!ti || ptrs.size) return; tapInfo = null;
  if (ti.moved < 10 && performance.now() - ti.t < 500 && cam.spec < 0) { ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera); const hit = ray.intersectObjects(tables.map(t => t.group), true)[0]; if (hit) { let o = hit.object; while (o && o.userData.i === undefined) o = o.parent; if (o) openSpec(o.userData.i); } }
}
dom.addEventListener('pointerup', endPtr); dom.addEventListener('pointercancel', e => { ptrs.delete(e.pointerId); tapInfo = null; lastPinch = 0; });
dom.addEventListener('wheel', e => { zoom(e.deltaY > 0 ? 1.1 : 0.9); e.preventDefault(); }, { passive: false });
try { const A = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App; if (A) A.addListener('backButton', () => { if ($('modal').style.display === 'flex') return; if (tab) { tab = null; render(); } else if (cam.spec >= 0) closeSpec(); else A.minimizeApp(); }); } catch (e) {}

let last = performance.now(), vo = 0, fAcc = 0, fN = 0, warm = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const raw = Math.min(0.1, (now - last) / 1000), dt = Math.min(0.05, raw); last = now; sfxN = 0; tmAcc += dt;
  warm += raw; if (warm > 3) { fAcc += raw; fN++; if (fAcc >= 2) { const avg = fAcc / fN, cap = Math.min(window.devicePixelRatio || 1, QS.pr); fAcc = 0; fN = 0; if (avg > 1 / 38 && prCur > 1) { prCur = Math.max(1, prCur - 0.25); resize(); } else if (avg < 1 / 57 && prCur < cap) { prCur = Math.min(cap, prCur + 0.125); resize(); } } }
  tickWorld(dt); updLeague(); for (let i = ctls.length - 1; i >= 0; i--) updCtl(ctls[i], dt);
  for (const tb of tables) { setBalls(tb, tb.ctl && tb.ctl.ph === 'roll' ? dt : 0); if (tb.glow) tb.glow.material.opacity = 0.3 + 0.1 * Math.sin(tmAcc * 2 + tb.i); for (let g = 0; g < tb.gems.length; g++) tb.gems[g].rotation.y += dt * 1.5; }
  for (const f of anim) f(tmAcc);
  updSpecs(dt); updStaff(dt, tmAcc); for (const ch of chars) animChar(ch, dt);
  planCam(); const k = 1 - Math.exp(-dt * 4); camT.lerp(tgtT, k); camP.lerp(tgtP, k); camera.position.copy(camP); camera.lookAt(camT);
  const tvo = tab ? (sheetEl.offsetHeight + 62) * 0.5 : cam.spec >= 0 ? ($('tp').offsetHeight + 62) * 0.45 : 0; vo += (tvo - vo) * 0.15; camera.setViewOffset(innerWidth, innerHeight, 0, vo, innerWidth, innerHeight);
  hudT += dt; if (hudT >= 0.5) { hudT = 0; hud(); } autoT += dt; if (autoT >= 10) { autoT = 0; save(); }
  renderer.render(scene, camera);
}
// ===== Mulai =====
S.broke = 0; genMissions(); buildVenue(); syncTables(); syncStaff(); fitAll(true); planCam(); camT.copy(tgtT); camP.copy(tgtP); hud();
{ const dtO = Math.min((Date.now() - (S.t || Date.now())) / 1000, 4 * 3600), g = Math.floor(net() * 0.4 * dtO); if (dtO > 120 && g > 0) { earn('offline', g); setTimeout(() => toast('Pendapatan saat offline: $' + fmt(g)), 800); } }
billingInit().then(() => { if (tab) render(); hud(); });
requestAnimationFrame(loop);
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); }); addEventListener('pagehide', save);
})();
