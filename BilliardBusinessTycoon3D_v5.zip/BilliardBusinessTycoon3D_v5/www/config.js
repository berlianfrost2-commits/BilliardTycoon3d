window.APP_CONFIG = { privacyUrl: "" };
