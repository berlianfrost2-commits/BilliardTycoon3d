// Mesin biliar 9-ball: fisika, aturan, prediksi bidikan, dan AI. Tanpa dependensi (bisa dites di Node).
(function (root) {
'use strict';
const R = 0.045, HX = 1.27, HZ = 0.635, POCKET = 0.11;
const POCKETS = [[HX, HZ], [HX, -HZ], [-HX, HZ], [-HX, -HZ], [0, HZ], [0, -HZ]];
const HEAD = { x: -0.6, z: 0 }, FOOT = { x: 0.45, z: 0 };
const rnd = (a, b) => a + Math.random() * (b - a);
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.75;
// Jarak tempuh bola dari kecepatan awal v (hukum gesekan: dv/dt = -(0.25 + 0.55 v))
const D = v => v / 0.55 - (0.25 / 0.3025) * Math.log(1 + 0.55 * v / 0.25);
function invD(d) { let lo = 0, hi = 9; for (let i = 0; i < 28; i++) { const mid = (lo + hi) / 2; if (D(mid) < d) lo = mid; else hi = mid; } return (lo + hi) / 2; }

function rackPositions() {
  const rows = [1, 2, 3, 2, 1], dx = R * 2 * 0.866 * 1.01, dz = R * 2 * 1.02, pos = [];
  rows.forEach((n, r) => { for (let i = 0; i < n; i++) pos.push([FOOT.x + r * dx, (i - (n - 1) / 2) * dz]); });
  return pos;
}
const mkBall = (n, x, z) => ({ n, x, z, vx: 0, vz: 0, alive: true, sp: 0 });
function newMatch(p0, p1) {
  const pos = rackPositions(), rest = [2, 3, 4, 5, 6, 7, 8];
  for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
  const nums = [1, rest[0], rest[1], rest[2], 9, rest[3], rest[4], rest[5], rest[6]];
  const balls = [mkBall(0, HEAD.x, HEAD.z)];
  nums.forEach((n, i) => balls.push(mkBall(n, pos[i][0], pos[i][1])));
  balls.sort((x, y) => x.n - y.n); // indeks array = nomor bola
  return { balls, players: [p0, p1], turn: 0, phase: 'aim', inHand: false, shot: null, winner: -1, shots: 0, events: [], last: null, seq: 0, pots: [0, 0] };
}
const lowest = m => { let l = 99; for (const b of m.balls) if (b.alive && b.n > 0 && b.n < l) l = b.n; return l; };
const cue = m => m.balls[0];
const ball = (m, n) => m.balls[n];
const moving = m => m.balls.some(b => b.alive && (b.vx || b.vz));
function freeSpot(m, x, z) {
  if (Math.abs(x) > HX - R - 0.01 || Math.abs(z) > HZ - R - 0.01) return false;
  for (const b of m.balls) if (b.alive && b.n > 0 && (b.x - x) ** 2 + (b.z - z) ** 2 < 4 * R * R * 1.02) return false;
  return true;
}
function shoot(m, ang, speed, spin) {
  const c = cue(m);
  c.vx = Math.cos(ang) * speed; c.vz = Math.sin(ang) * speed; c.sp = spin || 0;
  m.phase = 'roll'; m.inHand = false; m.shots++;
  m.shot = { low: lowest(m), first: null, pots: [], cuePot: false, rail: false };
  m.events.push({ t: 'cue', v: speed });
}
function step(m, dt) {
  if (m.phase !== 'roll') return;
  const B = m.balls, n = Math.max(3, Math.ceil(dt / 0.002)), h = dt / n, sh = m.shot;
  for (let s = 0; s < n; s++) {
    for (const b of B) {
      if (!b.alive || !(b.vx || b.vz)) continue;
      b.x += b.vx * h; b.z += b.vz * h;
      const sp = Math.hypot(b.vx, b.vz), ns = sp - (0.25 + 0.55 * sp) * h;
      if (ns <= 0.02) { b.vx = b.vz = 0; } else { const k = ns / sp; b.vx *= k; b.vz *= k; }
      let potted = false;
      for (const p of POCKETS) if ((b.x - p[0]) ** 2 + (b.z - p[1]) ** 2 < POCKET * POCKET) { potted = true; break; }
      if (potted) { b.alive = false; b.vx = b.vz = 0; if (b.n === 0) sh.cuePot = true; else sh.pots.push(b.n); m.events.push({ t: 'pot', n: b.n }); continue; }
      let hit = false;
      if (b.x > HX - R) { b.x = HX - R; if (b.vx > 0) { b.vx *= -0.78; b.vz *= 0.97; hit = true; } }
      else if (b.x < -HX + R) { b.x = -HX + R; if (b.vx < 0) { b.vx *= -0.78; b.vz *= 0.97; hit = true; } }
      if (b.z > HZ - R) { b.z = HZ - R; if (b.vz > 0) { b.vz *= -0.78; b.vx *= 0.97; hit = true; } }
      else if (b.z < -HZ + R) { b.z = -HZ + R; if (b.vz < 0) { b.vz *= -0.78; b.vx *= 0.97; hit = true; } }
      if (hit) { if (sh.first !== null) sh.rail = true; m.events.push({ t: 'rail', v: Math.hypot(b.vx, b.vz) }); }
    }
    for (let i = 0; i < B.length; i++) {
      const a = B[i]; if (!a.alive) continue;
      for (let j = i + 1; j < B.length; j++) {
        const b = B[j]; if (!b.alive) continue;
        const dx = a.x - b.x, dz = a.z - b.z, d2 = dx * dx + dz * dz;
        if (d2 <= 0 || d2 >= 4 * R * R) continue;
        const d = Math.sqrt(d2), nx = dx / d, nz = dz / d, ov = (2 * R - d) / 2;
        a.x += nx * ov; a.z += nz * ov; b.x -= nx * ov; b.z -= nz * ov;
        const imp = (a.vx - b.vx) * nx + (a.vz - b.vz) * nz;
        if (imp >= 0) continue;
        const c = a.n === 0 ? a : (b.n === 0 ? b : null);
        let pv = 0, ux = 0, uz = 0;
        if (c) { pv = Math.hypot(c.vx, c.vz); if (pv > 0) { ux = c.vx / pv; uz = c.vz / pv; } }
        const k = imp * 0.96;
        a.vx -= k * nx; a.vz -= k * nz; b.vx += k * nx; b.vz += k * nz;
        if (c && sh.first === null) {
          sh.first = (c === a ? b : a).n;
          if (c.sp) { c.vx += ux * c.sp * pv * 0.45; c.vz += uz * c.sp * pv * 0.45; c.sp = 0; }
        }
        m.events.push({ t: 'click', v: -imp });
      }
    }
  }
  if (m.events.length > 80) m.events.splice(0, m.events.length - 80);
  if (!moving(m)) resolve(m);
}
function spotNear(m, x, z) {
  if (freeSpot(m, x, z)) return [x, z];
  for (let r = 1; r < 40; r++) for (let a = 0; a < 8; a++) { const px = x + Math.cos(a * 0.785) * r * R * 0.9, pz = z + Math.sin(a * 0.785) * r * R * 0.9; if (freeSpot(m, px, pz)) return [px, pz]; }
  return [x, z];
}
function resolve(m) {
  const sh = m.shot, me = m.turn, other = 1 - me; let foul = false, reason = '';
  if (sh.cuePot) { foul = true; reason = 'Bola putih masuk kantong'; }
  else if (sh.first === null) { foul = true; reason = 'Tidak menyentuh bola'; }
  else if (sh.first !== sh.low) { foul = true; reason = 'Harus kena bola ' + sh.low + ' dulu'; }
  else if (!sh.pots.length && !sh.rail) { foul = true; reason = 'Tidak ada bola kena bantalan'; }
  const nine = sh.pots.includes(9);
  m.pots[me] += sh.pots.filter(n => n !== 9 || !foul).length;
  let win = -1;
  if (nine) { if (!foul) win = me; else { const b9 = ball(m, 9), sp = spotNear(m, FOOT.x, FOOT.z); b9.alive = true; b9.x = sp[0]; b9.z = sp[1]; b9.vx = b9.vz = 0; } }
  const c = cue(m);
  if (sh.cuePot) { const sp = spotNear(m, HEAD.x, HEAD.z); c.alive = true; c.x = sp[0]; c.z = sp[1]; c.vx = c.vz = 0; }
  const potsNo9 = sh.pots.filter(n => n !== 9);
  m.last = { who: me, foul, reason, pots: sh.pots.slice() };
  if (win >= 0) { m.winner = win; m.phase = 'over'; m.last.reason = 'Bola 9 masuk!'; }
  else if (m.shots >= 70) { m.winner = m.pots[0] >= m.pots[1] ? 0 : 1; m.phase = 'over'; m.last.reason = 'Batas waktu'; }
  else {
    m.phase = 'aim';
    if (foul) { m.turn = other; m.inHand = true; }
    else if (potsNo9.length > 0) { m.inHand = false; }
    else { m.turn = other; m.inHand = false; }
  }
  m.seq++;
}
// Prediksi bidikan: titik kontak, bola target, arah bola target setelah tumbukan
function predict(m, ang) {
  const c = cue(m), dx = Math.cos(ang), dz = Math.sin(ang); let best = { t: 1e9 };
  for (const b of m.balls) {
    if (!b.alive || b.n === 0) continue;
    const fx = c.x - b.x, fz = c.z - b.z, bq = fx * dx + fz * dz, cq = fx * fx + fz * fz - 4 * R * R, disc = bq * bq - cq;
    if (disc < 0) continue; const t = -bq - Math.sqrt(disc); if (t > 0 && t < best.t) best = { t, ball: b };
  }
  let tr = 1e9;
  if (dx > 1e-6) tr = Math.min(tr, (HX - R - c.x) / dx); else if (dx < -1e-6) tr = Math.min(tr, (-HX + R - c.x) / dx);
  if (dz > 1e-6) tr = Math.min(tr, (HZ - R - c.z) / dz); else if (dz < -1e-6) tr = Math.min(tr, (-HZ + R - c.z) / dz);
  if (best.t < tr) {
    const gx = c.x + dx * best.t, gz = c.z + dz * best.t, nx = (best.ball.x - gx) / (2 * R), nz = (best.ball.z - gz) / (2 * R), dn = dx * nx + dz * nz;
    return { t: best.t, gx, gz, n: best.ball.n, bx: best.ball.x, bz: best.ball.z, tdx: nx, tdz: nz, cdx: dx - dn * nx, cdz: dz - dn * nz };
  }
  return { t: tr, gx: c.x + dx * tr, gz: c.z + dz * tr, n: null };
}
// ---------- AI ----------
function segDist(px, pz, ax, az, bx, bz) {
  const vx = bx - ax, vz = bz - az, l2 = vx * vx + vz * vz; let t = l2 ? ((px - ax) * vx + (pz - az) * vz) / l2 : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + vx * t), pz - (az + vz * t));
}
function planFrom(m, cx, cz) {
  const tgt = ball(m, lowest(m)); let best = null;
  for (const p of POCKETS) {
    const px = p[0] * 0.97, pz = p[1] * 0.97, dx = px - tgt.x, dz = pz - tgt.z, dT = Math.hypot(dx, dz); if (dT < 0.05) continue;
    const ux = dx / dT, uz = dz / dT, gx = tgt.x - ux * 2 * R, gz = tgt.z - uz * 2 * R;
    if (Math.abs(gx) > HX - R + 0.02 || Math.abs(gz) > HZ - R + 0.02) continue;
    const qx = gx - cx, qz = gz - cz, dC = Math.hypot(qx, qz); if (dC < 0.05) continue;
    const cosA = (qx * ux + qz * uz) / dC; if (cosA < 0.3) continue;
    let ok = true;
    for (const b of m.balls) {
      if (!b.alive || b.n === 0 || b === tgt) continue;
      if (segDist(b.x, b.z, cx, cz, gx, gz) < 2 * R * 0.98 || segDist(b.x, b.z, tgt.x, tgt.z, px, pz) < 2 * R * 0.98) { ok = false; break; }
    }
    if (!ok) continue;
    const score = cosA * 2 - dC * 0.5 - dT * 0.7;
    if (!best || score > best.score) {
      const vt = Math.max(0.5, invD(dT + 0.2)) * 1.1, vh = vt / Math.max(0.35, cosA), v0 = invD(dC + D(vh)) * 1.04 + 0.1;
      best = { ang: Math.atan2(qz, qx), speed: Math.min(6.2, Math.max(0.9, v0)), score };
    }
  }
  if (!best) { const a = Math.atan2(tgt.z - cz, tgt.x - cx); best = { ang: a, speed: rnd(1.6, 2.6), score: -9 }; }
  return best;
}
function aiShot(m, skill) {
  skill = skill == null ? 0.6 : skill;
  const c = cue(m); let plan, place = null;
  if (m.inHand) {
    let bp = null;
    for (let k = 0; k < 18; k++) {
      const x = rnd(-HX + 0.12, HX - 0.12), z = rnd(-HZ + 0.12, HZ - 0.12); if (!freeSpot(m, x, z)) continue;
      const p = planFrom(m, x, z); if (!bp || p.score > bp.p.score) bp = { p, x, z };
    }
    if (bp) { plan = bp.p; place = { x: bp.x, z: bp.z }; }
    else { const sp = spotNear(m, HEAD.x, HEAD.z); place = { x: sp[0], z: sp[1] }; plan = planFrom(m, sp[0], sp[1]); }
  } else if (m.shots === 0) {
    const ap = ball(m, 1); plan = { ang: Math.atan2(ap.z - c.z, ap.x - c.x), speed: rnd(4.4, 5.6), score: 0 };
  } else plan = planFrom(m, c.x, c.z);
  const e = 1 - skill;
  return { ang: plan.ang + gauss() * e * 0.035, speed: Math.max(0.6, plan.speed * (1 + gauss() * e * 0.12)), spin: 0, place };
}
const Engine = { R, HX, HZ, POCKET, POCKETS, HEAD, FOOT, newMatch, step, shoot, predict, aiShot, lowest, moving, freeSpot, cue, ball, rackPositions };
if (typeof module !== 'undefined' && module.exports) module.exports = Engine; else root.Engine = Engine;
})(typeof window !== 'undefined' ? window : globalThis);
